import asyncio
import os
import re
from pathlib import Path
from typing import Optional

from nicegui import ui


async def log(log_area: ui.textarea, line: str):
    """Appends a line to the given log area."""
    log_area.value = (log_area.value or '') + (('\n' if log_area.value else '') + line)
    await asyncio.sleep(0)  # Yield to the event loop to refresh the UI


async def run_and_stream(
    log_area: ui.textarea,
    title: str,
    *cmd,
    cwd: Path | None = None,
    ignore_exit_code: bool = True
) -> None:
    """
    Runs a command and streams its stdout/stderr to the provided log area.

    Raises:
        RuntimeError: If the command fails and `ignore_exit_code` is False.
        FileNotFoundError: If the command executable is not found.
    """
    await log(log_area, f'--- Running: {title} ---')
    try:
        proc = await asyncio.create_subprocess_exec(
            *map(str, cmd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(cwd) if cwd else None,
        )
    except FileNotFoundError:
        await log(log_area, f"ERROR: Command not found - {' '.join(map(str, cmd))}")
        raise

    assert proc.stdout is not None
    while True:
        line_bytes = await proc.stdout.readline()
        if not line_bytes:
            break
        await log(log_area, line_bytes.decode('utf-8', errors='ignore').strip())

    rc = await proc.wait()

    if rc != 0 and not ignore_exit_code:
        raise RuntimeError(f'Command failed with exit code {rc}: {cmd}')
    elif rc != 0 and ignore_exit_code:
        await log(log_area, f"INFO: Command '{title}' completed with non-zero exit code {rc} (ignored).")

    await log(log_area, f'--- Finished: {title} ---')


def sanitize_filename(name: str) -> str:
    """
    Sanitizes a filename by removing potentially problematic characters.
    It keeps the original extension.
    """
    name = Path(name).name
    return re.sub(r'[^A-Za-z0-9._-]', '_', name)

def directory_pdf(directory_path: str) -> Optional[str]:
    try:
        for filename in os.listdir(directory_path):
            if filename.lower().endswith(".pdf"):
                return filename
    except FileNotFoundError:
        raise FileNotFoundError(f"The directory '{directory_path}' does not exist.")
    except NotADirectoryError:
        raise NotADirectoryError(f"'{directory_path}' is not a valid directory.")
    
    return None