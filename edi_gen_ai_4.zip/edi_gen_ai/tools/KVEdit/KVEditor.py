from typing import List, Dict
from nicegui import ui
import copy

def make_xml_node_table(rows: List[Dict[str, str]], form_data: dict[str, str]):
    """Render a simple 3-column table using ui.row and ui.column instead of ui.table."""
    computed_rows = copy.deepcopy(rows)
    rows_workbench = copy.deepcopy(rows)
    headers = ["node-text", "text-value","xml-path"]
    input_registry: Dict[str, ui.input] = {}

    with ui.row().classes('gap-1 border no-wrap').style('width: 250px;'):
        clear_button = ui.button(icon='refresh').on_click(lambda: filter_value_changed('')).props('dense')
        filter_input = ui.input('').props('flat dense outline clearable').classes('w-full').style('height: 36px;')

    @ui.refreshable
    def render_table():
        input_registry.clear()
        with ui.element('div').style(
        'max-height:600px; overflow-y:auto; box-sizing:border-box;'
        'padding:0; margin:0;'
        ):
            with ui.column().classes('gap-0 border'):
                with ui.row().classes('gap-0 border'):
                    for header in headers:
                        with ui.column().style('width:250px' if header == 'node-text' else 'width:150px').classes('gap-0 border'):
                            ui.input('EDI Node' if header == 'node-text' else 'Value').props('flat dense outline readonly')
                
                for row in computed_rows:
                    with ui.row().classes('gap-0'):
                        for key in headers:
                            value = row.get(key, "")
                            with ui.column().style('width:250px' if key == 'node-text' else 'width:150px').classes('gap-0'):
                                if key == "text-value":
                                    temp_input = ui.input('').props('flat dense outline').style('height: 36px;').classes('w-full')
                                    temp_path = row.get('xml-path',None)
                                    temp_input.value = get_text_value(temp_path)
                                    input_registry[temp_path] = temp_input

                                    temp_input.on_value_change(lambda e, p=temp_path: update_text_value(p,e.value))
                                    if temp_path is not None:
                                        tmp_key = get_key_by_ref(form_data,temp_path)
                                        if tmp_key is not None:
                                            temp_input.bind_value(form_data,tmp_key)
                                else:
                                    temp_input = ui.input('').props('flat dense outline readonly').style('height: 36px;').classes('w-full')
                                    temp_input.value = value

    def change_dataset(new_rows: List[Dict[str, str]], form_data: dict[str, str]):
        nonlocal rows, rows_workbench, computed_rows

        rows = copy.deepcopy(new_rows)
        rows_workbench = copy.deepcopy(new_rows)
        computed_rows = copy.deepcopy(new_rows)
        render_table.refresh()

    def get_changes()->List[Dict[str, str]]:
        changes: List[Dict[str, str]] = []
        for orig_row in rows:
            if get_text_value(orig_row["xml-path"]) != orig_row["text-value"]:
                changed_row = {"node-text": orig_row["node-text"], "text-value": get_text_value(orig_row["xml-path"]), "xml-path": orig_row["xml-path"]}
                changes.append(changed_row)

        return changes

    def get_key_by_ref(form_data, ref_value):
        for key, value in form_data.items():
            if key is not None:
                if key.endswith("_filter") and value == ref_value:
                    return key[:-7]
        return None

    def filter_rows(rows: List[Dict[str, str]], query: str) -> List[Dict[str, str]]:
        if query is None:
            return rows
        if len(query.strip()) < 3:
            return rows

        query_lower = query.lower()
        return [
            row for row in rows
            if any(query_lower in value.lower() for value in row.values())
        ]

    def filter_value_changed(value):
        if filter_input.value != value:
            filter_input.value = value
        nonlocal computed_rows
        computed_rows = filter_rows(rows, value)
        render_table.refresh()

    def update_text_value(xml_path: str, new_value: str):
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                row["text-value"] = new_value
                break

    def get_text_value(xml_path: str)->str:
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                return row["text-value"]
        return ""

    filter_input.on_value_change(lambda e: filter_value_changed(e.value))
    render_table()

    return {
        "filter_value_changed": filter_value_changed,
        "render_table": render_table,
        "get_changes": get_changes,
        "change_dataset": change_dataset
    }