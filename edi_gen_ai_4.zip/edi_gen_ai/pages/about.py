# pages/about.py
from nicegui import ui

def create_content():
    """Creates the content for the About tab."""
    # Using a column with a small gap to control spacing
    with ui.column().classes('gap-1'):
        # CHANGED: Heading is now smaller (h6)
        ui.label('About this app').classes('text-h6')
        
        # CHANGED: Added .props('dense') to the expansion to reduce its height
        with ui.expansion('FAQ').props('dense'):
            ui.label('This page was defined in a separate file and is now a tab.')