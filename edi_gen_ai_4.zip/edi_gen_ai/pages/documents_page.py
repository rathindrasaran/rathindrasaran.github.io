from pathlib import Path
from nicegui import ui, app
from tools.generate_markdown import generate_markdown
from tools.utils import directory_pdf
from tools.xmltotree import xml_tree_gen

BASE_DIR = Path(__file__).resolve().parent.parent

def create(directory_name: str):
    """Creates the page for displaying XML documents in a directory."""
    with ui.column().classes('p-4 gap-4 max-w-full w-full'):
        uploads_dir = BASE_DIR / 'uploads'
        directory_path = uploads_dir / directory_name
        pdf_filename = directory_pdf(directory_path)

        ui.button(icon='arrow_back', on_click=ui.navigate.back, color='blue-300').props('flat round dense')
        ui.label(f'ERA files for: {pdf_filename}').classes('text-2xl font-semibold')

        if not directory_path.is_dir():
            ui.label(f'Directory "{directory_name}" not found.').classes('text-red-500')
            return

        xml_files = sorted(directory_path.glob('*.xml'))

        if not xml_files:
            ui.label('No XML files found in this directory.').classes('text-gray-500')
            return

        with ui.column().classes('gap-2 w-full'):
            for xml_path in xml_files:
                with ui.expansion(xml_path.name.replace("remittance_835_","").replace(".xml",""), icon='description').classes('w-full border rounded-lg'):
                    try:
                        with ui.tabs().props('dense') as tabs:
                            ui.tab('Web View')
                            ui.tab('Tree View')
                        with ui.tab_panels(tabs, value='Web View').classes('w-full'):
                            with ui.tab_panel('Web View'):
                                ui.markdown(generate_markdown(directory_path / xml_path))
                            with ui.tab_panel('Tree View'):
                                xml_tree_gen(xml_path)
                    except Exception as e:
                        ui.label(f'Error rendering {xml_path.name}: {e}').classes('text-negative')