# generate_markdown.py

import xml.etree.ElementTree as ET
from decimal import Decimal, InvalidOperation
import os
import sys
import requests
import subprocess
import json
from collections import defaultdict
import csv
import shutil
import markdown

provider_cache = []
DEFAULT_CONFIG_PATH = "/home/edipod/tools/pyx12-master/bin/py12.conf.xml"

PDF_GENERATION_ENABLED = True

# --- Helper Function to Load Definitions ---
def load_codes_from_json(filename):
    """Loads a code definition dictionary from a JSON file."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, filename)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Warning: Code definition file '{filename}' not found. Descriptions will be missing.")
        return {}
    except json.JSONDecodeError:
        print(f"Warning: Could not parse '{filename}'. It may be malformed.")
        return {}

# --- Load Code Definitions from JSON files ---
CAS_GROUP_CODES = load_codes_from_json('cas_group_codes.json')
CARC_CODES = load_codes_from_json('carc_codes.json')
RARC_CODES = load_codes_from_json('rarc_codes.json')
MOA_CODES = load_codes_from_json('moa_codes.json')

# --- Helper Dictionaries for Static Codes ---
N1_ENTITY_IDENTIFIER_CODES = {'PR': 'Payer', 'PE': 'Payee', 'QC': 'Patient', '82': 'Rendering Provider', 'TT': 'Transfer To Payer'}
BPR_PAYMENT_METHOD_CODES = {'ACH': 'Automated Clearing House (ACH)', 'CHK': 'Check', 'FWT': 'Federal Reserve Funds/Wire Transfer', 'NON': 'Non-Payment'}

# --- Other Helper Functions ---
def get_element_text(node, path, default=''):
    if node is None: return default
    element = node.find(path)
    return element.text.strip() if element is not None and element.text else default

def get_all_segments(node, seg_id):
    if node is None: return []
    return node.findall(f".//seg[@id='{seg_id}']")

def format_date(date_str):
    if date_str and len(date_str) == 8: return f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
    return date_str

def format_currency(amount_str):
    if not amount_str: return "$0.00"
    try: return f"${Decimal(str(amount_str)):,.2f}"
    except (InvalidOperation, TypeError): return amount_str

def parse_n1_loop(loop_node):
    details = {}
    if loop_node is None: return details
    n1_seg = loop_node.find("seg[@id='N1']")
    if n1_seg is not None:
        entity_code = get_element_text(n1_seg, "ele[@id='N101']")
        details['type'] = N1_ENTITY_IDENTIFIER_CODES.get(entity_code, entity_code)
        details['name'] = get_element_text(n1_seg, "ele[@id='N102']")
        id_code_qual = get_element_text(n1_seg, "ele[@id='N103']")
        id_code = get_element_text(n1_seg, "ele[@id='N104']")
        if id_code: details['id'] = f"{id_code_qual}: {id_code}"
    address_parts = [get_element_text(loop_node, "seg[@id='N3']/ele[@id='N301']"), get_element_text(loop_node, "seg[@id='N3']/ele[@id='N302']")]
    n4_seg = loop_node.find("seg[@id='N4']")
    if n4_seg is not None:
        city, state, zip_code = get_element_text(n4_seg, "ele[@id='N401']").strip(', '), get_element_text(n4_seg, "ele[@id='N402']"), get_element_text(n4_seg, "ele[@id='N403']")
        address_parts.append(f"{city}, {state} {zip_code}")
    details['address'] = "\n".join(filter(None, address_parts))
    return details

def parse_cas_segment(cas_seg):
    adjustments = []
    group_code = get_element_text(cas_seg, "ele[@id='CAS01']")
    if not group_code: return adjustments
    data_map = {}
    for ele in cas_seg.findall("ele"):
        ele_id_str = ele.get('id', '')
        if ele_id_str.startswith('CAS') and ele.text:
            try:
                num_part = int(ele_id_str[3:])
                if num_part > 1: data_map[num_part] = ele.text.strip()
            except (ValueError, IndexError): continue
    for i in range(2, 20, 3):
        reason_code, amount = data_map.get(i), data_map.get(i + 1)
        if reason_code and amount: adjustments.append((group_code, reason_code, amount))
    return adjustments


def getProviderNameFromNPI(NPINumber):
    global provider_cache

    # Normalize NPI
    npi = str(NPINumber).strip()
    if not npi.isdigit() or len(npi) != 10:
        return None

    # 1. Check cache first
    for record in provider_cache:
        if record["npi"] == npi:
            return record["name"]

    # 2. Not in cache → Call API
    url = f"https://npiregistry.cms.hhs.gov/api/?version=2.1&number={npi}"
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            return None

        data = resp.json()
        results = (data or {}).get("results", [])
        if not results:
            return None

        entry = results[0]
        basic = entry.get("basic", {}) if isinstance(entry, dict) else {}

        if entry.get("enumeration_type") == "NPI-2":
            name = basic.get("organization_name", "").strip()
        else:
            first = basic.get("first_name", "").strip()
            middle = basic.get("middle_name", "").strip()
            last = basic.get("last_name", "").strip()
            name_parts = [p for p in (first, middle, last) if p]
            name = " ".join(name_parts)

        # 3. Save to cache if we got a name
        if name:
            provider_cache.append({"npi": npi, "name": name})
            return name

    except (requests.RequestException, ValueError):
        return None

def generate_markdown(xml_path: str):
    markdown_content = []

    tree = ET.parse(xml_path)
    root = tree.getroot()

    all_carcs, all_rarcs, all_moas = set(), set(), set()
    st_loop = root.find(".//loop[@id='ST_LOOP']")
    if st_loop is None: return "No ST (Transaction Set) loop found in the file."

    markdown_content.append("# Electronic Remittance Advice (835)")
    header_loop = st_loop.find("loop[@id='HEADER']")
    bpr_seg, trn_seg = header_loop.find("seg[@id='BPR']"), header_loop.find("seg[@id='TRN']")
    if bpr_seg is not None:
        markdown_content.append("## Payment Summary")
        markdown_content.append(f"**Payment Date:** {format_date(get_element_text(bpr_seg, 'ele[@id=\"BPR16\"]'))}  \n**Total Payment:** {format_currency(get_element_text(bpr_seg, 'ele[@id=\"BPR02\"]'))}  \n**Payment Method:** {BPR_PAYMENT_METHOD_CODES.get(get_element_text(bpr_seg, 'ele[@id=\"BPR04\"]'), '')}  \n**Check/EFT Trace #:** {get_element_text(trn_seg, 'ele[@id=\"TRN02\"]')}")

    markdown_content.append("## Remittance Parties")
    payer_info, payee_info = parse_n1_loop(header_loop.find("loop[@id='1000A']")), parse_n1_loop(header_loop.find("loop[@id='1000B']"))
    payer_md = f"**{payer_info.get('name', 'N/A')}**<br>{payer_info.get('address', '').replace('\n', '<br>')}"
    payee_md = f"**{payee_info.get('name', 'N/A')}**<br>Provider ID: {payee_info.get('id', '').replace('XX: ','')}<br>{payee_info.get('address', '').replace('\n', '<br>')}"
    markdown_content.append(f"| Payer (From) | Payee (To) |\n| :--- | :--- |\n| {payer_md} | {payee_md} |\n")

    markdown_content.append("## Claim Details")
    claim_loops = st_loop.findall(".//loop[@id='2100']")
    if not claim_loops: markdown_content.append("No claim details found in this remittance.")

    for i, clp_loop in enumerate(claim_loops, 1):
        clp_seg = clp_loop.find("seg[@id='CLP']")
        patient_nm1 = next((s for s in clp_loop.findall("seg[@id='NM1']") if get_element_text(s, "ele[@id='NM101']") == 'QC'), None)
        patient_id = get_element_text(patient_nm1, 'ele[@id=\"NM109\"]') if patient_nm1 is not None else 'N/A'
        patient_name = f"{get_element_text(patient_nm1, 'ele[@id=\"NM103\"]')} {get_element_text(patient_nm1, 'ele[@id=\"NM104\"]')}" if patient_nm1 is not None else "Patient Information Not Found"

        # Find Rendering Provider details
        rendering_provider_nm1 = next((s for s in clp_loop.findall("seg[@id='NM1']") if get_element_text(s, "ele[@id='NM101']") == '82'), None)
        provider_details_md = ""
        if rendering_provider_nm1 is not None:
            provider_name = f"{get_element_text(rendering_provider_nm1, 'ele[@id=\"NM104\"]')} {get_element_text(rendering_provider_nm1, 'ele[@id=\"NM103\"]')}".strip()
            provider_npi = get_element_text(rendering_provider_nm1, 'ele[@id=\"NM109\"]')
            if provider_npi:
                if provider_name:
                    provider_details_md = f"<br>Rendering Provider: **{provider_name}** (NPI: {provider_npi})"
                else:
                    provider_name = getProviderNameFromNPI(provider_npi)
                    provider_details_md = f"<br>Rendering Provider: **{provider_name}** (NPI: {provider_npi})"

        markdown_content.append(f"### Claim {i}: {patient_name} (Patient ID: {patient_id}) \n{provider_details_md}")

        clp_status_code = get_element_text(clp_seg, 'ele[@id="CLP02"]')
        if clp_status_code == '19':
            transfer_to_nm1 = None
            for nm1_seg in clp_loop.findall("seg[@id='NM1']"):
                if get_element_text(nm1_seg, "ele[@id='NM101']") == 'TT':
                    transfer_to_nm1 = nm1_seg
                    break

            if transfer_to_nm1 is not None:
                fwd_name = get_element_text(transfer_to_nm1, "ele[@id='NM103']")
                fwd_id_qual = get_element_text(transfer_to_nm1, "ele[@id='NM108']")
                fwd_id = get_element_text(transfer_to_nm1, "ele[@id='NM109']")
                markdown_content.append(f"**Claim Forwarded:** This claim was forwarded to **{fwd_name}** ({fwd_id_qual}: {fwd_id}).")

        claim_level_moa_codes, claim_adjustments_and_remarks = [], defaultdict(list)
        for moa_seg in clp_loop.findall("seg[@id='MOA']"):
            for j in range(3, 9):
                code = get_element_text(moa_seg, f"ele[@id='MOA0{j}']")
                if code: all_moas.add(code); claim_level_moa_codes.append(code)

        svc_loops = clp_loop.findall("loop[@id='2110']")
        if svc_loops:
            svc_table_rows = ["| Line Control # | Service Date | Procedure Code | Billed | Allowed | Paid |", "| :--- | :--- | :--- | :--- | :--- | :--- |"]
            for svc_loop in svc_loops:
                svc_seg = svc_loop.find("seg[@id='SVC']")
                svc_dtm = next((s for s in svc_loop.findall("seg[@id='DTM']") if get_element_text(s, "ele[@id='DTM01']") == '472'), None)
                proc_code = get_element_text(svc_seg.find("comp[@id='SVC']"), 'subele[@id=\"SVC01-02\"]')
                svc_date = format_date(get_element_text(svc_dtm, 'ele[@id="DTM02"]'))
                amt_b6 = next((s for s in svc_loop.findall("seg[@id='AMT']") if get_element_text(s, "ele[@id='AMT01']") == 'B6'), None)

                # extract line control numbers
                ref_6r_seg = next((s for s in svc_loop.findall("seg[@id='REF']") if get_element_text(s, "ele[@id='REF01']") == '6R'), None)
                line_control_num = get_element_text(ref_6r_seg, 'ele[@id="REF02"]') if ref_6r_seg is not None else 'N/A'

                svc_table_rows.append(f"| {line_control_num} | {svc_date} | `{proc_code}` | {format_currency(get_element_text(svc_seg, 'ele[@id=\"SVC02\"]'))} | {format_currency(get_element_text(amt_b6, 'ele[@id=\"AMT02\"]')) if amt_b6 is not None else 'N/A'} | {format_currency(get_element_text(svc_seg, 'ele[@id=\"SVC03\"]'))} |")

                service_key = f"Service `{proc_code}` on {svc_date}"
                for cas_seg in get_all_segments(svc_loop, 'CAS'):
                    for group_code, reason_code, amount in parse_cas_segment(cas_seg):
                        all_carcs.add(reason_code)
                        claim_adjustments_and_remarks[service_key].append(f"CARC: {group_code}-{reason_code} ({format_currency(amount)})")
                for lq_seg in get_all_segments(svc_loop, 'LQ'):
                    if get_element_text(lq_seg, 'ele[@id=\"LQ01\"]') == 'HE':
                        remark_code = get_element_text(lq_seg, 'ele[@id=\"LQ02\"]')
                        all_rarcs.add(remark_code)
                        claim_adjustments_and_remarks[service_key].append(f"RARC: {remark_code}")

        coinsurance, deductible = Decimal('0'), Decimal('0')
        for cas_seg in clp_loop.findall(".//seg[@id='CAS']"):
            for group, reason, amount_str in parse_cas_segment(cas_seg):
                if group == 'PR':
                    try: amount = Decimal(amount_str)
                    except InvalidOperation: continue
                    if reason == '2': coinsurance += amount
                    elif reason == '1': deductible += amount
        icn, p_acct = get_element_text(clp_seg, 'ele[@id=\"CLP07\"]'), get_element_text(clp_seg, 'ele[@id=\"CLP01\"]')
        t_billed, t_paid, p_resp = format_currency(get_element_text(clp_seg, 'ele[@id=\"CLP03\"]')), format_currency(get_element_text(clp_seg, 'ele[@id=\"CLP04\"]')), format_currency(get_element_text(clp_seg, 'ele[@id=\"CLP05\"]'))
        markdown_content.append(f"| Claim Control # | Patient Acct # | Total Billed | Amount Paid | Patient Resp. (Total) | Co-Insurance | Deductible |\n| :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n| {icn} | {p_acct} | {t_billed} | {t_paid} | {p_resp} | {format_currency(coinsurance)} | {format_currency(deductible)} |\n")

        if svc_loops: markdown_content.append("\n".join(svc_table_rows))
        if claim_level_moa_codes: markdown_content.append(f"\n**Medicare Adjudication Info:** `{', '.join(sorted(claim_level_moa_codes))}`")
        if claim_adjustments_and_remarks:
            markdown_content.append("\n#### Adjustments & Remarks")
            for service_key, remarks_list in claim_adjustments_and_remarks.items():
                markdown_content.append(f"For {service_key}: {', '.join(remarks_list)}")
        markdown_content.append("<hr/>\n")

    markdown_content.append("---")
    markdown_content.append("## Code Reference")
    def build_legend(title, code_set, code_dict):
        if not code_set: return []
        legend = [f"### {title}"]
        for code in sorted(list(code_set)): legend.append(f"* **{code}:** {code_dict.get(code, 'Description not found')}")
        return legend
    markdown_content.extend(build_legend("Claim Adjustment Reason Codes (CARC)", all_carcs, CARC_CODES))
    markdown_content.extend(build_legend("Remittance Advice Remark Codes (RARC)", all_rarcs, RARC_CODES))
    markdown_content.extend(build_legend("Medicare Outpatient Adjudication (MOA) Codes", all_moas, MOA_CODES))

    markdown_content.append("\n---\n## Glossary")
    if CAS_GROUP_CODES:
        glossary_md = ["**Adjustment Group Codes:**"]
        for code, desc in sorted(CAS_GROUP_CODES.items()): glossary_md.append(f"* **{code}:** {desc}")
        markdown_content.append("<br/>\n".join(glossary_md))

    return "\n\n".join(markdown_content)

