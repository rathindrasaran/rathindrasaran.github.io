import xml.etree.ElementTree as ET
from nicegui import ui, app
from typing import Dict, Any, Optional

# --- Configuration ---
SCHEMA_FILE = 'tools/837.5010.X224.A2.xml'

# --- Global variable to hold the parsed XML tree of a SINGLE claim in memory ---
data_tree: Optional[ET.ElementTree] = None

# --- [REVISED AND CORRECTED] Single Claim Extraction Function ---
def get_single_claim_xml(claim_id: str, xml_file_path: str) -> str | None:
    """
    Parses an 837 EDI XML file, finds a single claim by its ID, and removes
    all other claims and billing provider loops (2000A) to isolate the
    single claim's hierarchy. It then readjusts segment and loop counters
    and returns the modified XML as a string.
    """
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except (FileNotFoundError, ET.ParseError) as e:
        print(f"Error reading or parsing source file {xml_file_path}: {e}")
        return None

    # Find the DETAIL loop which acts as the parent for all 2000A loops.
    detail_loop = root.find(".//loop[@id='DETAIL']")
    if detail_loop is None:
        print("Error: Could not find the main detail loop (DETAIL).")
        return None

    target_2000a = None
    target_2000b = None

    # Find the specific 2000A and 2000B loops containing the claim
    for loop_2000a in detail_loop.findall("loop[@id='2000A']"):
        for loop_2000b in loop_2000a.findall("loop[@id='2000B']"):
            clm_segment = loop_2000b.find(".//seg[@id='CLM']/ele[@id='CLM01']")
            if clm_segment is not None and clm_segment.text == claim_id:
                target_2000a = loop_2000a
                target_2000b = loop_2000b
                break  # Found the claim, exit inner loop
        if target_2000a:
            break  # Found the provider, exit outer loop

    if not target_2000a:
        print(f"Claim with ID '{claim_id}' not found.")
        return None

    # --- Filter Sibling 2000B Loops ---
    # Keep all children of the target 2000A loop EXCEPT for other 2000B loops.
    children_of_2000a_to_keep = []
    for child in target_2000a:
        if child.get('id') != '2000B':
            children_of_2000a_to_keep.append(child)
        elif child is target_2000b:  # Only keep the specific 2000B we found
            children_of_2000a_to_keep.append(child)
    
    target_2000a[:] = children_of_2000a_to_keep

    # --- Filter Sibling 2000A Loops ---
    # Replace all children of the DETAIL loop with only our modified target 2000A loop.
    detail_loop[:] = [target_2000a]

    # --- Recalculate Counters ---
    hl_segments = root.findall('.//seg[@id="HL"]')
    old_to_new_hl_map = {}
    for i, hl_seg in enumerate(hl_segments, start=1):
        hl01 = hl_seg.find("ele[@id='HL01']")
        if hl01 is not None:
            old_hl_id = hl01.text
            new_hl_id = str(i)
            old_to_new_hl_map[old_hl_id] = new_hl_id
            hl01.text = new_hl_id
        hl02 = hl_seg.find("ele[@id='HL02']")
        if hl02 is not None and hl02.text in old_to_new_hl_map:
            hl02.text = old_to_new_hl_map[hl02.text]

    st_loop = root.find(".//loop[@id='ST_LOOP']")
    if st_loop is not None:
        total_segments = len(st_loop.findall('.//seg'))
        se01 = st_loop.find("seg[@id='SE']/ele[@id='SE01']")
        if se01 is not None:
            se01.text = str(total_segments)

    return ET.tostring(root, encoding='unicode')

# --- Hierarchical Schema Parsing (No changes below this line, but included for completeness) ---
def parse_schema_hierarchically(schema_file: str) -> (Optional[Dict], Optional[Dict]):
    try:
        tree = ET.parse(schema_file)
        schema_root = tree.getroot()
    except (ET.ParseError, FileNotFoundError) as e:
        ui.notify(f"Fatal Error: Could not parse schema file '{schema_file}'. {e}", type='negative', multi_line=True)
        return None, None
    flat_schema_dict = {elem.get('xid'): {'name': elem.findtext('name', elem.get('xid'))} for elem in schema_root.findall(".//*[@xid]")}
    def _parse_node(xml_element: ET.Element) -> Dict[str, Any]:
        node_id = xml_element.get('xid')
        node_info = {'name': xml_element.findtext('name', node_id), 'children': {}}
        valid_codes_elem = xml_element.find('valid_codes')
        if valid_codes_elem is not None:
            codes = [code.text for code in valid_codes_elem.findall('code') if code.text]
            if codes: node_info['codes'] = codes
        for child_xml in xml_element:
            if 'xid' in child_xml.attrib:
                child_id = child_xml.get('xid')
                node_info['children'][child_id] = _parse_node(child_xml)
        return node_info
    root_xid = schema_root.get('xid')
    hierarchical_schema = {root_xid: _parse_node(schema_root)}
    return hierarchical_schema, flat_schema_dict

# --- Search and Rendering Logic ---
def node_contains_match(data_node: ET.Element, schema_node: Dict, search_term_lower: str, flat_schema: Dict) -> bool:
    if not search_term_lower: return False
    node_id = data_node.get('id', '')
    node_name = schema_node.get('name', '')
    if search_term_lower in node_id.lower() or search_term_lower in node_name.lower(): return True
    if data_node.tag in ('ele', 'subele') and data_node.text and search_term_lower in data_node.text.lower(): return True
    for child_data in data_node:
        child_id = child_data.get('id')
        child_schema = schema_node.get('children', {}).get(child_id)
        if child_schema and node_contains_match(child_data, child_schema, search_term_lower, flat_schema): return True
    return False

def render_node(data_node: ET.Element, schema_node: Dict, search_term: str, flat_schema: Dict):
    node_id = data_node.get('id', '')
    node_name = schema_node.get('name', node_id)
    term_lower = search_term.lower() if search_term else ''
    if data_node.tag in ('loop', 'seg'):
        header_matches = term_lower and (term_lower in node_id.lower() or term_lower in node_name.lower())
        child_has_match = term_lower and node_contains_match(data_node, schema_node, term_lower, flat_schema)
        icon = 'account_tree' if data_node.tag == 'loop' else 'segment'
        style_classes = 'w-full border-b ' + ('ml-3 bg-gray-50' if data_node.tag == 'seg' else '')
        highlight_class = ' bg-yellow-200' if header_matches else ''
        with ui.expansion(f'{node_name} ({node_id})', icon=icon).classes(style_classes + highlight_class).props('dense') as exp:
            if data_node.tag == 'seg':
                with ui.grid(columns=2).classes('p-2 gap-x-2 w-full'):
                    for child_data in data_node: render_node(child_data, schema_node, search_term, flat_schema)
            else:
                for child_data in data_node:
                    child_id = child_data.get('id')
                    child_schema = schema_node.get('children', {}).get(child_id)
                    if child_schema: render_node(child_data, child_schema, search_term, flat_schema)
        if child_has_match and not header_matches: exp.open()
    elif data_node.tag in ('ele', 'comp', 'subele'):
        ele_id = data_node.get('id')
        if data_node.tag == 'subele': ele_info = flat_schema.get(ele_id, {})
        else: ele_info = schema_node.get('children', {}).get(ele_id, {})
        ele_name = ele_info.get('name', ele_id)
        if data_node.tag in ('ele', 'subele'):
            current_value = data_node.text.strip() if data_node.text is not None else ''
            valid_codes = ele_info.get('codes')
            name_prefix = '- ' if data_node.tag == 'subele' else ''
            label_text = f'{name_prefix}{ele_name} ({ele_id})'
            name_matches = term_lower and term_lower in label_text.lower()
            value_matches = term_lower and term_lower in current_value.lower()
            label_classes = 'text-sm self-center' if data_node.tag == 'ele' else 'text-xs self-center ml-2'
            ui.label(label_text).classes(label_classes).classes('bg-yellow-100 p-1 rounded' if name_matches else '')
            if valid_codes and current_value in valid_codes:
                ui.select(options=valid_codes, value=current_value, on_change=lambda e, el=data_node: setattr(el, 'text', e.value)).classes('w-full').props('dense outlined').classes('bg-yellow-100' if value_matches else '')
            else:
                input_field = ui.input(value=current_value, on_change=lambda e, el=data_node: setattr(el, 'text', e.value)).classes('w-full').props('dense outlined').classes('bg-yellow-100' if value_matches else '')
                if valid_codes and current_value not in valid_codes:
                    with input_field:
                        ui.tooltip(f"Invalid Value. Options: {', '.join(valid_codes)}").classes('bg-red-600')
                        input_field.props('error')
        elif data_node.tag == 'comp':
            with ui.column().classes('col-span-2 border-l-2 border-blue-200 pl-2 my-1'):
                ui.label(f'Composite: {ele_name} ({ele_id})').classes('font-semibold text-xs text-blue-800')
                with ui.grid(columns=2).classes('gap-x-2 w-full'):
                    for sub_ele in data_node: render_node(sub_ele, schema_node, search_term, flat_schema)

@ui.refreshable
def claim_view_container(hierarchical_schema: Dict, flat_schema: Dict):
    if not data_tree:
        ui.label('Enter a Claim ID from the source file and click "Load Claim" to begin.').classes('text-lg text-center p-8')
        return
    search_term = app.storage.user.get('search_term', '')
    top_data_loop = data_tree.getroot().find('loop')
    if top_data_loop:
        top_schema_node = next(iter(hierarchical_schema.values()))['children']['ISA_LOOP']
        render_node(top_data_loop, top_schema_node, search_term, flat_schema)

# --- Main Application Setup ---
def create_tree_editor():
    """Creates the EDI 837 Tree Editor component."""
    global data_tree
    hierarchical_schema, flat_schema = parse_schema_hierarchically(SCHEMA_FILE)
    if not hierarchical_schema or not flat_schema:
        ui.label("Error: Could not load the EDI schema.").classes("text-negative")
        return None

    def load_claim_data(claim_id: str, xml_file: str):
        """Loads a single claim from an XML file into the global data_tree."""
        global data_tree
        if not claim_id or not xml_file:
            data_tree = None
            claim_view_container.refresh()
            return

        single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
        if single_claim_xml_str:
            try:
                root = ET.fromstring(single_claim_xml_str)
                data_tree = ET.ElementTree(root)
                app.storage.user['loaded_claim_id'] = claim_id
                ui.notify(f"Successfully loaded claim '{claim_id}'.", type='positive')
            except ET.ParseError as e:
                data_tree = None
                ui.notify(f"Error parsing XML for claim '{claim_id}'. {e}", type='negative', multi_line=True)
        else:
            data_tree = None
            ui.notify(f"Claim '{claim_id}' not found in the file.", type='negative')
        claim_view_container.refresh()

    app.storage.user.setdefault('search_term', '')
    app.storage.user.setdefault('loaded_claim_id', '')

    with ui.card().classes('w-full'):
        with ui.row().classes('w-full items-center'):
            ui.input(placeholder='Search loaded claim...').props('dense outlined bg-white').classes('flex-grow').bind_value(app.storage.user, 'search_term').on('update:model-value', claim_view_container.refresh, throttle=0.5)
            ui.button(icon='clear', on_click=lambda: (app.storage.user.update(search_term=''), claim_view_container.refresh())).props('flat round color=primary').tooltip('Clear search')
        
        with ui.column().classes('w-full'):
            claim_view_container(hierarchical_schema, flat_schema)

    return load_claim_data