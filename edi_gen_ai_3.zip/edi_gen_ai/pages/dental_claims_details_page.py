import os
from nicegui import ui, app
from pathlib import Path
from typing import Dict, Any
from functools import partial
from datetime import datetime
from tools.ada_dental import create_form, form_data, refresh_service_lines
from tools.xml_parser_d import parse_837D_xml
from tools.edi_table_editor_dental import create_table_editor, filter_name_contains, createCombinedPdfForAllClaims
import logging


logging.basicConfig(level=logging.INFO)
BASE_DIR = Path(__file__).resolve().parent.parent

def create_content(directory: str):
    """Creates the new EDI 837 viewer content based on the wireframe."""
    ui.add_head_html('<style>body { overflow: hidden; }</style>')
    with ui.row().classes("w-full gap-0 m-0 p-0 h-dvh"):
        # --- Data Loading ---
        workdir = BASE_DIR / "claims_upload" / directory
        xml_files = list(workdir.glob("*.xml"))
        if not xml_files:
            ui.label("No XML file found in this directory.").classes(
                "text-lg text-negative p-4"
            )
            return
        claim_data = parse_837D_xml(xml_files[0])
        if "error" in claim_data:
            ui.label(f"Error processing file: {claim_data['error']}").classes(
                "text-lg text-negative p-4"
            )
            return
        # --- Page Header ---
        with ui.row().classes("w-full items-center gap").style('height: 5dvh'):
            ui.button(
                icon="arrow_back", on_click=ui.navigate.back, color="primary"
            ).props("flat round dense")
            ui.label(f"Claim Details: {xml_files[0].name.replace('.xml','')}").classes(
                "text-lg font-semibold"
            )
        
        # --- Main Content Layout (2 columns) ---
        with ui.splitter(value=30).classes('w-full').style('height: 95dvh') as splitter:
            with splitter.before:
                # --- Left Panel: EDI 837 Tree Editor ---
                load_claim_for_editor = create_table_editor()

            with splitter.after:
                # --- Right Panel: Claim Grid and CMS Form ---
                files = [
                    f for f in os.listdir(workdir)
                    if os.path.isfile(os.path.join(workdir, f))
                    and not (f.endswith(".xml") or f == "info.json")
                ]
                with ui.row().classes('gap-2'):
                    ui.button("Download Full EDI",on_click=lambda: ui.download(f'{workdir}/{files[0]}',f'{xml_files[0].name.replace('.xml','')}.edi'))
                    ui.button("Generate Full PDF", on_click=lambda: createCombinedPdfForAllClaims(claim_data, xml_files[0].name))
                # --- Master Claim List ---
                columns = [
                {
                    "name": "claim_id",
                    "label": "Claim ID",
                    "field": "claim_id",
                    "sortable": True,
                    "filter": "agNumberColumnFilter",
                },
                {
                    "name": "patient_name",
                    "label": "Patient Name",
                    "field": "patient_name",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "dob",
                    "label": "DOB",
                    "field": "dob",
                    "sortable": True,
                    "filter": "agDateColumnFilter",
                },
                {
                    "name": "insurance",
                    "label": "Insurance",
                    "field": "insurance",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "subscriber_id",
                    "label": "Subscriber ID",
                    "field": "subscriber_id",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "provider_name",
                    "label": "Provider Name",
                    "field": "provider_name",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "amount",
                    "label": "Amt",
                    "field": "amount",
                    "sortable": True,
                    "filter": "agNumberColumnFilter",
                },
                {
                    "name": "date",
                    "label": "Date",
                    "field": "date",
                    "sortable": True,
                    "filter": "agDateColumnFilter",
                },
                ]
                rows = [
                    {
                        "claim_id": c.get("claim_info", {}).get("claim_control_number", "N/A"),
                        # "patient_name": f"{c.get('subscriber', {}).get('first_name', '')} {c.get('subscriber', {}).get('last_name', '')}".strip(),
                        "patient_name": f"{c.get('patient', c.get('subscriber', {})).get('first_name', '')} {c.get('patient', c.get('subscriber', {})).get('last_name', '')}".strip(),
                        "dob": datetime.strptime(c.get("patient", {}).get("dob", c.get("subscriber", {}).get("dob", "")),"%m/%d/%Y").date(),
                        "insurance": c.get("primary_payer_info", {}).get("name", "N/A"),
                        "subscriber_id": c.get("subscriber", {}).get("subscriber_id", "N/A"),
                        "provider_name": c.get("billing_provider", {}).get("name", "N/A"),
                        "amount": float(c.get("claim_info", {}).get("total_claim_charge_amount", "0.00")),
                        "date": datetime.strptime(claim_data.get("hierarchical_transaction", {}).get("creation_date", ""),"%m/%d/%Y").date(),
                    }
                    for c in claim_data.get("claims", [])
                ]
                if not rows:
                    ui.label("No claims found in the XML file.").classes("p-4")
                    return

                grid = ui.aggrid(
                    {
                        "columnDefs": columns,
                        "rowData": rows,
                        "rowSelection": "single",
                        "autoSizeColumns": True,
                    }
                ).classes('h-1/3')

                def handle_selection(e):
                    if e.args['data']:
                        populate_ada_form(e.args["data"]["claim_id"])

                grid.on('cellClicked', handle_selection)

                @ui.refreshable
                def populate_ada_form(claim_id: str = None):
                    if claim_id is None:
                        if not rows:
                            return
                        claim_id = rows[0]["claim_id"]

                    # --- Load data into the tree view ---
                    if load_claim_for_editor:
                        xml_file_path = str(xml_files[0])
                        load_claim_for_editor(claim_id, xml_file_path)

                    full_claim_obj = next(
                        (
                            c
                            for c in claim_data.get("claims", [])
                            if c.get("claim_info", {}).get("claim_control_number") == claim_id
                        ),
                        None,
                    )
                    if not full_claim_obj:
                        return

                    # Clear previous data
                    for key in form_data:
                        if isinstance(form_data[key], dict):
                            for sub_key in form_data[key]:
                                form_data[key][sub_key] = ""
                        elif isinstance(form_data[key], list):
                            form_data[key] = []
                        else:
                            form_data[key] = ""
                    form_data['service_lines'] = []
                    
                    # --- Populate Data ---
                    subscriber = full_claim_obj.get("subscriber", {})
                    primary_payer_info = full_claim_obj.get("primary_payer_info", {})
                    other_insured = full_claim_obj.get("other_insured", {})
                    patient = full_claim_obj.get("patient", subscriber)
                    billing_provider = full_claim_obj.get("billing_provider", {})
                    claim_info = full_claim_obj.get("claim_info", {})

                    # --- Map data to ADA form fields ---
                    form_data["1_type_of_transaction"]["statement_of_actual_services"] = claim_info.get("stmt_of_actual_service",False)
                    form_data["1_type_of_transaction"]["request_for_predetermination"] = claim_info.get("req_for_predet_preauth",False)
                    form_data["1_type_of_transaction"]["epsdt_title_xix"] = claim_info.get("epsdt_title_xix",False)
                    form_data["2_predetermination_number"] = claim_info.get("predet_preauth_number","")
                    form_data["2_predetermination_number_filter"] = ""
                    form_data["3a_payer_id"] = primary_payer_info.get("payer_id","")
                    form_data["3a_payer_id_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/NM1/NM109"
                    form_data["3_company_plan_name_address"] = f'{primary_payer_info.get("name", "")}\n{primary_payer_info.get("address", "")}\n{primary_payer_info.get("city", "")}, {primary_payer_info.get("state", "")} {primary_payer_info.get("zipcode", "")}'
                    form_data["3_company_plan_name_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB"
                    form_data["3_company_plan_name"] = f'{primary_payer_info.get("name", "")}'
                    form_data["3_company_plan_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/NM1/NM103"
                    form_data["3_company_address"] = f'{primary_payer_info.get("address", "")}'
                    form_data["3_company_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/N3/N301"
                    form_data["3_company_city"] = f'{primary_payer_info.get("city", "")}'
                    form_data["3_company_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/N4/N401"
                    form_data["3_company_state"] = f'{primary_payer_info.get("state", "")}'
                    form_data["3_company_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/N4/N402"
                    form_data["3_company_zipcode"] = f'{primary_payer_info.get("zipcode", "")}'
                    form_data["3_company_zipcode_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BB/N4/N403"
                    form_data["4_other_coverage"]["medical"] = claim_info.get("other_coverage_medical_flag",False)
                    form_data["4_other_coverage"]["dental"] = claim_info.get("other_coverage_dental_flag",False)
                    form_data["5_other_insured_name"] = f'{other_insured.get("last_name","")} {other_insured.get("first_name","")} {other_insured.get("middle_name","")} {other_insured.get("suffix","")}'
                    form_data["5_other_insured_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1"
                    form_data["5_other_insured_fname"] = f'{other_insured.get("first_name","")}'
                    form_data["5_other_insured_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM104"
                    form_data["5_other_insured_lname"] = f'{other_insured.get("last_name","")}'
                    form_data["5_other_insured_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM103"
                    form_data["8_other_insured_id"] = other_insured.get("policy_sub_id","")
                    form_data["8_other_insured_id_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM109"
                    form_data["9_other_plan_group_number"] = other_insured.get("other_sub_plan_grp_number","")
                    form_data["9_other_plan_group_number_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/NM1/NM109"
                    form_data["10_patient_relationship_to_other_insured"] = other_insured.get("other_plan_relation","")
                    form_data["10_patient_relationship_to_other_insured_filter"] = ""
                    
                    if form_data["4_other_coverage"]["medical"] or form_data["4_other_coverage"]["dental"]:
                        form_data["11_other_insurance_company_name_address"] = f'{other_insured.get("other_payer_name","")}\n{other_insured.get("other_payer_address","")}\n{other_insured.get("other_payer_city","")}, {other_insured.get("other_payer_state","")} {other_insured.get("other_payer_zipcode","")}'
                        form_data["11_other_insurance_company_name_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B"
                        form_data["11_other_insurance_company_name"] = f'{other_insured.get("other_payer_name","")}'
                        form_data["11_other_insurance_company_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/NM1/NM103"
                        form_data["11_other_insurance_company_address"] = f'{other_insured.get("other_payer_address","")}'
                        form_data["11_other_insurance_company_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/N3/N301"
                        form_data["11_other_insurance_company_city"] = f'{other_insured.get("other_payer_city","")}'
                        form_data["11_other_insurance_company_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/N4/N401"
                        form_data["11_other_insurance_company_state"] = f'{other_insured.get("other_payer_state","")}'
                        form_data["11_other_insurance_company_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/N4/N402"
                        form_data["11_other_insurance_company_zipcode"] = f'{other_insured.get("other_payer_zipcode","")}'
                        form_data["11_other_insurance_company_zipcode_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330B/N4/N403"

                    form_data["11a_other_payer_id"] = other_insured.get("other_payer_id","")
                    form_data["11a_other_payer_id_filter"] = ""

                    form_data["12_policyholder_name_address"] = f'{subscriber.get("first_name", "")} {subscriber.get("last_name", "")}, \n{subscriber.get("address", "")}, \n{subscriber.get("city", "")}, {subscriber.get("state", "")} {subscriber.get("zip", "")}'
                    form_data["12_policyholder_name_address_filter"] = ""
                    form_data["12_policyholder_fname"] = f'{subscriber.get("first_name", "")}'
                    form_data["12_policyholder_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM104"
                    form_data["12_policyholder_lname"] = f'{subscriber.get("last_name", "")}'
                    form_data["12_policyholder_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM103"
                    form_data["12_policyholder_address"] = f'{subscriber.get("address", "")}'
                    form_data["12_policyholder_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N3/N301"
                    form_data["12_policyholder_city"] = f'{subscriber.get("city", "")}'
                    form_data["12_policyholder_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N401"
                    form_data["12_policyholder_state"] = f'{subscriber.get("state", "")}'
                    form_data["12_policyholder_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N402"
                    form_data["12_policyholder_zipcode"] = f'{subscriber.get("zip", "")}'
                    form_data["12_policyholder_zipcode_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N403"

                    form_data["13_policyholder_dob"] = subscriber.get("dob", "")
                    form_data["13_policyholder_dob_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG02"
                    form_data["14_policyholder_gender"] = subscriber.get("gender", "")
                    form_data["14_policyholder_gender_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG03"
                    form_data["15_policyholder_id"] = subscriber.get("subscriber_id", "")
                    form_data["15_policyholder_id_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM109"
                    form_data["16_policyholder_plan_group_number"] = subscriber.get("sub_group_feca_num", "")
                    form_data["16_policyholder_plan_group_number_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/SBR/SBR03"
                    form_data["18_patient_relationship_to_policyholder"] = subscriber.get("relationship", "")
                    form_data["18_patient_relationship_to_policyholder_filter"] = ""

                    form_data["20_patient_name_address"] = f'{patient.get("first_name", "")} {patient.get("last_name", "")}\n{patient.get("address", "")}\n{patient.get("city", "")}, {patient.get("state", "")} {patient.get("zip", "")}'
                    form_data["20_patient_name_address_filter"] = ""

                    form_data["20_patient_fname"] = f'{patient.get("first_name", "")}'
                    form_data["20_patient_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/NM1/NM104" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM104"
                    form_data["20_patient_lname"] = f'{patient.get("last_name", "")}'
                    form_data["20_patient_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/NM1/NM103" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM103"
                    form_data["20_patient_address"] = f'{patient.get("address", "")}'
                    form_data["20_patient_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N3/N301" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N3/N301"
                    form_data["20_patient_city"] = f'{patient.get("city", "")}'
                    form_data["20_patient_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N401" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N401"
                    form_data["20_patient_state"] = f'{patient.get("state", "")}'
                    form_data["20_patient_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N402" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N402"
                    form_data["20_patient_zipcode"] = f'{patient.get("zip", "")}'
                    form_data["20_patient_zipcode_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N403" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N403"


                    form_data["21_patient_dob"] = patient.get("dob", "")
                    form_data["21_patient_dob_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000C/2010CA/DMG/DMG02" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG02"
                    form_data["22_patient_gender"] = patient.get("gender", "")
                    form_data["22_patient_gender_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000C/2010CA/DMG/DMG03" if full_claim_obj.get("patient",False) != False else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG03"
                    form_data["23_patient_id"] = patient.get("patient_id", "")
                    form_data["23_patient_id_filter"] = ""

                    # Billing Dentist
                    form_data["48_billing_dentist_name_address"] = f'{billing_provider.get("name", "")}\n{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'

                    form_data["48_billing_dentist_name"] = f'{billing_provider.get("name", "")}'
                    form_data["48_billing_dentist_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/NM1/NM103"
                    form_data["48_billing_dentist_address"] = f'{billing_provider.get("address", "")}'
                    form_data["48_billing_dentist_address_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N3/N301"
                    form_data["48_billing_dentist_city"] = f'{billing_provider.get("city", "")}'
                    form_data["48_billing_dentist_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N401"
                    form_data["48_billing_dentist_state"] = f'{billing_provider.get("state", "")}'
                    form_data["48_billing_dentist_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N402"
                    form_data["48_billing_dentist_zip"] = f'{billing_provider.get("zip", "")}'
                    form_data["48_billing_dentist_zip_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N403"

                    form_data["49_billing_dentist_npi"] = billing_provider.get("npi", "")
                    form_data["49_billing_dentist_npi_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/NM1/NM109"
                    form_data["51_billing_dentist_ssn_or_tin"] = billing_provider.get("tax_id", "")
                    form_data["51_billing_dentist_ssn_or_tin_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/REF/REF02"
                    form_data["52_billing_dentist_phone"] = billing_provider.get("phone", "")
                    form_data["52_billing_dentist_phone_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/PER/PER04"
                    
                    # Treating Dentist (assuming same as billing for now)
                    form_data["54_treating_dentist_npi"] = billing_provider.get("npi", "")
                    form_data["54_treating_dentist_npi_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/NM1/NM109"
                    form_data["56a_treatment_location_address"] = f'{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
                    form_data["56a_treatment_location_address_filter"] = ""
                    form_data["56a_treatment_location_address_1"] = f'{billing_provider.get("address", "")}'
                    form_data["56a_treatment_location_address_1_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N3/N301"
                    form_data["56a_treatment_location_city"] = f'{billing_provider.get("city", "")}'
                    form_data["56a_treatment_location_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N401"
                    form_data["56a_treatment_location_state"] = f'{billing_provider.get("state", "")}'
                    form_data["56a_treatment_location_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N402"
                    form_data["56a_treatment_location_zip"] = f'{billing_provider.get("zip", "")}'
                    form_data["56a_treatment_location_zip_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2010AA/N4/N403"

                    # Diagnoses
                    form_data["34_diagnosis_code_list_qualifier"] = f'{claim_info.get("diagnoses_q_1","")}{"|" if claim_info.get("diagnoses_q_1","") != "" else ""}{claim_info.get("diagnoses_q_2","")}'
                    form_data["34_diagnosis_code_list_qualifier_filter"] = ""
                    diagnoses = full_claim_obj.get("diagnoses", [])
                    for i, dx in enumerate(diagnoses[:4]):  # ADA form has 4 diagnosis slots (A, B, C, D)
                        form_data["34a_diagnosis_codes"][chr(65 + i)] = dx.get("code", "")
                    
                    # Total Fee
                    form_data["32_total_fee"] = claim_info.get("total_claim_charge_amount", "")
                    form_data["32_total_fee_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM02"
                    form_data["35_remarks"] = claim_info.get("remarks", "")
                    form_data["35_remarks_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/NTE/NTE02"
                    form_data["36_patient_guardian_signature"] = "Y" if claim_info.get("patient_sign",False) else "N"
                    form_data["36_patient_guardian_signature_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM09"
                    form_data["37_subscriber_signature"] = "Y" if claim_info.get("subscriber_sign",False) else "N"
                    form_data["37_subscriber_signature_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM08"
                    form_data["38_place_of_treatment"] = claim_info.get("place_of_service_code", "")
                    form_data["38_place_of_treatment_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM/CLM05-01"
                    form_data["40_is_treatment_for_orthodontics"] = "Y" if claim_info.get("ortho_treatment", False) else "N"
                    form_data["40_is_treatment_for_orthodontics_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/DN101"
                    form_data["41_date_appliance_placed"] = claim_info.get("ortho_appliance_pl_date", "")
                    form_data["41_date_appliance_placed_filter"] = ""
                    form_data["42_months_of_treatment"] = claim_info.get("months_of_treatment", "")
                    form_data["42_months_of_treatment_filter"] = ""
                    form_data["43_replacement_of_prosthesis"] = "Y" if claim_info.get("prosthesis_replacement", False) else "N"
                    form_data["43_replacement_of_prosthesis_filter"] = ""

                    # Service Lines
                    service_lines = full_claim_obj.get("service_lines", [])
                    for sl in service_lines:
                        new_line = {
                            "procedure_date": sl.get("date_of_service", ""),
                            "procedure_code": sl.get("procedure_code", ""),
                            "description": sl.get("description", ""),
                            "fee": sl.get("line_item_charge_amount", ""),
                            "quantity": sl.get("quantity", ""),
                            "diag_pointer": " ".join(map(str, sl.get("diagnosis_pointers", []))),
                            "tooth_number": sl.get("tooth_number",""),
                            "tooth_surface": sl.get("tooth_surface",""),
                            "oral_cavity_area": sl.get("area_of_oral_cavity",""),
                            "tooth_system": sl.get("tooth_system",""),
                        }
                        form_data['service_lines'].append(new_line)

                    missing_teeth = claim_info.get("missing_teeth", [])
                    for i in range(1, 33):
                        form_data["33_missing_teeth_information"][str(i)] = False
                    for mt in missing_teeth:
                        form_data["33_missing_teeth_information"][str(mt)] = True
                    

                    refresh_service_lines()


                with ui.scroll_area().classes('w-full m-0 p-0 gap-0 h-2/3'):
                    # --- Detail Area (CMS-1500 Form) ---
                    create_form(filter_name_contains)

                    # Initial population of the form
                    populate_ada_form()