# pages/login.py
from nicegui import ui, app

from config import VALID_CREDENTIALS


def require_auth_or_redirect():
    """Redirect to login if the user is not authenticated."""
    if not app.storage.user.get('authenticated'):
        ui.navigate.to('/login')
        return False
    return True


@ui.page('/login')
def login_page():
    # If already logged in, go straight to the main page
    if app.storage.user.get('authenticated'):
        ui.navigate.to('/')
        return

    # Full-screen container that centers its children
    with ui.row().classes('w-full h-screen items-center justify-center'):
        with ui.card().style('max-width: 420px; width: 100%'):
            ui.label('Welcome').classes('text-h5')
            ui.label('Please log in to continue.').classes('text-grey-6')

            username = ui.input('Username').props('outlined dense clearable').classes('w-full')
            password = ui.input('Password', password=True, password_toggle_button=True) \
                        .props('outlined dense clearable').classes('w-full')

            msg = ui.label().classes('text-negative')

            def do_login():
                user = username.value
                pwd = password.value
                if user in VALID_CREDENTIALS and VALID_CREDENTIALS[user] == pwd:
                    app.storage.user['authenticated'] = True
                    app.storage.user['username'] = user
                    msg.set_text('')
                    ui.navigate.to('/')  # Redirect to main page after login
                else:
                    msg.set_text('Invalid username or password.')

            ui.button('Log in', on_click=do_login).classes('w-full')
            ui.separator()
            ui.label('Org : RevExp LLC').classes('text-caption text-grey-6')