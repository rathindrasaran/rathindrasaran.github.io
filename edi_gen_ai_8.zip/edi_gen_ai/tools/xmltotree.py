# tools/xmltotree.py
from __future__ import annotations
from pathlib import Path
import csv
import xml.etree.ElementTree as ET
from collections import defaultdict
from typing import Dict, Any, List, Optional, Union
from nicegui import ui

XmlSource = Union[str, Path, bytes]

# --------------------------
# CSV description dictionary (optional)
# --------------------------
def _load_descriptions(csv_path: Path) -> Dict[str, str]:
    if not csv_path or not csv_path.exists():
        return {}
    with csv_path.open(newline='', encoding='utf-8') as f:
        rows = list(csv.reader(f))
    if not rows:
        return {}
    header = [h.strip().lower() for h in rows[0]]
    def find_col(cands: set[str]) -> Optional[int]:
        for n in cands:
            if n in header:
                return header.index(n)
        return None
    id_col = find_col({'id','element','key','code','x12_id','data element','data_element'})
    desc_col = find_col({'description','desc','meaning','name','long name','long_name'})
    start = 1 if (id_col is not None or desc_col is not None) else 0
    d: Dict[str, str] = {}
    for r in rows[start:]:
        if not r:
            continue
        if id_col is None or desc_col is None:
            if len(r) >= 2:
                k, v = r[0].strip(), r[1].strip()
            else:
                continue
        else:
            if max(id_col, desc_col) >= len(r):
                continue
            k, v = r[id_col].strip(), r[desc_col].strip()
        if k:
            d[k] = v
    return d

def _get_desc(key: str, descs: Dict[str, str]) -> Optional[str]:
    if not key:
        return None
    if key in descs and descs[key]:
        return descs[key]
    if '-' in key:  # e.g., SVC01-02 -> SVC01
        base = key.split('-')[0].strip()
        if base in descs and descs[base]:
            return descs[base]
    return None

def _label(id_or_tag: str, text: Optional[str], descs: Dict[str, str]) -> str:
    parts: List[str] = []
    if id_or_tag:
        parts.append(id_or_tag)
        d = _get_desc(id_or_tag, descs)
        if d:
            parts.append(f'— {d}')
    label = ' '.join(parts) if parts else ''
    t = (text or '').strip()
    if t:
        if len(t) > 80:
            t = t[:77] + '…'
        label = f'{label}: {t}' if label else t
    return label or id_or_tag or ''

# --------------------------
# Helpers to find transaction code and ISA root
# --------------------------
def _transaction_code(root: ET.Element) -> str:
    """Try to read ST01 (e.g., 837) under seg id='ST'."""
    st = root.find(".//seg[@id='ST']")
    if st is not None:
        st01 = st.find(".//element[@id='ST01']")
        if st01 is not None and st01.text and st01.text.strip():
            return st01.text.strip()
    return 'X12'

def _isa_roots(root: ET.Element) -> List[ET.Element]:
    isa = root.findall(".//loop[@id='ISA_LOOP']")
    if not isa:
        isa = root.findall(".//*[@id='ISA_LOOP']")
    return isa

# --------------------------
# Tree builder (PATH = joined @id attributes)
# --------------------------
def _build_children_by_id(parent: ET.Element,
                          prefix_path: str,
                          descs: Dict[str, str]) -> List[Dict[str, Any]]:
    """Each path segment comes from element @id if present, else tag; index only when needed."""
    children = list(parent)
    seg_names = [(ch.get('id') or ch.tag) for ch in children]

    counts: Dict[str, int] = defaultdict(int)
    for name in seg_names:
        counts[name] += 1

    seen: Dict[str, int] = defaultdict(int)
    nodes: List[Dict[str, Any]] = []

    for ch in children:
        seg = ch.get('id') or ch.tag
        seen[seg] += 1
        seg_for_path = f'{seg}[{seen[seg]}]' if counts[seg] > 1 else seg
        path = f'{prefix_path}/{seg_for_path}' if prefix_path else seg_for_path

        lbl_id = ch.get('id') or ch.tag
        lbl_text = (ch.text or '').strip()
        label = _label(lbl_id, lbl_text, descs)

        nodes.append({
            'id': path,  # selection key = human path you want
            'label': label,
            'children': _build_children_by_id(ch, path, descs),
        })
    return nodes

def _nodes_from_root(root: ET.Element, descs: Dict[str, str]) -> List[Dict[str, Any]]:
    tx = _transaction_code(root)  # e.g., '837'
    isa = _isa_roots(root)

    if isa:
        top = {'id': tx, 'label': tx, 'children': []}
        for loop in isa:
            seg_name = loop.get('id') or loop.tag  # expected 'ISA_LOOP'
            loop_path = f'{tx}/{seg_name}'
            top['children'].append({
                'id': loop_path,
                'label': _label(seg_name, (loop.text or '').strip(), descs),
                'children': _build_children_by_id(loop, loop_path, descs),
            })
        return [top]

    # fallback: mount entire document under tx
    root_seg = (root.get('id') or root.tag)
    base = f'{tx}/{root_seg}'
    top = {
        'id': tx,
        'label': tx,
        'children': [{
            'id': base,
            'label': _label(root_seg, (root.text or '').strip(), descs),
            'children': _build_children_by_id(root, base, descs),
        }],
    }
    return [top]

# --------------------------
# Public API (accepts file path OR XML string)
# --------------------------
def xml_tree_gen(xml_source: XmlSource,
                 *,
                 is_text: bool = False,
                 csv_path: Union[str, Path] = Path("tools/edi_835_elements.csv")) -> ui.tree:
    """
    Build a NiceGUI ui.tree from either:
      - xml_source = XML STRING (set is_text=True), or
      - xml_source = file path (default).

    Node 'id' is a path of @id attributes (e.g., 837/ISA_LOOP/GS_LOOP/.../N4/N403).
    Visible label is "<id — description : text>".
    """
    # Load descriptions
    csv_path = Path(csv_path) if csv_path else Path("tools/edi_835_elements.csv")
    descs = _load_descriptions(csv_path)

    # Parse XML
    if isinstance(xml_source, (bytes, bytearray)):
        root = ET.fromstring(xml_source)  # bytes implies text
    elif is_text:
        root = ET.fromstring(xml_source)  # xml_source is XML text
    else:
        # Treat as a path unless told otherwise; if path doesn't exist, fall back to parsing as text
        p = Path(str(xml_source))
        if p.exists():
            root = ET.parse(p).getroot()
        else:
            root = ET.fromstring(str(xml_source))

    nodes = _nodes_from_root(root, descs)

    t = ui.tree(
        nodes=nodes,
        label_key='label',
        node_key='id',          # selection key = our id-path
        children_key='children',
        # selection=True,
        tick_strategy='none',
    ).classes('w-full')
    return t
