import xml.etree.ElementTree as ET
import json
import re
from pathlib import Path

def find_elements_by_path(start_node, path):
    """
    Finds XML elements based on a simplified dot-notation path, handling filters.
    Example path: "loop.2300.seg.REF[REF01='G1'].ele.REF02"
    """
    if start_node is None:
        return []

    current_nodes = [start_node]
    parts = path.split('.')

    for part in parts:
        next_nodes = []
        
        # Parse the part for tag, ID, and filter conditions
        tag_match = re.match(r"^(loop|seg|ele|comp|subele)", part)
        tag = tag_match.group(1) if tag_match else None
        
        filter_match = re.search(r"\[(.+?)=.?\'(.+?)\'.?\]", part)
        main_id = part.split('[')[0] if filter_match else part

        # If the tag isn't explicit, derive it from the ID
        if not tag:
            if main_id.lower() in ['loop', 'seg', 'ele', 'comp', 'subele']:
                 tag = main_id.lower()
                 main_id = '' # No specific ID, just the tag
            else:
                 # Default to 'seg' for things like 'HI' or 'NM1'
                 tag = 'seg'
        
        id_from_tag = main_id.replace(tag, '', 1).lstrip('.') if tag else main_id
        
        for node in current_nodes:
            # Construct a search path
            search_path = f"./{tag}" if id_from_tag else f"./{tag}"
            if id_from_tag:
                 search_path += f"[@id='{id_from_tag}']"

            found_children = node.findall(search_path)
            
            if filter_match:
                filter_key, filter_val = filter_match.groups()
                # Apply the filter after finding potential candidates
                for child in found_children:
                    key_node = child.find(f".//ele[@id='{filter_key}']")
                    if key_node is not None and key_node.text and key_node.text.strip() == filter_val:
                        next_nodes.append(child)
            else:
                next_nodes.extend(found_children)
        current_nodes = next_nodes
    return current_nodes


def get_value(context_nodes, edi_path):
    """
    Extracts a value from the XML using the edi_path and the correct starting context.
    """
    if not edi_path or edi_path == 'N/A' or isinstance(edi_path, dict):
        return ""

    # --- Handle special syntaxes first ---
    if ' + ' in edi_path:
        parts = edi_path.split(' + ')
        results = [get_value(context_nodes, p.strip()) for p in parts]
        return " ".join(filter(None, results))

    if edi_path.startswith("exists("):
        path_to_check = edi_path[7:-1]
        return "Yes" if get_value(context_nodes, path_to_check) else "No"
    
    # --- Determine starting node and make path relative ---
    start_node = None
    relative_path = edi_path
    
    if 'service_line' in context_nodes and 'loop.2400' in edi_path:
        start_node = context_nodes['service_line']
        relative_path = edi_path.split('loop.2400.', 1)[1]
    # Handle paths relative to the claim but outside a service line
    elif 'loop.24' in edi_path and 'claim' in context_nodes:
        start_node = context_nodes['claim']
        relative_path = edi_path.split('loop.2300.', 1)[-1]
    elif edi_path.startswith("loop.2000A"):
        start_node = context_nodes['billing_provider']
        relative_path = edi_path.replace("loop.2000A.", "", 1)
    elif edi_path.startswith("loop.2000B"):
        start_node = context_nodes['subscriber']
        relative_path = edi_path.replace("loop.2000B.", "", 1)
    elif edi_path.startswith("loop.2300"):
        start_node = context_nodes['claim']
        relative_path = edi_path.replace("loop.2300.", "", 1)
    
    # --- Process path options ---
    path_options = relative_path.split('|')
    final_texts = []

    for option in path_options:
        nodes = find_elements_by_path(start_node, option.strip())
        for node in nodes:
            # For segments, we often want to concatenate all meaningful text
            if node.tag == 'seg':
                 texts = [
                    elem.text.strip() for elem in node.iter() 
                    if elem.text and elem.text.strip() and elem.tag in ('ele', 'subele')
                 ]
                 if texts:
                     final_texts.append(" ".join(texts))
            elif node.text:
                final_texts.append(node.text.strip())

    return ", ".join(final_texts)


def generate_html_report(edi_map_file, xml_file):
    """
    Parses the 837 XML based on the JSON map and generates an HTML report.
    """
    with open(edi_map_file, 'r') as f:
        edi_map = json.load(f)

    tree = ET.parse(xml_file)
    root = tree.getroot()

    # --- Find top-level loops ---
    billing_provider_loop = root.find(".//loop[@id='2000A']")
    detail_loop = root.find(".//loop[@id='DETAIL']")
    subscriber_loops = detail_loop.findall("./loop[@id='2000B']") if detail_loop else []

    html = """
    <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>EDI 837P Claim Extraction</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 2em; background-color: #f4f7f6; color: #333; }
        h1 { color: #2c3e50; text-align: center; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
        .claim-container { border: 1px solid #dcdcdc; border-radius: 8px; margin-bottom: 2em; padding: 1.5em; background-color: #ffffff; box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
        .claim-title { color: #2980b9; border-bottom: 2px solid #e0e0e0; padding-bottom: 0.5em; margin-top: 0; }
        .data-table, .service-table { border-collapse: collapse; width: 100%; margin-top: 1em; }
        .data-table td, .service-table td, .service-table th { border: 1px solid #e0e0e0; padding: 10px; text-align: left; vertical-align: top; }
        .data-table td:first-child { font-weight: bold; width: 35%; background-color: #f8f9fa; }
        .service-table th { background-color: #34495e; color: white; }
        .service-table { font-size: 0.9em; }
        .no-claims { text-align: center; color: #c0392b; font-size: 1.2em; }
    </style>
    </head><body><h1>EDI 837P Claim Data Extraction Results</h1>
    """

    claim_count = 0
    for sub_loop in subscriber_loops:
        # Determine the context for the patient and claim
        patient_is_dependent = sub_loop.find("./loop[@id='2000C']") is not None
        claim_loop = sub_loop.find(".%s/loop[@id='2300']" % ("loop[@id='2000C']" if patient_is_dependent else ""))
        
        if not claim_loop:
            continue
        claim_count += 1
        
        context = {
            'billing_provider': billing_provider_loop,
            'subscriber': sub_loop,
            'claim': claim_loop
        }

        # Get title info
        patient_name = get_value(context, "loop.2000B.loop.2010BA.seg.NM1" if not patient_is_dependent else "loop.2000B.loop.2000C.loop.2010CA.seg.NM1")
        account_no = get_value(context, "loop.2300.seg.CLM.ele.CLM01")

        html += f"""
        <div class="claim-container">
            <h2 class="claim-title">Claim #{claim_count} &mdash; Patient: {patient_name} (Account: {account_no})</h2>
            <table class="data-table">
        """

        for field_info in edi_map:
            field_id = field_info['id']
            field_name = field_info['field_name']

            if field_id == 24: # --- Service Details Table ---
                html += f"<tr><td>{field_name}</td><td>"
                table_info = field_info
                headers = table_info['table_headers'].split('|')
                
                html += '<table class="service-table"><thead><tr>' + ''.join(f'<th>{h}</th>' for h in headers) + '</tr></thead><tbody>'

                service_line_loops = claim_loop.findall("./loop[@id='2400']")
                for sl_loop in service_line_loops:
                    html += '<tr>'
                    sl_context = {**context, 'service_line': sl_loop}
                    for header in headers:
                        cell_path = table_info['edi_path'].get(header)
                        cell_value = get_value(sl_context, cell_path)
                        html += f'<td>{cell_value}</td>'
                    html += '</tr>'
                html += '</tbody></table></td></tr>'
            else: # --- All Other Fields ---
                value = get_value(context, field_info['edi_path'])
                html += f"<tr><td>{field_name}</td><td>{value}</td></tr>"

        html += "</table></div>"

    if claim_count == 0:
        html += "<div class='claim-container'><p class='no-claims'>No valid claims were found in the provided XML file.</p></div>"

    html += "</body></html>"
    return html


# --- Main Execution ---
if __name__ == "__main__":
    # Define file paths
    edi_map_filepath = Path('edi.837.p.info.corrected.json')
    xml_filepath = Path('/home/rathin/Github/projects/python-workspace/edi_gen_ai/workspace/edi_gen_ai/claims_upload/20250922-001412-0f4bc211/837_Chauhan_mod.xml')
    output_filepath = Path('/home/rathin/Github/projects/python-workspace/edi_gen_ai/workspace/edi_gen_ai/claims_upload/20250922-001412-0f4bc211/claims_extraction_report.html')

    try:
        # Generate the HTML content
        html_report = generate_html_report(edi_map_filepath, xml_filepath)

        # Save the output to an HTML file
        with open(output_filepath, 'w', encoding='utf-8') as f:
            f.write(html_report)

        print(f"Successfully generated the HTML report: '{output_filepath.name}'")

    except FileNotFoundError as e:
        print(f"Error: Could not find a required file. Please ensure '{e.filename}' is in the same directory.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")