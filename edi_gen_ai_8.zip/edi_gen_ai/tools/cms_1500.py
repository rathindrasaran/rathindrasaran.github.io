from typing import Dict
from nicegui import ui

# Dictionary to store form data
form_data = {
    "1_insurance_type": "",
    "1a_insured_id_number": "",
    "2_patient_name": "",
    "3_patient_birth_date": "",
    "3_patient_sex": "",
    "4_insured_name": "",
    "5_patient_address_street": "",
    "5_patient_address_city": "",
    "5_patient_address_state": "",
    "5_patient_address_zip": "",
    "5_patient_address_telephone": "",
    "6_patient_relationship": "",
    "7_insured_address_street": "",
    "7_insured_address_city": "",
    "7_insured_address_state": "",
    "7_insured_address_zip": "",
    "8_reserved_for_nucc_use": "",
    "9_other_insured_name": "",
    "9a_other_insured_policy_number": "",
    "9b_reserved_for_nucc_use": "",
    "9c_reserved_for_nucc_use": "",
    "9d_insurance_plan_name": "",
    "10a_employment": "",
    "10b_auto_accident": "",
    "10b_auto_accident_place": "",
    "10c_other_accident": "",
    "10d_claim_codes": "",
    "11_insured_policy_group_or_feca_number": "",
    "11a_insured_birth_date": "",
    "11a_insured_sex": "",
    "11b_other_claim_id": "",
    "11c_insurance_plan_name": "",
    "11d_is_there_another_health_benefit_plan": "",
    "12_patient_signature": "",
    "12_date": "",
    "13_insured_signature": "",
    "14_date_of_current_illness": "",
    "14_qual": "",
    "15_other_date": "",
    "15_qual": "",
    "16_dates_patient_unable_to_work_from": "",
    "16_dates_patient_unable_to_work_to": "",
    "17_name_of_referring_provider": "",
    "17_qualifier":"",
    "17a_qual": "",
    "17a_identifier": "",
    "17b_npi": "",
    "18_hospitalization_dates_from": "",
    "18_hospitalization_dates_to": "",
    "19_additional_claim_information": "",
    "20_outside_lab": "",
    "20_charges": "",
    "21_diagnosis_a": "",
    "21_diagnosis_b": "",
    "21_diagnosis_c": "",
    "21_diagnosis_d": "",
    "21_diagnosis_e": "",
    "21_diagnosis_f": "",
    "21_diagnosis_g": "",
    "21_diagnosis_h": "",
    "21_diagnosis_i": "",
    "21_diagnosis_j": "",
    "21_diagnosis_k": "",
    "21_diagnosis_l": "",
    "21_icd_ind_1": "",
    "21_icd_ind_2": "",
    "22_resubmission_code": "",
    "22_original_ref_no": "",
    "23_prior_authorization_number": "",
    "25_federal_tax_id_number": "",
    "25_ssn": False,
    "25_ein": False,
    "26_patients_account_no": "",
    "27_accept_assignment": False,
    "28_total_charge": "",
    "29_amount_paid": "",
    "30_reserved_for_nucc_use": "",
    "31_signature_of_physician": "",
    "31_date": "",
    "32_service_facility_location_information_a": "",
    "32_service_facility_location_information_b": "",
    "32_service_facility_location_information_c": "",
    "33_billing_provider_info_and_ph": "",
    "33_billing_provider_info_and_ph_a": "",
    "33_billing_provider_info_and_ph_b": "",
    "33_billing_provider_info_and_ph_c": ""
}

form_data['service_lines'] = []
service_lines_container = None

def create_form( func_filter_name_contains ):
    """Creates the CMS-1500 form using NiceGUI."""
    global service_lines_container
    with ui.row().classes('-m-4 p-0 w-full scroll-m-0'):
        # Header
        with ui.row().classes('w-full items-center no-wrap'):
            ui.label('CMS-1500 FORM VIEW').classes('text-lg font-bold text-red-700 ml-2')
            ui.space()
            ui.label('PICA').classes('text-xs mr-2')

        # Section 1: Patient and Insured Information
        with ui.grid(columns=3).classes('w-full gap-0'):
            with ui.column().classes('col-span-2 gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.toggle({
                        'MEDICARE':'MEDICARE','MEDICAID':'MEDICAID',
                        'TRICARE':'TRICARE','CHAMPVA':'CHAMPVA',
                        'GROUP HEALTH PLAN':'GROUP HEALTH PLAN',
                        'FECA BLK LUNG':'FECA BLK LUNG','OTHER':'OTHER'}
                    ).bind_value(form_data, '1_insurance_type').on('Click',lambda:func_filter_name_contains(form_data["1_insurance_type_filter"]))
            with ui.column().classes('gap-1 border  border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input(label="1a. INSURED'S I.D. NUMBER").bind_value(form_data, '1a_insured_id_number').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data["1a_insured_id_number_filter"]))

        with ui.grid(columns=3).classes('w-full gap-0'):
            with ui.column().classes('gap-1 border border-red-700'):
                # ui.input(label="2. PATIENT'S NAME (Last Name, First Name, Middle Initial)").bind_value(form_data, '2_patient_name').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['2_patient_name_filter']))
                with ui.row().classes('w-full no-wrap gap-0'):
                    ui.input(label="2. PATIENT'S LAST NAME").bind_value(form_data, '2_patient_lname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['2_patient_lname_filter']))
                    ui.input(label="FIRST NAME").bind_value(form_data, '2_patient_fname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['2_patient_fname_filter']))
                    ui.input(label="MIDDLE INIT").bind_value(form_data, '2_patient_mname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['2_patient_mname_filter']))
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.grid(columns=2).classes('w-full gap-0'):
                    with ui.column().classes('gap-0'):
                        ui.label("3. PATIENT\'S BIRTH DATE")
                        with ui.input(label="MM / DD / YYYY").bind_value(form_data, '3_patient_birth_date').props('flat outlined dense').classes('w-full') as patients_dob:
                            patients_dob.on('Click',lambda:func_filter_name_contains(form_data['3_patient_birth_date_filter']))
                            with ui.menu().props('no-parent-event') as menu:
                                with ui.date(mask="MM/DD/YYYY").bind_value(patients_dob):
                                    with ui.row().classes('justify-end'):
                                        ui.button('Close', on_click=menu.close).props('flat')
                            with patients_dob.add_slot('append'):
                                ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

                    with ui.column().classes('items-center gap-0'):
                        ui.label('SEX')
                        ui.toggle({'M':'MALE','F':'FEMALE'}).bind_value(form_data, '3_patient_sex').on('Click',lambda:func_filter_name_contains(form_data['3_patient_sex_filter']))
            with ui.column().classes('gap-1 border border-red-700'):
                # ui.input(label="4. INSURED'S NAME (Last Name, First Name, Middle Initial)").bind_value(form_data, '4_insured_name').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['4_insured_name_filter']))
                with ui.row().classes('w-full no-wrap gap-0'):
                    ui.input(label="2. INSURED'S LAST NAME").bind_value(form_data, '4_insured_lname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['4_insured_lname_filter']))
                    ui.input(label="FIRST NAME").bind_value(form_data, '4_insured_fname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['4_insured_fname_filter']))
                    ui.input(label="MIDDLE INIT").bind_value(form_data, '4_insured_mname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['4_insured_mname_filter']))

        with ui.grid(columns=3).classes('w-full gap-0'):
            with ui.column().classes('gap-1 border border-red-700'):
                ui.input(label="5. PATIENT'S ADDRESS (No., Street)").bind_value(form_data, '5_patient_address_street').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['5_patient_address_street_filter']))
                with ui.row().classes('no-wrap'):
                    ui.input(label="CITY").bind_value(form_data, '5_patient_address_city').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['5_patient_address_city_filter']))
                    ui.input(label="STATE").bind_value(form_data, '5_patient_address_state').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['5_patient_address_state_filter']))
                with ui.row().classes('no-wrap'):
                    ui.input(label="ZIP CODE").bind_value(form_data, '5_patient_address_zip').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['5_patient_address_zip_filter']))
                    ui.input(label="TELEPHONE (Include Area Code)").bind_value(form_data, '5_patient_address_telephone').props('flat outlined dense').classes('w-full')
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.grid(columns=1).classes('w-full gap-0'):
                    with ui.column().classes('items-center'):
                        ui.label('6. PATIENT RELATIONSHIP TO INSURED')
                        ui.toggle({'SELF':'SELF','SPOUSE':'SPOUSE','CHILD':'CHILD','OTHER':'OTHER'}).bind_value(form_data, '6_patient_relationship').on('Click',lambda:func_filter_name_contains(form_data['6_patient_relationship_filter']))
                with ui.grid(columns=1).classes('w-full gap-0'):
                    with ui.column().classes('items-center'):
                        ui.input("8. RESERVED FOR NUCC USE").props('flat outlined dense').classes('w-full')
            with ui.column().classes('gap-1 border border-red-700'):
                ui.input(label="7. INSURED'S ADDRESS (No., Street)").bind_value(form_data, '7_insured_address_street').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['7_insured_address_street_filter']))
                with ui.row().classes('no-wrap'):
                    ui.input(label="CITY").bind_value(form_data, '7_insured_address_city').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['7_insured_address_city_filter']))
                    ui.input(label="STATE").bind_value(form_data, '7_insured_address_state').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['7_insured_address_state_filter']))
                ui.input(label="ZIP CODE").bind_value(form_data, '7_insured_address_zip').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['7_insured_address_zip_filter']))

        with ui.grid(columns=3).classes('w-full gap-1'):
            with ui.column().classes('gap-1 border border-red-700'):
                # ui.input(label="9. OTHER INSURED'S NAME (Last Name, First Name, Middle Initial)").bind_value(form_data, '9_other_insured_name').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['9_other_insured_name_filter']))
                with ui.row().classes('w-full no-wrap gap-0'):
                    ui.input(label="9. OTHER INSURED'S LAST NAME").bind_value(form_data, '9_other_insured_lname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['9_other_insured_lname_filter']))
                    ui.input(label="FIRST NAME").bind_value(form_data, '9_other_insured_fname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['9_other_insured_fname_filter']))
                    ui.input(label="MIDDLE INIT").bind_value(form_data, '9_other_insured_mname').props('flat outlined dense').classes('w-1/3').on('Click',lambda:func_filter_name_contains(form_data['9_other_insured_mname_filter']))

                ui.input(label="a. OTHER INSURED'S POLICY OR GROUP NUMBER").bind_value(form_data, '9a_other_insured_policy_number').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['9a_other_insured_policy_number_filter']))
                ui.input(label="b. RESERVED FOR NUCC USE").bind_value(form_data, '9b_reserved_for_nucc_use').props('flat outlined dense').classes('w-full')
                ui.input(label="c. RESERVED FOR NUCC USE").bind_value(form_data, '9c_reserved_for_nucc_use').props('flat outlined dense').classes('w-full')
                ui.input("").props('flat outlined dense').classes('w-full')
                ui.input(label="d. INSURANCE PLAN NAME OR PROGRAM NAME").bind_value(form_data, '9d_insurance_plan_name').props('flat outlined dense').classes('w-full').on('Click',lambda:func_filter_name_contains(form_data['9d_insurance_plan_name_filter']))
            with ui.column().classes('gap-1 border border-red-700'):
                ui.label("10. IS PATIENT'S CONDITION RELATED TO:")
                with ui.row():
                    ui.label("a. EMPLOYMENT? (Current or Previous)")
                with ui.row():
                    ui.toggle({'Y':'YES','N':'NO'}).bind_value(form_data, '10a_employment').on('Click',lambda:func_filter_name_contains(form_data['10a_employment_filter']))
                with ui.row():
                    ui.label("b. AUTO ACCIDENT?")
                with ui.row():
                    ui.toggle({'Y':'YES','N':'NO'}).bind_value(form_data, '10b_auto_accident').on('Click',lambda:func_filter_name_contains(form_data['10b_auto_accident_filter']))
                    ui.input(label="PLACE (State)").bind_value(form_data, '10b_auto_accident_place').props('flat dense outlined').on('Click',lambda:func_filter_name_contains(form_data['10b_auto_accident_place_filter']))
                with ui.row():
                    ui.label("c. OTHER ACCIDENT?")
                with ui.row():
                    ui.toggle({'Y':'YES','N':'NO'}).bind_value(form_data, '10c_other_accident').on('Click',lambda:func_filter_name_contains(form_data['10c_other_accident_filter']))

                ui.input(label="10d. CLAIM CODES (Designated by NUCC)").bind_value(form_data, '10d_claim_codes').props('flat outlined dense').classes('w-full')

            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center w-full gap-1'):
                    ui.input(label="11. INSURED'S POLICY GROUP OR FECA NUMBER").bind_value(form_data, '11_insured_policy_group_or_feca_number').props('flat outlined dense').classes('w-full')
                with ui.row().classes('items-center w-full gap-1'):
                    with ui.input(label="a. INSURED\'S DATE OF BIRTH (MM/DD/YYYY)").bind_value(form_data, '11a_insured_birth_date').props('flat outlined dense').classes('w-full') as insureds_dob:
                            with ui.menu().props('no-parent-event') as menu:
                                with ui.date(mask="MM/DD/YYYY").bind_value(insureds_dob):
                                    with ui.row().classes('justify-end'):
                                        ui.button('Close', on_click=menu.close).props('flat')
                            with insureds_dob.add_slot('append'):
                                ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

                with ui.row().classes('items-center w-full gap-1'):
                    ui.label('SEX')
                    ui.toggle({'MALE':'MALE','FEMALE':'FEMALE'}).bind_value(form_data, '11a_insured_sex')
                ui.input(label="b. OTHER CLAIM ID (Designated by NUCC)").bind_value(form_data, '11b_other_claim_id').props('flat outlined dense').classes('w-full')
                ui.input(label="c. INSURANCE PLAN NAME OR PROGRAM NAME").bind_value(form_data, '11c_insurance_plan_name').props('flat outlined dense').classes('w-full')
                with ui.row():
                    ui.label("d. IS THERE ANOTHER HEALTH BENEFIT PLAN?")
                with ui.row():
                    ui.toggle({'YES':'YES','NO':'NO'}).bind_value(form_data, '11d_is_there_another_health_benefit_plan')

# section 14 - 18
        with ui.grid(columns=3).classes('w-full gap-0'):
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("14. DATE OF CURRENT ILLNESS, INJURY, or PREGNANCY (LMP)")
                with ui.row().classes('items-center no-wrap w-full'):
                    with ui.input(label="(MM / DD / YYYY)").bind_value(form_data, '14_date_of_current_illness').props('flat outlined dense').classes('w-full') as current_illness_date:
                            with ui.menu().props('no-parent-event') as menu:
                                with ui.date(mask="MM/DD/YYYY").bind_value(current_illness_date):
                                    with ui.row().classes('justify-end'):
                                        ui.button('Close', on_click=menu.close).props('flat')
                            with current_illness_date.add_slot('append'):
                                ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

                    ui.input(label="QUAL.").bind_value(form_data, '14_qual').props('flat outlined dense')
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("15. OTHER DATE")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input(label="QUAL.").bind_value(form_data, '15_qual').props('flat outlined dense').style('width: 60px;')
                    with ui.input(label="(MM / DD / YYYY)").bind_value(form_data, '15_other_date').props('flat outlined dense').classes('w-full') as other_date:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(other_date):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with other_date.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("16. DATES PATIENT UNABLE TO WORK IN CURRENT OCCUPATION")
                with ui.row().classes('items-center no-wrap w-full'):
                    with ui.input(label="FROM (MM/DD/YYYY)").bind_value(form_data, '16_dates_patient_unable_to_work_from').props('flat outlined dense') as dates_patient_unable_to_work_from:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(dates_patient_unable_to_work_from):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with dates_patient_unable_to_work_from.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')
                    with ui.input(label="TO (MM/DD/YYYY)").bind_value(form_data, '16_dates_patient_unable_to_work_to').props('flat outlined dense') as dates_patient_unable_to_work_to:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(dates_patient_unable_to_work_to):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with dates_patient_unable_to_work_to.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')


        with ui.grid(columns=3).classes('w-full gap-0'):
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("17. NAME OF REFERRING PROVIDER OR OTHER SOURCE")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input(label="").bind_value(form_data, '17_qualifier').props('flat outlined dense').style('width: 60px;')
                    ui.input(label="REFERRING PROVIDER OR OTHER SOURCE").bind_value(form_data, '17_name_of_referring_provider').props('flat outlined dense').classes('w-full')
            with ui.column().classes('gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("17a.")
                    ui.input(label="QUAL").bind_value(form_data, '17a_qual').props('flat outlined dense').style('width: 60px;')
                    ui.input(label="LEGACY IDENTIFIER").bind_value(form_data, '17a_identifier').props('flat outlined dense').classes('w-full')
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("17b.")
                    ui.input(label="NPI NUMBER").bind_value(form_data, '17b_npi').props('flat outlined dense').classes('w-full')
            with ui.column().classes('gap-1 border border-red-700'):
                ui.label("18. HOSPITALIZATION DATES RELATED TO CURRENT SERVICES")
                with ui.row().classes('items-center no-wrap'):
                    with ui.input(label="FROM (MM/DD/YYYY)").bind_value(form_data, '18_hospitalization_dates_from').props('flat outlined dense') as hospitalization_dates_from:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(hospitalization_dates_from):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with hospitalization_dates_from.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

                    with ui.input(label="TO (MM/DD/YYYY)").bind_value(form_data, '18_hospitalization_dates_to').props('flat outlined dense') as hospitalization_dates_to:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(hospitalization_dates_to):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with hospitalization_dates_to.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

# section 19 to 23

        # Sections 19-23
        with ui.grid(columns=3).classes('w-full gap-0'):
            # Box 19 spans 2 columns
            with ui.column().classes('col-span-2 gap-1 border border-red-700'):
                ui.input(label="19. ADDITIONAL CLAIM INFORMATION (Designated by NUCC)").bind_value(form_data, '19_additional_claim_information').props('flat outlined dense').classes('w-full')
            # Box 20
            with ui.column().classes('col-span-1 gap-1 border border-red-700'):
                with ui.row().classes('items-center no-wrap'):
                    ui.label("20. OUTSIDE LAB?")
                    ui.toggle({'YES':'YES','NO':'NO'}).bind_value(form_data, '20_outside_lab')
                    ui.input(label="$ CHARGES").bind_value(form_data, '20_charges').props('flat outlined dense')

        with ui.grid(columns=3).classes('w-full gap-0 border border-red-700'):
            # Box 21 spans 2 columns
            with ui.column().classes('col-span-2 gap-1 border border-red-700 w-full'):
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.label("21. DIAGNOSIS OR NATURE OF ILLNESS OR INJURY")
                    ui.space()
                    ui.input(label="ICD-Ind.").bind_value(form_data, '21_icd_ind_1').props('flat outlined dense').style('width: 80px;')
                    ui.input(label="ICD-Ind.").bind_value(form_data, '21_icd_ind_2').props('flat outlined dense').style('width: 80px;')
                with ui.grid(columns=4).classes('w-full gap-x-4'):
                    ui.input(label="A.").bind_value(form_data, '21_diagnosis_a').props('flat outlined dense')
                    ui.input(label="B.").bind_value(form_data, '21_diagnosis_b').props('flat outlined dense')
                    ui.input(label="C.").bind_value(form_data, '21_diagnosis_c').props('flat outlined dense')
                    ui.input(label="D.").bind_value(form_data, '21_diagnosis_d').props('flat outlined dense')
                    ui.input(label="E.").bind_value(form_data, '21_diagnosis_e').props('flat outlined dense')
                    ui.input(label="F.").bind_value(form_data, '21_diagnosis_f').props('flat outlined dense')
                    ui.input(label="G.").bind_value(form_data, '21_diagnosis_g').props('flat outlined dense')
                    ui.input(label="H.").bind_value(form_data, '21_diagnosis_h').props('flat outlined dense')
                    ui.input(label="I.").bind_value(form_data, '21_diagnosis_i').props('flat outlined dense')
                    ui.input(label="J.").bind_value(form_data, '21_diagnosis_j').props('flat outlined dense')
                    ui.input(label="K.").bind_value(form_data, '21_diagnosis_k').props('flat outlined dense')
                    ui.input(label="L.").bind_value(form_data, '21_diagnosis_l').props('flat outlined dense')

            # Boxes 22 and 23 are in the 3rd column, stacked
            with ui.column().classes('col-span-1 gap-0'):
                # Box 22
                with ui.row().classes('items-center no-wrap border border-red-700 w-full'):
                    ui.input(label="22. RESUBMISSION CODE").bind_value(form_data, '22_resubmission_code').props('flat outlined dense')
                    ui.input(label="ORIGINAL REF. NO.").bind_value(form_data, '22_original_ref_no').props('flat outlined dense')
                # Box 23
                with ui.row().classes('items-center no-wrap border border-red-700 w-full'):
                    ui.input(label="23. PRIOR AUTHORIZATION NUMBER").bind_value(form_data, '23_prior_authorization_number').props('flat outlined dense').classes('w-full')

# Section 24: Procedures, Services, or Supplies
        with ui.element('div').classes('w-full border-2 border-red-700 p-1'):
            # HEADER ROW using a 24-column grid for precise alignment
            with ui.grid(columns=25).classes('w-full gap-x-1'):
                # A. DATE(S) OF SERVICE
                ui.label('24A. DATE(S) OF SERVICE').classes('col-span-6 text-center text-xs font-bold')
                # B. PLACE OF SERVICE
                ui.label('B. POS').classes('col-span-1 text-center text-xs font-bold')
                # C. EMG
                ui.label('C. EMG').classes('col-span-1 text-center text-xs font-bold')
                # D. PROCEDURES...
                ui.label('D. PROCEDURES, SERVICES, OR SUPPLIES').classes('col-span-6 text-center text-xs font-bold')
                # E. DIAGNOSIS POINTER
                ui.label('E. DIAG. PTR').classes('col-span-2 text-center text-xs font-bold')
                # F. $ CHARGES
                ui.label('F. $ CHARGES').classes('col-span-2 text-center text-xs font-bold')
                # G. DAYS OR UNITS
                ui.label('G. DAYS/UNITS').classes('col-span-1 text-center text-xs font-bold')
                # H. EPSDT
                ui.label('H. EPSDT').classes('col-span-1 text-center text-xs font-bold')
                # I. ID QUAL
                ui.label('I. ID QUAL').classes('col-span-1 text-center text-xs font-bold')
                # J. RENDERING PROVIDER ID
                ui.label('J. PROVIDER ID').classes('col-span-3 text-center text-xs font-bold')
                ui.label('').classes('col-span-1') # Placeholder for delete

            # Container to hold the dynamically added service line rows
            service_lines_container = ui.column().classes('w-full gap-0')

            # Button to add more service lines
            with ui.row().classes('w-full mt-2'):
                ui.space()
                ui.button('(+) Add Service Line', on_click=lambda: add_service_line(None)).props('color=blue-700 outlined dense')

        # Sections 25-33
        with ui.grid(columns=6).classes('w-full gap-0'):
            # Box 25
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("25. FEDERAL TAX I.D. NUMBER")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input().bind_value(form_data, '25_federal_tax_id_number').props('flat outlined dense').classes('grow')
                    with ui.column().classes('gap-0'):
                        ui.checkbox('SSN').bind_value(form_data, '25_ssn').props('dense')
                        ui.checkbox('EIN').bind_value(form_data, '25_ein').props('dense')

            # Box 26
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("26. PATIENT'S ACCOUNT NO.")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input().bind_value(form_data, '26_patients_account_no').props('flat outlined dense').classes('w-full')

            # Box 27
            with ui.column().classes('border border-red-700 p-1 items-center'):
                ui.label("27. ACCEPT ASSIGNMENT?")
                ui.toggle({'YES':'YES','NO':'NO'}).bind_value(form_data, '27_accept_assignment')

            # Box 28
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("28. TOTAL CHARGE")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input().bind_value(form_data, '28_total_charge').props('flat outlined dense').classes('w-full')

            # Box 29
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("29. AMOUNT PAID")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input().bind_value(form_data, '29_amount_paid').props('flat outlined dense').classes('w-full')

            # Box 30
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("30. Rsvd. for NUCC Use")
                with ui.row().classes('items-center no-wrap w-full'):
                    ui.input().bind_value(form_data, '30_reserved_for_nucc_use').props('flat outlined dense').classes('w-full')


        with ui.grid(columns=3).classes('w-full gap-0'):
            # Box 31
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("31. SIGNATURE OF PHYSICIAN OR SUPPLIER")
                with ui.row().classes('items-center w-full'):
                    ui.input().bind_value(form_data, '31_signature_of_physician').props('flat outlined dense').classes('w-full')
                    with ui.input(label="DATE").bind_value(form_data, '31_date').props('flat outlined dense').classes('w-full') as physician_supplier_date:
                        with ui.menu().props('no-parent-event') as menu:
                            with ui.date(mask="MM/DD/YYYY").bind_value(physician_supplier_date):
                                with ui.row().classes('justify-end'):
                                    ui.button('Close', on_click=menu.close).props('flat')
                        with physician_supplier_date.add_slot('append'):
                            ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

            # Box 32
            with ui.column().classes('border border-red-700 p-1'):
                ui.label("32. SERVICE FACILITY LOCATION INFORMATION")
                with ui.row().classes('w-full no-wrap items-center'):
                    pass
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('a.').classes('font-bold mr-1')
                    ui.textarea().bind_value(form_data, '32_service_facility_location_information_a').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('b.').classes('font-bold mr-1')
                    ui.input(label="NPI").bind_value(form_data, '32_service_facility_location_information_b').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('c.').classes('font-bold mr-1')
                    ui.input(label="LEGACY ID").bind_value(form_data, '32_service_facility_location_information_c').props('flat outlined dense').classes('w-full')

            # Box 33
            with ui.column().classes('border border-red-700 p-1'):
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label("33. BILLING PROVIDER INFO & PH #").classes('w-3/5')
                    ui.input().bind_value(form_data, '33_billing_provider_info_and_ph').props('flat outlined dense').classes('w-2/5')
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('a.').classes('font-bold mr-1')
                    ui.textarea().bind_value(form_data, '33_billing_provider_info_and_ph_a').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('b.').classes('font-bold mr-1')
                    ui.input(label="NPI").bind_value(form_data, '33_billing_provider_info_and_ph_b').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full no-wrap items-center'):
                    ui.label('c.').classes('font-bold mr-1')
                    ui.input(label="LEGACY ID").bind_value(form_data, '33_billing_provider_info_and_ph_c').props('flat outlined dense').classes('w-full')


def create_service_line_row(line_data: Dict):
    if service_lines_container is None:
        return

    with service_lines_container:
        # Each service line is its own grid, matching the header's 25 columns
        with ui.grid(columns=25).classes('w-full gap-x-1 items-center border-t-2 border-red-200'):
            # A. DATE(S) OF SERVICE (spans 6 columns)
            with ui.row().classes('col-span-6 no-wrap w-full'):
                with ui.input(label="From").bind_value(line_data, 'date_of_service_from').props('maxlength=8 flat outlined dense').classes('w-1/2') as date_of_service_from:
                    with ui.menu().props('no-parent-event') as menu:
                        with ui.date(mask="MM/DD/YYYY").bind_value(date_of_service_from):
                            with ui.row().classes('justify-end'):
                                ui.button('Close', on_click=menu.close).props('flat')
                    with date_of_service_from.add_slot('append'):
                        ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')
                with ui.input(label="To").bind_value(line_data, 'date_of_service_to').props('maxlength=8 flat outlined dense').classes('w-1/2') as date_of_service_to:
                    with ui.menu().props('no-parent-event') as menu:
                        with ui.date(mask="MM/DD/YYYY").bind_value(date_of_service_to):
                            with ui.row().classes('justify-end'):
                                ui.button('Close', on_click=menu.close).props('flat')
                    with date_of_service_to.add_slot('append'):
                        ui.icon('edit_calendar').on('click', menu.open).classes('cursor-pointer')

            # B. PLACE OF SERVICE (spans 1 column, max 2 chars)
            ui.input().bind_value(line_data, 'place_of_service').props('maxlength=2 flat outlined dense').classes('w-full col-span-1')

            # C. EMG (spans 1 column, max 2 chars)
            ui.input().bind_value(line_data, 'emg').props('maxlength=2 flat outlined dense').classes('w-full col-span-1')

            # D. PROCEDURES, SERVICES, OR SUPPLIES (spans 6 columns)
            # This is a nested grid to hold CPT code + 4 modifiers
            with ui.grid(columns=6).classes('col-span-6 w-full gap-x-1'):
                ui.input(label="CPT/HCPCS").bind_value(line_data, 'procedures_cpt_hcpcs').props('flat outlined dense').classes('w-full col-span-2')
                ui.input(label="M1").bind_value(line_data, 'modifier_1').props('maxlength=2 flat outlined dense').classes('w-full')
                ui.input(label="M2").bind_value(line_data, 'modifier_2').props('maxlength=2 flat outlined dense').classes('w-full')
                ui.input(label="M3").bind_value(line_data, 'modifier_3').props('maxlength=2 flat outlined dense').classes('w-full')
                ui.input(label="M4").bind_value(line_data, 'modifier_4').props('maxlength=2 flat outlined dense').classes('w-full')

            # E. DIAGNOSIS POINTER (spans 2 columns)
            ui.input().bind_value(line_data, 'diagnosis_pointer').props('flat outlined dense').classes('w-full col-span-2')

            # F. $ CHARGES (spans 2 columns)
            ui.input().bind_value(line_data, 'charges').props('flat outlined dense').classes('w-full col-span-2')

            # G. DAYS OR UNITS (spans 2 columns)
            ui.input().bind_value(line_data, 'days_or_units').props('flat outlined dense').classes('w-full col-span-1')

            # H. EPSDT Family Plan (spans 1 column, max 2 chars)
            ui.input().bind_value(line_data, 'epsdt_family_plan').props('maxlength=2 flat outlined dense').classes('w-full col-span-1')

            # I. ID. QUAL. (spans 1 column, max 2 chars)
            ui.input().bind_value(line_data, 'id_qual').props('maxlength=2 flat outlined dense').classes('w-full col-span-1')

            # J. RENDERING PROVIDER ID. # (spans 4 columns, max 12 chars)
            ui.input(label="NPI").bind_value(line_data, 'rendering_provider_id_npi').props('maxlength=12 flat outlined dense').classes('w-full col-span-3')
            with ui.row().classes('col-span-1'):
                ui.button(icon='delete', on_click=lambda line_data=line_data: delete_service_line(line_data)).props('color=negative flat round dense').tooltip('Delete this service line')

async def delete_service_line(line_data_to_delete: Dict):
    """Shows a confirmation dialog and deletes the service line if confirmed."""
    with ui.dialog() as dialog, ui.card():
        ui.label('Are you sure you want to delete this service line?')
        with ui.row().classes('w-full justify-end'):
            ui.button('Cancel', on_click=lambda: dialog.submit(False), color='secondary')
            ui.button('Delete', on_click=lambda: dialog.submit(True), color='negative')

    confirmed = await dialog
    if confirmed:
        try:
            form_data['service_lines'].remove(line_data_to_delete)
            refresh_service_lines()
            ui.notify('Service line deleted.', color='positive')
        except ValueError:
            ui.notify('Error: Could not find the service line to delete.', color='negative')
def add_service_line(line_data: Dict = None):
    if line_data is None:
        line_data = {
            "date_of_service_from": "", "date_of_service_to": "", "place_of_service": "", "emg": "",
            "procedures_cpt_hcpcs": "", "modifier_1": "", "modifier_2": "", "modifier_3": "", "modifier_4": "",
            "diagnosis_pointer": "", "charges": "", "days_or_units": "", "epsdt_family_plan": "",
            "id_qual": "", "rendering_provider_id_npi": ""
        }
    form_data['service_lines'].append(line_data)
    create_service_line_row(line_data)

def refresh_service_lines():
    if service_lines_container:
        service_lines_container.clear()
        for sl in form_data['service_lines']:
            create_service_line_row(sl)


