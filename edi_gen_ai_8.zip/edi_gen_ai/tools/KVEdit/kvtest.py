from nicegui import ui
from KVEditor import make_xml_node_table

rows = [
    {"node-text": "Book", "text-value": "1984", "xml-path": "/library/fiction/book[1]/title"},
    {"node-text": "Author", "text-value": "George Orwell", "xml-path": "/library/fiction/book[1]/author"},
    {"node-text": "Book", "text-value": "Brave New World", "xml-path": "/library/fiction/book[2]/title"},
    {"node-text": "Author", "text-value": "Aldous Huxley", "xml-path": "/library/fiction/book[2]/author"},
    {"node-text": "Book", "text-value": "Sapiens", "xml-path": "/library/nonfiction/book[1]/title"},
    {"node-text": "Author", "text-value": "Yuval Noah Harari", "xml-path": "/library/nonfiction/book[1]/author"},
    {"node-text": "Book", "text-value": "The Martian", "xml-path": "/library/scifi/book[1]/title"},
    {"node-text": "Author", "text-value": "Andy Weir", "xml-path": "/library/scifi/book[1]/author"},
    {"node-text": "Book", "text-value": "To Kill a Mockingbird", "xml-path": "/library/classics/book[1]/title"},
    {"node-text": "Author", "text-value": "Harper Lee", "xml-path": "/library/classics/book[1]/author"},
    {"node-text": "Book", "text-value": "The Hobbit", "xml-path": "/library/fantasy/book[1]/title"},
    {"node-text": "Author", "text-value": "J.R.R. Tolkien", "xml-path": "/library/fantasy/book[1]/author"},
    {"node-text": "Book", "text-value": "Dune", "xml-path": "/library/scifi/book[2]/title"},
    {"node-text": "Author", "text-value": "Frank Herbert", "xml-path": "/library/scifi/book[2]/author"},
    {"node-text": "Book", "text-value": "The Catcher in the Rye", "xml-path": "/library/fiction/book[3]/title"},
    {"node-text": "Author", "text-value": "J.D. Salinger", "xml-path": "/library/fiction/book[3]/author"},
    {"node-text": "Book", "text-value": "The Art of War", "xml-path": "/library/philosophy/book[1]/title"},
    {"node-text": "Author", "text-value": "Sun Tzu", "xml-path": "/library/philosophy/book[1]/author"},
]

form_data = {
    "insurance": "",
    "license": ""
}
form_data["insurance"] = "Sun Tzu"
form_data["insurance_filter"] = "/library/philosophy/book[1]/author"

form_data["license"] = "Harper Lee"
form_data["license_filter"] = "/library/classics/book[1]/author"

table_handles = make_xml_node_table(rows,form_data)

ui.button('change val').on_click(lambda: table_handles["filter_value_changed"]("author"))
ui.button('clear').on_click(lambda: table_handles["filter_value_changed"](""))
ui.button('show changes').on_click(lambda: table_handles["get_changes"]())



temp_input = ui.input('Insurance').bind_value(form_data,"insurance")

lic_input = ui.input('License').bind_value(form_data,"license")

ui.run()