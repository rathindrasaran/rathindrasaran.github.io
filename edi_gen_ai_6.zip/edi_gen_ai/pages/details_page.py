# pages/details_page.py
import asyncio
import json
import logging
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Dict, List

from nicegui import ui, app

from tools.utils import directory_pdf, run_and_stream, log

# Configure logging
logging.basicConfig(level=logging.INFO)
BASE_DIR = Path(__file__).resolve().parent.parent


def create_json_editor(json_path: Path, parent_container: ui.element):
    """
    Creates an editor for a single JSON file, with a save button that is
    enabled only when changes are made.
    """
    try:
        with open(json_path, 'r') as f:
            initial_data = json.load(f)

        current_data = initial_data.copy()

        with parent_container:
            # Create a dictionary to hold the UI input elements
            inputs = {}

            def check_for_changes():
                """Enable save button only if data has changed."""
                for key in inputs:
                    current_data[key] = inputs[key].value
                save_button.enabled = (current_data != initial_data)

            # Create a two-column grid for the input fields
            with ui.grid(columns=2).classes('w-full gap-4'):
                for key, value in initial_data.items():
                    inputs[key] = ui.input(label=key, value=str(value), on_change=check_for_changes).props('outlined dense').classes('w-full')

            # The save button is initially disabled
            save_button = ui.button('Save', on_click=lambda: save_json(json_path, current_data)).props('outline').classes('mt-4')
            save_button.enabled = False

    except Exception as e:
        ui.label(f"Error loading {json_path.name}: {e}").classes('text-negative')


def save_json(json_path: Path, new_data: Dict):
    """
    Saves the modified data back to the JSON file and notifies the user.
    """
    try:
        # Before writing, ensure all values are of a consistent type, e.g., string
        # (or attempt to infer types if necessary)
        # For simplicity, we'll just dump, but for robustness, you might want type conversion
        with open(json_path, 'w') as f:
            json.dump(new_data, f, indent=4)
        
        # Notify user of success
        ui.notify(f'Successfully saved changes to {json_path.name}.', color='positive')
        
        # To reflect the new "saved" state, you might want to refresh the component
        # or at least disable the save button again. A full refresh is safer.
        directory_name = app.storage.user.get("details_directory")
        if directory_name:
            ui.navigate.to(f'/details/{directory_name}')
        else:
            # Fallback or error notification if directory_name is not found
            ui.notify("Could not refresh page: directory not found.", color='negative')

    except Exception as e:
        ui.notify(f'Error saving {json_path.name}: {e}', color='negative')


from nicegui import app


def create_details_json_editor(json_path: Path, parent_container: ui.element):
    """
    Creates an editor for a _details.json file, allowing editing of each line item.
    """
    try:
        with open(json_path, 'r') as f:
            initial_data = json.load(f)

        if not isinstance(initial_data, list):
            ui.label(f"Expected a list in {json_path.name}, but found {type(initial_data).__name__}.").classes('text-negative')
            return

        current_data = [item.copy() for item in initial_data]
        
        with parent_container:
            inputs = []

            def check_for_changes():
                """Enable save button if any line item has changed."""
                for i, item_inputs in enumerate(inputs):
                    for key in item_inputs:
                        current_data[i][key] = item_inputs[key].value
                save_button.enabled = (current_data != initial_data)

            for i, item in enumerate(initial_data):
                with ui.expansion(f"{i+1}: {item['PatientFirstName']} {item['PatientLastName']} ({item['LineItemPaidAmount']})", icon='description').classes('w-full mb-2'):
                    item_inputs = {}
                    # Create a two-column grid for the input fields
                    with ui.grid(columns=2).classes('w-full gap-4 p-4'):
                        for key, value in item.items():
                            item_inputs[key] = ui.input(label=key, value=str(value), on_change=check_for_changes).props('outlined dense').classes('w-full')
                    inputs.append(item_inputs)

            save_button = ui.button('Save Details', on_click=lambda: save_json(json_path, current_data)).props('outline').classes('mt-4')
            save_button.enabled = False

    except Exception as e:
        ui.label(f"Error loading {json_path.name}: {e}").classes('text-negative')


def create_combined_editor(basic_path: Path, details_path: Path, on_expansion_open, expansion_group: List, base_name: str):
    """
    Creates a single expansion panel with two tabs for editing _basic.json and _details.json.
    """
    
    # Create the expansion panel and add it to the group
    expansion = ui.expansion(base_name, icon='folder', group='editors').classes('w-full mb-4').props(f'id="{base_name}"')
    expansion.on('click', lambda: on_expansion_open(base_name))
    expansion_group.append(expansion)

    with expansion:
        with ui.tabs().props('dense') as tabs:
            ui.tab('Basic Info')
            ui.tab('Detailed Info')
        
        with ui.tab_panels(tabs, value='Basic Info').classes('w-full'):
            with ui.tab_panel('Basic Info'):
                create_json_editor(basic_path, ui.element('div'))
            with ui.tab_panel('Detailed Info'):
                create_details_json_editor(details_path, ui.element('div'))


@ui.page('/details/{directory_name}')
def page(directory_name: str):
    app.storage.user['details_directory'] = directory_name
    directory_path = BASE_DIR / 'uploads' / directory_name
    
    path = Path(directory_path)
    image_files = sorted(path.glob('*.jpg'))
    num_images = len(image_files)
    image_base_names = [p.stem for p in image_files]
    
    # Central state for the current page
    current_page = 1
    expansion_panels = []

    # --- UI Elements ---
    page_number_input = None
    back_button = None
    next_button = None
    image_container = None

    def update_ui_for_page_change():
        """Updates all relevant UI components when the page changes."""
        nonlocal current_page
        
        # Update image source
        if 1 <= current_page <= num_images:
            # Update the image source
            web_path = f"/uploads/{directory_name}/{image_files[current_page - 1].name}"
            if image_container:
                image_container.set_source(web_path)

            # Open the corresponding expansion panel
            if expansion_panels and 0 <= current_page - 1 < len(expansion_panels):
                for i, panel in enumerate(expansion_panels):
                    if i == current_page - 1:
                        panel.open()
                    else:
                        panel.close()
        
        # Update input field
        if page_number_input:
            page_number_input.set_value(current_page)

        # Update button states
        if back_button:
            back_button.props(f'disable={current_page == 1}')
        if next_button:
            next_button.props(f'disable={current_page == num_images}')

    def show_page(page_number: int):
        """Go to a specific page number and update the UI."""
        nonlocal current_page
        if page_number is None:
            return
            
        page_number=int(page_number)
        if 1 <= page_number <= num_images:
            current_page = page_number
            update_ui_for_page_change()

    def handle_expansion_open(base_name: str):
        """When an expansion panel is clicked, find its page and go to it."""
        try:
            target_index = image_base_names.index(base_name)
            show_page(target_index + 1)
        except ValueError:
            logging.warning(f"Could not find an image for base_name '{base_name}'")

    def handle_expansion_open(base_name: str):
        """When an expansion panel is clicked, find its page and go to it."""
        try:
            target_index = image_base_names.index(base_name)
            show_page(target_index + 1)
            
            # Scroll the element to the top
            ui.run_javascript(f"""
                const element = document.getElementById('{base_name}');
                if (element) {{
                    element.scrollIntoView({{ behavior: 'smooth', block: 'start' }});
                }}
            """)
        except ValueError:
            logging.warning(f"Could not find an image for base_name '{base_name}'")

    # --- Header and Navigation ---
    with ui.header(elevated=True).classes('bg-white text-gray-800 q-pa-md'):
        with ui.row().classes('w-full items-center justify-between'):
            # Left side
            with ui.row().classes('items-center gap-4'):
                uploads_dir = BASE_DIR / 'uploads'
                directory_path = uploads_dir / directory_name
                pdf_filename = directory_pdf(directory_path)
                ui.button(icon='arrow_back', on_click=ui.navigate.back, color='blue-300').props('flat round dense')
                ui.label(f'Details for: {pdf_filename}').classes('text-xl font-bold')

            # Right side
            with ui.row().classes('items-center gap-2'):
                ui.button(icon='download', on_click=lambda: handle_download(directory_name)).props('flat dense').tooltip('Download EDI files')
                ui.button(icon='replay', on_click=lambda: handle_redo(directory_name), color='warning').props('flat dense').tooltip('Redo processing')
                ui.button(icon='delete', on_click=lambda: handle_delete(directory_name), color='negative').props('flat dense').tooltip('Delete this item')
                
                with ui.row().classes('items-center gap-2 border-l-2 border-gray-300 pl-4 ml-2'):
                    back_button = ui.button(icon='arrow_back_ios', on_click=lambda: show_page(current_page - 1)).props('flat round dense')
                    
                    page_number_input = ui.number(
                        min=1, max=num_images, value=current_page, on_change=lambda e: show_page(e.value),
                    ).props('dense outlined').classes('w-20').on('keydown.enter', lambda e: show_page(page_number_input.value))

                    ui.label(f'/ {num_images}').classes('text-md')

                    next_button = ui.button(icon='arrow_forward_ios', on_click=lambda: show_page(current_page + 1)).props('flat round dense')

    # Initial UI state update
    update_ui_for_page_change()

    # --- Main Content Splitter ---
    json_groups = {}
    for json_file in sorted(path.glob('*.json')):
        base_name = json_file.stem.replace('_details', '').replace('_basic', '')
        if base_name not in json_groups:
            json_groups[base_name] = {}
        if json_file.name.endswith('_basic.json'):
            json_groups[base_name]['basic'] = json_file
        elif json_file.name.endswith('_details.json'):
            json_groups[base_name]['details'] = json_file

    with ui.splitter(value=75).classes('w-full h-screen') as splitter:
        # Left panel (Image)
        with splitter.before:
            with ui.scroll_area().classes('w-full h-full'):
                with ui.column().classes('w-full h-full p-4 items-center justify-center'):
                    if not image_files:
                        ui.label('No images found.').classes('text-center text-gray-500')
                    else:
                        initial_web_path = f"/uploads/{directory_name}/{image_files[0].name}"
                        image_container = ui.image(initial_web_path).classes('w-full rounded-lg shadow-md')

        # Right panel (JSON Editors)
        with splitter.after:
            with ui.scroll_area().classes('w-full h-full p-4'):
                if not json_groups:
                    ui.label('No JSON files found.').classes('text-center text-gray-500')
                else:
                    for base_name in sorted(json_groups.keys()):
                        group = json_groups[base_name]
                        if 'basic' in group and 'details' in group:
                            # Pass the handler to the editor creation function
                            create_combined_editor(group['basic'], group['details'], handle_expansion_open, expansion_panels, base_name)
                        else:
                            ui.label(f"Incomplete JSON pair for {base_name}").classes('text-warning')

    # --- Action Handlers (from home.py, adapted) ---
    async def handle_download(directory: str):
        """Triggers a download for the zip file in the given directory."""
        directory_path = BASE_DIR / 'uploads' / directory
        zip_files = list(directory_path.glob('*-edi_files.zip'))
        if zip_files:
            zip_to_download = zip_files[0]
            ui.download(zip_to_download)
            ui.notify(f"Downloading {zip_to_download.name}...", color='positive')
        else:
            ui.notify(f"No ZIP file found in {directory_path.name}.", color='warning')

    async def handle_delete(directory: str):
        """Deletes a directory after user confirmation."""
        directory_path = BASE_DIR / 'uploads' / directory
        dialog = ui.dialog()
        with dialog, ui.card():
            ui.label(f'Are you sure you want to delete the directory "{directory}"?')
            with ui.row().classes('w-full justify-end'):
                ui.button('Cancel', on_click=dialog.close)
                
                async def perform_delete():
                    try:
                        shutil.rmtree(directory_path)
                        ui.notify(f'Successfully deleted {directory}', color='positive')
                        await asyncio.sleep(0.5)
                        ui.navigate.to('/')
                    except Exception as ex:
                        ui.notify(f'Error deleting directory: {ex}', color='negative')
                    dialog.close()

                ui.button('Delete', on_click=perform_delete, color='negative')
        await dialog

    async def handle_redo(directory: str):
        """Deletes the zip, reruns EDI conversion, and creates a new zip."""
        directory_path = BASE_DIR / 'uploads' / directory
        
        # Open a dialog with a log area
        log_dialog = ui.dialog()
        with log_dialog, ui.card().classes('w-full max-w-2xl'):
            ui.label(f"Redoing process for: {directory}").classes('text-lg font-bold mb-4')
            log_area = ui.textarea().props('readonly outlined').classes('w-full h-64')
            with ui.row().classes('w-full justify-end mt-4'):
                close_button = ui.button('Close', on_click=log_dialog.close)
                close_button.disable()

        # await log_dialog
        
        await log(log_area, f"--- Starting Redo for {directory_path.name} ---")

        # 1. Delete existing zip file
        for zip_file in directory_path.glob('*-edi_files.zip'):
            try:
                zip_file.unlink()
                await log(log_area, f"Deleted existing zip: {zip_file.name}")
            except OSError as e:
                await log(log_area, f"Error deleting zip {zip_file.name}: {e}")
                ui.notify(f"Error during redo: Could not delete old zip.", color='negative')
                return

        # 2. Rerun EDI generation
        try:
            tools_dir = BASE_DIR / 'tools'
            await run_and_stream(
                log_area,
                'Generate 835 from JSON',
                sys.executable, str(tools_dir / 'convjsonto835.py'), str(directory_path),
            )

            xmlx12_bin = shutil.which('xmlx12')
            if not xmlx12_bin:
                await log(log_area, 'CRITICAL: xmlx12 executable not found in system PATH.')
                raise FileNotFoundError('xmlx12 not found')

            xml_files = sorted(directory_path.glob('*.xml'))
            if xml_files:
                await log(log_area, f'Found {len(xml_files)} XML file(s) to convert to EDI.')
                for i, xml_path in enumerate(xml_files):
                    out_edi_path = xml_path.with_suffix('.edi')
                    await run_and_stream(
                        log_area,
                        f'Converting {xml_path.name} to EDI',
                        xmlx12_bin, str(xml_path.resolve()), '--outputfile', str(out_edi_path.resolve()),
                        ignore_exit_code=True
                    )
                    if out_edi_path.exists():
                        await log(log_area, f"SUCCESS: Created {out_edi_path.name}")
                    else:
                        await log(log_area, f"WARNING: xmlx12 ran but did not create {out_edi_path.name}")
            else:
                await log(log_area, 'No XML files found to convert with xmlx12.')

        except Exception as ex:
            await log(log_area, f"FATAL ERROR during processing: {ex}")
            ui.notify('An error occurred. Check the log for details.', color='negative')
            return

        # 3. Create a new zip file
        await log(log_area, 'Searching for .edi files to archive...')
        edi_files = list(directory_path.glob('*.edi'))

        if edi_files:
            zip_filename = f"{directory_path.name}-edi_files.zip"
            zip_path = directory_path / zip_filename
            await log(log_area, f'Creating ZIP archive: {zip_path.name}')
            
            with zipfile.ZipFile(zip_path, 'w') as zipf:
                for file in edi_files:
                    zipf.write(file, arcname=file.name)
            
            await log(log_area, f'Successfully created archive with {len(edi_files)} file(s).')
            ui.notify('Redo process complete!', color='positive')
        else:
            await log(log_area, 'No .edi files were generated to archive.')
            ui.notify('Redo finished, but no EDI files were created.', color='warning')

        await log(log_area, f"--- Redo for {directory_path.name} Finished ---")
        close_button.enable()
        ui.navigate.reload()
