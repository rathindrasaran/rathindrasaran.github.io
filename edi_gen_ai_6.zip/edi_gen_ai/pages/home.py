# pages/uploader.py
import asyncio
import shutil
import sys
import uuid
import zipfile
from datetime import datetime
from pathlib import Path

from nicegui import ui, events, app

from tools.utils import run_and_stream, sanitize_filename, log

BASE_DIR = Path(__file__).resolve().parent.parent


def create_content():
    """Creates the content for the Uploader tab."""
    with ui.column().classes('p-4 gap-3 max-w-6xl w-full'):
        with ui.card().classes('w-full'):
            ui.label('Upload a PDF to start processing.').classes('text-lg font-medium')
            upload = ui.upload(
                label='Upload PDF',
                on_upload=lambda e: handle_upload(e, table),
                auto_upload=True,
                multiple=False,
                max_file_size=100_000_000,
            ).props('accept=application/pdf')

        # This will be populated with a spinner during processing
        status_container = ui.row().classes('w-full items-center justify-center pt-4')
        
        # History Table
        ui.label('Processing History').classes('text-lg text-gray-800 font-medium pt-8')
        
        columns = [
            {'name': 'directory', 'label': 'Directory', 'field': 'directory', 'sortable': True},
            {'name': 'filename', 'label': 'Filename', 'field': 'filename', 'sortable': True},
            {'name': 'created_at', 'label': 'Created At', 'field': 'created_at', 'sortable': True},
            {'name': 'actions', 'label': 'Actions', 'field': 'actions'},
        ]
        
        table = ui.table(columns=columns, rows=[], row_key='directory').classes('w-full h-96')
        
        with table.add_slot('body-cell-actions', """
            <q-td :props="props">
                <q-btn @click="$parent.$emit('download', props.row)" icon="download" flat dense color="primary" />
                <q-btn @click="$parent.$emit('edit', props.row)" icon="edit" flat dense color="info" />
                <q-btn @click="$parent.$emit('documents', props.row)" icon="description" flat dense color="green" />
                <q-btn @click="$parent.$emit('redo', props.row)" icon="replay" flat dense color="warning" />
                <q-btn @click="$parent.$emit('delete', props.row)" icon="delete" flat dense color="negative" />
            </q-td>
        """):
            pass

        with ui.row().classes('w-full items-center justify-between pt-4'):
            ui.label('Processing Log').classes('text-lg text-gray-800 font-medium')
            log_toggle = ui.switch('Show Logs', value=False)

        log_area = ui.textarea(
            placeholder='Logs are hidden. Toggle "Show Logs" to view details.',
        ).props('rows=16 autogrow readonly').classes('w-full')

        log_area.bind_visibility_from(log_toggle, 'value')

        path_label = ui.label('').classes('text-caption text-grey-7')

        def get_history():
            """Scans the uploads directory and returns a list of processing results."""
            root = BASE_DIR / 'uploads'
            history = []
            if not root.exists():
                return history
        
            for d in sorted(root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
                if d.is_dir():
                    pdf_files = list(d.glob('*.pdf'))
                    if pdf_files:
                        pdf_file = pdf_files[0]
                        history.append({
                            'directory': d.name,
                            'filename': pdf_file.name,
                            'created_at': datetime.fromtimestamp(d.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                            'path': str(d),
                        })
            return history

        async def delete_directory(directory_path: str):
            """Deletes a directory after user confirmation."""
            dialog = ui.dialog()
            with dialog, ui.card():
                ui.label(f'Are you sure you want to delete the directory "{Path(directory_path).name}"?')
                with ui.row().classes('w-full justify-end'):
                    ui.button('Cancel', on_click=dialog.close)
                    
                    async def perform_delete():
                        try:
                            shutil.rmtree(directory_path)
                            ui.notify(f'Successfully deleted {Path(directory_path).name}', color='positive')
                            await asyncio.sleep(0.5) # Give time for notification
                            table.rows = get_history()
                        except Exception as ex:
                            ui.notify(f'Error deleting directory: {ex}', color='negative')
                        dialog.close()

                    ui.button('Delete', on_click=perform_delete, color='negative')
            await dialog

        def build_table_rows():
            table.rows = get_history()

        def handle_edit(row):
            """Navigates to the details page for the selected directory."""
            directory_name = row['directory']
            ui.navigate.to(f'/details/{directory_name}')

        def handle_documents(row):
            """Navigates to the documents page for the selected directory."""
            directory_name = row['directory']
            ui.navigate.to(f'/documents/{directory_name}')

        async def handle_delete(row):
            await delete_directory(row['path'])

        async def handle_download(row):
            """Triggers a download for the zip file in the given directory."""
            directory_path = Path(row['path'])
            zip_files = list(directory_path.glob('*-edi_files.zip'))
            if zip_files:
                zip_to_download = zip_files[0]
                ui.download(zip_to_download)
                ui.notify(f"Downloading {zip_to_download.name}...", color='positive')
            else:
                ui.notify(f"No ZIP file found in {directory_path.name}.", color='warning')

        table.on('edit', lambda msg: handle_edit(msg.args))
        table.on('delete', lambda msg: handle_delete(msg.args))
        table.on('download', lambda msg: handle_download(msg.args))
        table.on('documents', lambda msg: handle_documents(msg.args))
        table.on('redo', lambda msg: handle_redo(msg.args))

        # Initial table load
        build_table_rows()

        async def handle_redo(row):
            """Deletes the zip, reruns the EDI conversion, and creates a new zip."""
            directory_path = Path(row['path'])
            log_toggle.value = True
            await log(log_area, f"--- Starting Redo for {directory_path.name} ---")

            # 1. Delete existing zip file
            for zip_file in directory_path.glob('*-edi_files.zip'):
                try:
                    zip_file.unlink()
                    await log(log_area, f"Deleted existing zip: {zip_file.name}")
                except OSError as e:
                    await log(log_area, f"Error deleting zip {zip_file.name}: {e}")
                    ui.notify(f"Error during redo: Could not delete old zip.", color='negative')
                    return

            # 2. Rerun EDI generation
            try:
                tools_dir = BASE_DIR / 'tools'
                await run_and_stream(
                    log_area,
                    'Generate 835 from JSON',
                    sys.executable, str(tools_dir / 'convjsonto835.py'), str(directory_path),
                )

                xmlx12_bin = shutil.which('xmlx12')
                if not xmlx12_bin:
                    await log(log_area, 'CRITICAL: xmlx12 executable not found in system PATH.')
                    raise FileNotFoundError('xmlx12 not found')

                xml_files = sorted(directory_path.glob('*.xml'))
                if xml_files:
                    await log(log_area, f'Found {len(xml_files)} XML file(s) to convert to EDI.')
                    for i, xml_path in enumerate(xml_files):
                        out_edi_path = xml_path.with_suffix('.edi')
                        await run_and_stream(
                            log_area,
                            f'Converting {xml_path.name} to EDI',
                            xmlx12_bin, str(xml_path.resolve()), '--outputfile', str(out_edi_path.resolve()),
                            ignore_exit_code=True
                        )
                        if out_edi_path.exists():
                            await log(log_area, f"SUCCESS: Created {out_edi_path.name}")
                        else:
                            await log(log_area, f"WARNING: xmlx12 ran but did not create {out_edi_path.name}")
                else:
                    await log(log_area, 'No XML files found to convert with xmlx12.')

            except Exception as ex:
                await log(log_area, f"FATAL ERROR during processing: {ex}")
                ui.notify('An error occurred. Check the log for details.', color='negative')
                return

            # 3. Create a new zip file
            await log(log_area, 'Searching for .edi files to archive...')
            edi_files = list(directory_path.glob('*.edi'))

            if edi_files:
                zip_filename = f"{directory_path.name}-edi_files.zip"
                zip_path = directory_path / zip_filename
                await log(log_area, f'Creating ZIP archive: {zip_path.name}')
                
                with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
                    for file in edi_files:
                        zipf.write(file, arcname=file.name)
                
                await log(log_area, f'Successfully created archive with {len(edi_files)} file(s).')
                ui.notify('Redo process complete!', color='positive')
            else:
                await log(log_area, 'No .edi files were generated to archive.')
                ui.notify('Redo finished, but no EDI files were created.', color='warning')

            await log(log_area, f"--- Redo for {directory_path.name} Finished ---")
            build_table_rows()

        async def handle_upload(e: events.UploadEventArguments, table_ref: ui.table):
            log_toggle.value = False
            log_area.value = ''
            log_area.props('placeholder="Logs are hidden. Toggle \'Show Logs\' to view details."')

            upload.disable()
            with status_container:
                spinner = ui.spinner(color='primary', size='lg')
            log_area.props('placeholder="Processing logs will appear here..."')

            orig_name = sanitize_filename(e.name or 'upload.pdf')
            suffix = Path(orig_name).suffix.lower()
            data = e.content.read()
            if suffix != '.pdf':
                ui.notify('Please upload a valid PDF file.', color='negative')
                upload.enable()
                return

            root = BASE_DIR / 'uploads'
            root.mkdir(exist_ok=True)
            unique = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
            workdir = root / unique
            workdir.mkdir(parents=True, exist_ok=True)

            pdf_path = workdir / orig_name
            pdf_path.write_bytes(data)

            path_label.set_text(f'Working directory: {workdir}')
            await log(log_area, f'Created working directory: {unique}')
            await log(log_area, f'Saved uploaded file as: {orig_name}')

            try:
                # In the merged code, the conversion scripts are in the `tools` directory
                tools_dir = BASE_DIR / 'tools'
                await run_and_stream(
                    log_area,
                    'Convert PDF → XML (intermediate)',
                    sys.executable, str(tools_dir / 'convpdftoxml.py'), str(pdf_path), str(workdir),
                )

                await run_and_stream(
                    log_area,
                    'Generate 835 from JSON',
                    sys.executable, str(tools_dir / 'convjsonto835.py'), str(workdir),
                )

                xmlx12_bin = shutil.which('xmlx12')
                if not xmlx12_bin:
                    await log(log_area, 'CRITICAL: xmlx12 executable not found in system PATH.')
                    raise FileNotFoundError('xmlx12 not found')

                xml_files = sorted(workdir.glob('*.xml'))
                if xml_files:
                    await log(log_area, f'Found {len(xml_files)} XML file(s) to convert to EDI.')
                    for i, xml_path in enumerate(xml_files):
                        out_edi_path = xml_path.with_suffix('.edi')
                        
                        await run_and_stream(
                            log_area,
                            f'Converting {xml_path.name} to EDI',
                            xmlx12_bin, str(xml_path.resolve()), '--outputfile', str(out_edi_path.resolve()),
                            ignore_exit_code=True
                        )
                        
                        if out_edi_path.exists():
                            await log(log_area, f"SUCCESS: Created {out_edi_path.name}")
                        else:
                            await log(log_area, f"WARNING: xmlx12 ran but did not create {out_edi_path.name}")
                            
                else:
                    await log(log_area, 'No XML files found to convert with xmlx12.')
                

                await log(log_area, 'Searching for .edi files to archive...')
                edi_files = list(workdir.glob('*.edi'))

                if edi_files:
                    zip_filename = f"{unique}-edi_files.zip"
                    zip_path = workdir / zip_filename
                    await log(log_area, f'Creating ZIP archive: {zip_path.name}')
                    
                    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
                        for file in edi_files:
                            zipf.write(file, arcname=file.name)
                    
                    await log(log_area, f'Successfully created archive with {len(edi_files)} file(s).')

                    # The download button is now in the table, so no need to create one here.
                    pass
                else:
                    await log(log_area, 'No .edi files were generated to archive.')

            except Exception as ex:
                await log(log_area, f"FATAL ERROR during processing: {ex}")
                ui.notify('An error occurred. Check the log for details.', color='negative')
                log_toggle.value = True

            finally:
                status_container.clear()
                upload.enable()
                ui.notify('Processing complete ✅')
                build_table_rows()