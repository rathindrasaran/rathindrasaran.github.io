# config.py

# --- Hard-coded multiple login details ---
VALID_CREDENTIALS = {
    'rathin': 'Rathin180689',
    'paul': 'Nimda@321',
    'sundar_bala': 'Super@User@321'
}

API_KEY = ""