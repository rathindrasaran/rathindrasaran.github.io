# components/layout.py
from nicegui import ui, app

from pages.home import create_content as create_home_content
from pages.about import create_content as create_about_content
from pages.home import create_content as create_uploader_content
from pages import details_page
from pages.claims_page import create_content as create_claims_content
 
content_map = {
    'Home': create_home_content,
    'Claims': create_claims_content,
    'About': create_about_content,
    # 'Uploader': create_uploader_content,
}

def build_layout():
    """Builds a compact and professional layout."""
    ui.page_title("ERA PDF to EDI Tool")
    
    if 'open_tabs' not in app.storage.user:
        app.storage.user['open_tabs'] = ['Home']
    
    open_tabs = app.storage.user['open_tabs']

    @ui.refreshable
    def create_tabs_area():
        """Creates the tab and tab_panel UI with a more compact style."""
        with ui.tabs().props('dense align=left').classes('w-full').bind_value(app.storage.user, 'active_tab') as tabs:
            for name in list(open_tabs):
                with ui.tab(name=name, label=''):
                    with ui.row().classes('items-center gap-2 no-wrap'):
                        ui.label(name)
                        if name != 'Home':
                            ui.button(icon='close', on_click=lambda _, n=name: close_tab(n)) \
                                .props('flat round dense size=sm')

        # CHANGED: Reduced vertical padding from p-4 to py-2 (8px).
        # This brings the content closer to the tab bar.
        with ui.tab_panels(tabs, value=app.storage.user.get('active_tab'), animated=False) \
                .classes('w-full flex-grow px-4 py-2'):
            for name in open_tabs:
                with ui.tab_panel(name):
                    if name in content_map:
                        content_map[name]()
                    else:
                        ui.label(f'Content for {name}')

    def close_tab(name: str):
        if app.storage.user['active_tab'] == name:
            current_index = open_tabs.index(name)
            new_active_tab = open_tabs[max(0, current_index - 1)]
            if current_index == 0 and len(open_tabs) > 1:
                new_active_tab = open_tabs[1]
            app.storage.user['active_tab'] = new_active_tab
        open_tabs.remove(name)
        if not open_tabs:
             app.storage.user['active_tab'] = None
        elif app.storage.user['active_tab'] not in open_tabs:
             app.storage.user['active_tab'] = open_tabs[0]
        create_tabs_area.refresh()

    def open_tab(name: str):
        if name not in open_tabs:
            open_tabs.append(name)
        app.storage.user['active_tab'] = name
        create_tabs_area.refresh()

    # --- Main UI Structure ---
    with ui.header(elevated=True).classes('items-center justify-between px-4 py-1 w-full'):
        with ui.row().classes('items-center gap-4'):
            ui.button(on_click=lambda: left_drawer.toggle(), icon='menu').props('flat dense color=white')
            ui.label('ERA PDF to EDI Tool').classes('text-lg')

        with ui.row().classes('items-center gap-4'):
            ui.label(f"User: {app.storage.user.get('username', 'Guest')}").classes('text-white')
            
            def logout():
                app.storage.user.clear()
                ui.navigate.to('/login')
            
            ui.button('Logout', on_click=logout, icon='logout').props('flat dense color=white')

    with ui.left_drawer().props('bordered width=240') as left_drawer:
        with ui.column().classes('w-full p-2 gap-0'):
            ui.label('Menu').classes('p-2 text-caption text-gray-500')
            
            with ui.row().classes('w-full items-center p-2 rounded-lg hover:bg-gray-200 cursor-pointer') \
                    .on('click', lambda: open_tab('Home')):
                ui.icon('home', size='sm').classes('mr-2')
                ui.label('PDF -> 835')

            with ui.row().classes('w-full items-center p-2 rounded-lg hover:bg-gray-200 cursor-pointer') \
                    .on('click', lambda: open_tab('Claims')):
                ui.icon('assignment', size='sm').classes('mr-2')
                ui.label('837 Parser')

            with ui.row().classes('w-full items-center p-2 rounded-lg hover:bg-gray-200 cursor-pointer') \
                    .on('click', lambda: open_tab('About')):
                ui.icon('info', size='sm').classes('mr-2')
                ui.label('About')
 
    create_tabs_area()

    with ui.footer().classes('justify-center py-1'):
        ui.label('© 2025 REVEXP LLC').classes('text-xs')