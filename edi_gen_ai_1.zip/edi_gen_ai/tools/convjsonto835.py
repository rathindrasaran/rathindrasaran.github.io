import os
import sys
import json
import re
from collections import defaultdict
import xml.etree.ElementTree as ET
from xml.dom import minidom
from datetime import datetime

# -- Track Check / EFT Number ---
current_payment_id: str = None

# --- Helper Functions ---

def pretty_print_xml(elem):
    """Return a pretty-printed XML string for the Element."""
    rough_string = ET.tostring(elem, 'utf-8')
    reparsed = minidom.parseString(rough_string)
    pretty_string = reparsed.toprettyxml(indent="  ")
    
    # This regex finds tags like <ele id="..."/> and replaces them
    # with <ele id="..."></ele> to satisfy stricter parsers.
    return re.sub(r'(<(\w+)([^>]*?)/>)', r'<\2\3> </\2>', pretty_string)

def format_date_from_json(date_str, out_fmt='%Y%m%d'):
    """
    Parses a date string by trying a list of common formats (e.g., m/d/yyyy, m/d/yy)
    and converts it to the standard YYYYMMDD format. Returns None if invalid.
    """
    if not date_str or not isinstance(date_str, str):
        return None

    # --- CHANGE: List of formats to try in order of preference ---
    supported_formats = [
        '%m/%d/%Y',  # Handles '05/15/2024'
        '%m/%d/%y',  # Handles '05/15/24'
        '%Y-%m-%d',  # Handles '2024-05-15'
        '%Y%m%d',    # Handles '20240515'
    ]
    # --- END OF CHANGE ---

    # Loop through the formats and try to parse the date
    for fmt in supported_formats:
        try:
            # If parsing is successful, format and return immediately
            dt_obj = datetime.strptime(date_str, fmt)
            return dt_obj.strftime(out_fmt)
        except ValueError:
            # If parsing fails, just continue to the next format
            continue

    # If the loop finishes without a successful parse, the format is unsupported.
    # Print a warning for easier debugging.
    print(f"Warning: Could not parse unsupported date format: '{date_str}'", file=sys.stderr)
    return None

def find_remittance_files(directory):
    """
    Finds and groups _basic.json and _details.json files by their page number.
    Returns a dictionary of file paths keyed by page number, sorted.
    """
    file_pattern = re.compile(r".*_(\d{3,})_(basic|details)\.json$")
    files_by_page = defaultdict(dict)

    if not os.path.isdir(directory):
        print(f"Error: Directory not found at '{directory}'", file=sys.stderr)
        sys.exit(1)

    for filename in os.listdir(directory):
        match = file_pattern.match(filename)
        if match:
            page_num = match.group(1)
            file_type = match.group(2) # 'basic' or 'details'
            files_by_page[page_num][file_type] = os.path.join(directory, filename)

    # Return a dictionary sorted by page number (key)
    return {k: files_by_page[k] for k in sorted(files_by_page.keys())}

def group_service_lines_by_claim(details_data):
    """
    Groups a flat list of service line items by their ClaimControlNumber.
    """
    claims = defaultdict(lambda: {'header': None, 'lines': []})
    for line_item in details_data:
        if not isinstance(line_item, dict):
            print(f"Warning: Skipping invalid/non-dictionary item in details data: {line_item}", file=sys.stderr)
            continue

        ccn = line_item.get('PayerClaimControlNumber') or line_item.get('PayerClaimControlNumberO1') or line_item.get('ClaimControlNumber') or line_item.get('SubscriberID')
        if not ccn:
            continue 
        if not claims[ccn]['header']:
            claims[ccn]['header'] = line_item
        claims[ccn]['lines'].append(line_item)
    return claims

# --- XML Generation Functions ---

def add_element(parent, tag, text=None, attrib=None):
    """
    Helper to create and add a new XML element, ensuring text is never None.
    """
    if attrib is None:
        attrib = {}
    
    safe_text = str(text) if text is not None else ""
        
    element = ET.SubElement(parent, tag, attrib)
    element.text = safe_text
    return element

def add_header(st_loop, basic_info):
    """Adds the HEADER loop (BPR, TRN, N1, PER) to the ST loop."""
    header_loop = add_element(st_loop, 'loop', attrib={'id': 'HEADER'})
    
    # BPR Segment 
    bpr_seg = add_element(header_loop, 'seg', attrib={'id': 'BPR'})
    payment_method_code = 'CHK' if basic_info.get('CheckNumber') else 'ACH' if basic_info.get('EFTNumber') else ''
    add_element(bpr_seg, 'ele', text='I', attrib={'id': 'BPR01'}) # I for Information
    add_element(bpr_seg, 'ele', text=basic_info.get('PaymentAmount'), attrib={'id': 'BPR02'})
    add_element(bpr_seg, 'ele', text='C', attrib={'id': 'BPR03'}) # C for Credit
    add_element(bpr_seg, 'ele', text=payment_method_code, attrib={'id': 'BPR04'})
    add_element(bpr_seg, 'ele', text=format_date_from_json(basic_info.get('ProductionDate') or basic_info.get('PaymentDate')), attrib={'id': 'BPR16'})
    
    # TRN Segment
    trn_seg = add_element(header_loop, 'seg', attrib={'id': 'TRN'})
    trace_number = basic_info.get('CheckNumber') or basic_info.get('EFTNumber') or basic_info.get('PaymentNumber') or basic_info.get('TraceNumber') or basic_info.get('PaymentTraceNumber')
    add_element(trn_seg, 'ele', text='1', attrib={'id': 'TRN01'})
    add_element(trn_seg, 'ele', text=trace_number, attrib={'id': 'TRN02'})
    add_element(trn_seg, 'ele', text=f"1{basic_info.get('PayeeTaxID', '')}", attrib={'id': 'TRN03'})

    # DTM Production Date 
    dtm_seg = add_element(header_loop, 'seg', attrib={'id': 'DTM'})
    add_element(dtm_seg, 'ele', '405', attrib={'id': 'DTM01'}) # Production Date
    add_element(dtm_seg, 'ele', format_date_from_json(basic_info.get('ProductionDate') or basic_info.get('PaymentDate')), attrib={'id': 'DTM02'})

    # 1000A Loop - Payer
    payer_loop = add_element(header_loop, 'loop', attrib={'id': '1000A'})
    n1_pr = add_element(payer_loop, 'seg', attrib={'id': 'N1'})
    add_element(n1_pr, 'ele', 'PR', attrib={'id': 'N101'}) # PR for Payer
    add_element(n1_pr, 'ele', basic_info.get('PayerName'), attrib={'id': 'N102'})
    
    if basic_info.get('PayerAddress'):
        n3_pr = add_element(payer_loop, 'seg', attrib={'id': 'N3'})
        add_element(n3_pr, 'ele', text=basic_info.get('PayerAddress'), attrib={'id': 'N301'})
    
    n4_pr = add_element(payer_loop, 'seg', attrib={'id': 'N4'})
    add_element(n4_pr, 'ele', basic_info.get('PayerCity'), attrib={'id': 'N401'})
    add_element(n4_pr, 'ele', basic_info.get('PayerState'), attrib={'id': 'N402'})
    add_element(n4_pr, 'ele', basic_info.get('PayerZIP'), attrib={'id': 'N403'})
    
    if basic_info.get('PayerWebsite'):
        per_web = add_element(payer_loop, 'seg', attrib={'id': 'PER'})
        add_element(per_web, 'ele', 'IC', attrib={'id': 'PER01'})
        add_element(per_web, 'ele', 'UR', attrib={'id': 'PER03'})
        add_element(per_web, 'ele', f"http|//{basic_info.get('PayerWebsite')}", attrib={'id': 'PER04'})
        
    if basic_info.get('PayerContactPhone'):
        per_phone = add_element(payer_loop, 'seg', attrib={'id': 'PER'})
        add_element(per_phone, 'ele', 'CX', attrib={'id': 'PER01'})
        add_element(per_phone, 'ele', 'CUSTOMER SERVICE', attrib={'id': 'PER02'})
        add_element(per_phone, 'ele', 'TE', attrib={'id': 'PER03'})
        add_element(per_phone, 'ele', basic_info.get('PayerContactPhone').replace('-', ''), attrib={'id': 'PER04'})

    # 1000B Loop - Payee
    payee_loop = add_element(header_loop, 'loop', attrib={'id': '1000B'})
    n1_pe = add_element(payee_loop, 'seg', attrib={'id': 'N1'})
    add_element(n1_pe, 'ele', 'PE', attrib={'id': 'N101'}) # PE for Payee
    add_element(n1_pe, 'ele', basic_info.get('PayeeName'), attrib={'id': 'N102'})
    add_element(n1_pe, 'ele', 'XX', attrib={'id': 'N103'}) # NPI qualifier
    add_element(n1_pe, 'ele', basic_info.get('PayeeNPI'), attrib={'id': 'N104'})

    if basic_info.get('PayeeAddress'):
       n3_pe = add_element(payee_loop, 'seg', attrib={'id': 'N3'})
       add_element(n3_pe, 'ele', basic_info.get('PayeeAddress'), attrib={'id': 'N301'})
    
    n4_pe = add_element(payee_loop, 'seg', attrib={'id': 'N4'})
    add_element(n4_pe, 'ele', basic_info.get('PayeeCity'), attrib={'id': 'N401'})
    add_element(n4_pe, 'ele', basic_info.get('PayeeState'), attrib={'id': 'N402'})
    add_element(n4_pe, 'ele', basic_info.get('PayeeZIP'), attrib={'id': 'N403'})
    
    if basic_info.get('PayeeTaxID'):
        ref_pe = add_element(payee_loop, 'seg', attrib={'id': 'REF'})
        add_element(ref_pe, 'ele', 'TJ', attrib={'id': 'REF01'}) # Tax ID number
        add_element(ref_pe, 'ele', basic_info.get('PayeeTaxID'), attrib={'id': 'REF02'})

def add_detail_claims(st_loop, details_data):
    """Adds the DETAIL loop containing all claims and services."""
    detail_loop = add_element(st_loop, 'loop', attrib={'id': 'DETAIL'})
    grouped_claims = group_service_lines_by_claim(details_data)
    
    for i, (claim_control_num, claim_data) in enumerate(grouped_claims.items(), 1):
        claim_header = claim_data['header']
        service_lines = claim_data['lines']

        loop_2000 = add_element(detail_loop, 'loop', attrib={'id': '2000'})

        lx_seg = add_element(loop_2000, 'seg', attrib={'id': 'LX'}) # Create the parent seg
        add_element(lx_seg, 'ele', text=str(i), attrib={'id': 'LX01'}) # Add the ele inside it

        loop_2100 = add_element(loop_2000, 'loop', attrib={'id': '2100'})
        
        # CLP Segment
        clp_seg = add_element(loop_2100, 'seg', attrib={'id': 'CLP'})
        claim_payment_amt = float(claim_header.get('ClaimPaymentAmount', 0) or 0)
        # 1: Processed as Primary, 4: Denied. We infer from payment amount.
        claim_status_code = '1' if claim_payment_amt > 0 else '4'
        
        add_element(clp_seg, 'ele', claim_header.get('ClaimControlNumber'), attrib={'id': 'CLP01'})
        add_element(clp_seg, 'ele', claim_status_code, attrib={'id': 'CLP02'})
        add_element(clp_seg, 'ele', claim_header.get('TotalChargeAmount'), attrib={'id': 'CLP03'})
        add_element(clp_seg, 'ele', claim_header.get('ClaimPaymentAmount'), attrib={'id': 'CLP04'})
        add_element(clp_seg, 'ele', claim_header.get('PatientResponsibilityAmount'), attrib={'id': 'CLP05'})
        add_element(clp_seg, 'ele', claim_header.get('ClaimFilingIndicatorCode') or 'ZZ', attrib={'id': 'CLP06'}) #ZZ for unknown
        add_element(clp_seg, 'ele', claim_header.get('PayerClaimControlNumber'), attrib={'id': 'CLP07'})
        
        # NM1 - Patient Name
        nm1_patient = add_element(loop_2100, 'seg', attrib={'id': 'NM1'})
        add_element(nm1_patient, 'ele', 'QC', attrib={'id': 'NM101'}) # QC for Patient
        add_element(nm1_patient, 'ele', '1', attrib={'id': 'NM102'}) # 1 for Person
        add_element(nm1_patient, 'ele', claim_header.get('PatientLastName'), attrib={'id': 'NM103'})
        add_element(nm1_patient, 'ele', claim_header.get('PatientFirstName'), attrib={'id': 'NM104'})
        add_element(nm1_patient, 'ele', claim_header.get('PatientMiddleName') or ' ', attrib={'id': 'NM105'})
        add_element(nm1_patient, 'ele', claim_header.get('SubscriberID') or claim_header.get('ClaimControlNumber'), attrib={'id': 'NM109'})
        
        # NM1 - Rendering Provider
        if claim_header.get('RenderingProviderNPI'):
            nm1_provider = add_element(loop_2100, 'seg', attrib={'id': 'NM1'})
            add_element(nm1_provider, 'ele', '82', attrib={'id': 'NM101'}) # 82 for Rendering Provider
            add_element(nm1_provider, 'ele', '1', attrib={'id': 'NM102'}) # Person
            add_element(nm1_provider, 'ele', claim_header.get('RenderingProviderLastName') or ' ', attrib={'id': 'NM103'})
            add_element(nm1_provider, 'ele', claim_header.get('RenderingProviderFirstName') or ' ', attrib={'id': 'NM104'})
            add_element(nm1_provider, 'ele', 'XX', attrib={'id': 'NM108'}) # NPI qualifier
            add_element(nm1_provider, 'ele', claim_header.get('RenderingProviderNPI'), attrib={'id': 'NM109'})

        # Loop 2110 for Service Lines
        for service_line in service_lines:
            loop_2110 = add_element(loop_2100, 'loop', attrib={'id': '2110'})
            
            # SVC Segment
            svc_seg = add_element(loop_2110, 'seg', attrib={'id': 'SVC'})
            proc_code = service_line.get('ProcedureCode', '')
            
            svc_comp = add_element(svc_seg, 'comp', attrib={'id': 'SVC'})
            add_element(svc_comp, 'subele', 'HC', attrib={'id': 'SVC01-01'}) # HC assumes HCPCS
            add_element(svc_comp, 'subele', proc_code, attrib={'id': 'SVC01-02'})
            
            add_element(svc_seg, 'ele', service_line.get('LineItemChargeAmount'), attrib={'id': 'SVC02'})
            add_element(svc_seg, 'ele', service_line.get('LineItemPaidAmount'), attrib={'id': 'SVC03'})
            add_element(svc_seg, 'ele', service_line.get('UnitsOfService') or 1, attrib={'id': 'SVC05'})

            # DTM Service Date
            dtm_svc = add_element(loop_2110, 'seg', attrib={'id': 'DTM'})
            add_element(dtm_svc, 'ele', '472', attrib={'id': 'DTM01'}) # 472 for Service Date
            add_element(dtm_svc, 'ele', format_date_from_json(service_line.get('ServiceDate')), attrib={'id': 'DTM02'})

            # CAS Segment (Claim Adjustment)
            try:
                charge = float(service_line.get('LineItemChargeAmount', 0))
                paid = float(service_line.get('LineItemPaidAmount', 0))
                adjustment = charge - paid
            except (ValueError, TypeError):
                adjustment = 0

            # Use a small epsilon for float comparison to avoid precision issues
            if adjustment > 0.005: 
                cas_seg = add_element(loop_2110, 'seg', attrib={'id': 'CAS'})
                # The 'P' prefix in sample reason codes ('P51') suggests a payer remark.
                # 'PI' (Payer Initiated Reduction) is a reasonable default group code.
                group_code = service_line.get('AdjustmentGroupCode') or 'PI'
                reason_code = service_line.get('AdjustmentReasonCode') or ' '
                add_element(cas_seg, 'ele', group_code, attrib={'id': 'CAS01'})
                add_element(cas_seg, 'ele', reason_code, attrib={'id': 'CAS02'})
                add_element(cas_seg, 'ele', f"{adjustment:.2f}", attrib={'id': 'CAS03'})

def generate_835_xml(batch_data, output_filename):
    """
    Generates a complete 835 XML file from a batch of remittance data.
    """
    basic_info = batch_data['basic']
    details_data = batch_data['details']

    # --- Root and Envelope Setup (ISA/GS/ST/SE/GE/IEA) ---
    root = ET.Element('x12simple')
    isa_loop = add_element(root, 'loop', attrib={'id': 'ISA_LOOP'})
    # Hardcoded/Generated ISA segment
    isa_seg = add_element(isa_loop, 'seg', attrib={'id': 'ISA'})
    add_element(isa_seg, 'ele', '00', attrib={'id': 'ISA01'})
    add_element(isa_seg, 'ele', ''.ljust(10), attrib={'id': 'ISA02'})
    add_element(isa_seg, 'ele', '00', attrib={'id': 'ISA03'})
    add_element(isa_seg, 'ele', ''.ljust(10), attrib={'id': 'ISA04'})
    add_element(isa_seg, 'ele', 'ZZ', attrib={'id': 'ISA05'})
    payer_name_isa = (basic_info.get('PayerName') or 'PAYER')[:15].ljust(15)
    add_element(isa_seg, 'ele', payer_name_isa, attrib={'id': 'ISA06'})
    add_element(isa_seg, 'ele', 'ZZ', attrib={'id': 'ISA07'})
    payee_name_isa = (basic_info.get('PayeeName') or 'PAYEE')[:15].ljust(15)
    add_element(isa_seg, 'ele', payee_name_isa, attrib={'id': 'ISA08'})
    add_element(isa_seg, 'ele', datetime.now().strftime('%y%m%d'), attrib={'id': 'ISA09'})
    add_element(isa_seg, 'ele', datetime.now().strftime('%H%M'), attrib={'id': 'ISA10'})
    add_element(isa_seg, 'ele', '^', attrib={'id': 'ISA11'})
    add_element(isa_seg, 'ele', '00501', attrib={'id': 'ISA12'})
    add_element(isa_seg, 'ele', '000000001', attrib={'id': 'ISA13'})
    add_element(isa_seg, 'ele', '0', attrib={'id': 'ISA14'})
    add_element(isa_seg, 'ele', 'P', attrib={'id': 'ISA15'})
    add_element(isa_seg, 'ele', ':', attrib={'id': 'ISA16'})

    gs_loop = add_element(isa_loop, 'loop', attrib={'id': 'GS_LOOP'})
    gs_seg = add_element(gs_loop, 'seg', attrib={'id': 'GS'})
    add_element(gs_seg, 'ele', 'HP', attrib={'id': 'GS01'})
    # Use 'or' to provide a default value if the key's value is None, then slice.
    payer_id_gs = (basic_info.get('PayerID') or 'PAYERID')[:15]
    add_element(gs_seg, 'ele', payer_id_gs, attrib={'id': 'GS02'})
    payee_tax_id_gs = (basic_info.get('PayeeTaxID') or 'PAYEEID')[:15]
    add_element(gs_seg, 'ele', payee_tax_id_gs, attrib={'id': 'GS03'})
    add_element(gs_seg, 'ele', datetime.now().strftime('%Y%m%d'), attrib={'id': 'GS04'})
    add_element(gs_seg, 'ele', datetime.now().strftime('%H%M'), attrib={'id': 'GS05'})
    add_element(gs_seg, 'ele', '1', attrib={'id': 'GS06'})
    add_element(gs_seg, 'ele', 'X', attrib={'id': 'GS07'})
    add_element(gs_seg, 'ele', '005010X221A1', attrib={'id': 'GS08'})

    st_loop = add_element(gs_loop, 'loop', attrib={'id': 'ST_LOOP'})
    st_seg = add_element(st_loop, 'seg', attrib={'id': 'ST'})
    add_element(st_seg, 'ele', '835', attrib={'id': 'ST01'})
    add_element(st_seg, 'ele', '0001', attrib={'id': 'ST02'})
    
    # --- Main Content ---
    add_header(st_loop, basic_info)
    add_detail_claims(st_loop, details_data)
    
    # --- Trailers ---
    segment_count = len(st_loop.findall('.//seg'))
    se_seg = add_element(st_loop, 'seg', attrib={'id': 'SE'})
    add_element(se_seg, 'ele', str(segment_count + 1), attrib={'id': 'SE01'}) # +1 for the SE segment itself
    add_element(se_seg, 'ele', '0001', attrib={'id': 'SE02'})

    ge_seg = add_element(gs_loop, 'seg', attrib={'id': 'GE'})
    add_element(ge_seg, 'ele', '1', attrib={'id': 'GE01'}) # Number of ST loops
    add_element(ge_seg, 'ele', '1', attrib={'id': 'GE02'})

    iea_seg = add_element(isa_loop, 'seg', attrib={'id': 'IEA'})
    add_element(iea_seg, 'ele', '1', attrib={'id': 'IEA01'}) # Number of GS loops
    add_element(iea_seg, 'ele', '000000001', attrib={'id': 'IEA02'})
    
    # Write to file
    with open(output_filename, "w", encoding="utf-8") as f:
        f.write(pretty_print_xml(root))
    print(f"Successfully generated XML file: {output_filename}")


def main():
    """
    Main function to process JSON files and generate 835 XML.
    """
    global current_payment_id

    if len(sys.argv) < 2:
        print(f"Usage: python {sys.argv[0]} <directory_path>")
        sys.exit(1)
    
    input_dir = sys.argv[1]
    
    sorted_files = find_remittance_files(input_dir)
    if not sorted_files:
        print(f"No valid '*_basic.json' or '*_details.json' files found in '{input_dir}'.")
        return

    # --- Batching Logic ---
    all_batches = []
    current_batch = None
    current_batch_id = None

    for page_num in sorted_files:
        page_files = sorted_files[page_num]
        basic_path = page_files.get('basic')
        details_path = page_files.get('details')
        print(f"Processing {page_num} {basic_path}")

        if not (basic_path and details_path):
            print(f"Warning: Missing a file pair for page {page_num}. Skipping.")
            continue

        # check for check or claim info missing scenario

        try:
            with open(basic_path, 'r', encoding='utf-8') as f:
                basic_data = json.load(f)
        except json.JSONDecodeError as e:
            print(f"Error reading JSON for page {page_num}: {e}. Skipping.", file=sys.stderr)
            continue

        page_payment_id = basic_data.get('CheckNumber') or basic_data.get('EFTNumber') or basic_data.get('PaymentTraceNumber') or basic_data.get('TraceNumber') or basic_data.get('PaymentNumber')

        if isinstance(page_payment_id, str):
            page_payment_id = page_payment_id.replace(" ","")

        if not page_payment_id:
            if current_payment_id:
                page_payment_id = current_payment_id
            else:
                continue
        else:
            current_payment_id = page_payment_id

        special_chars = [",", "[", "]", "'"]
        if any(ch in page_payment_id for ch in special_chars) :
            print(f"Invalid Check / EFT NUmber for page {page_num}: Skipping.")
            continue

        if not isinstance(page_payment_id, str):
            print(f"Invalid Check / EFT for page {page_num}: Skipping.")
            continue

        try:
            with open(details_path, 'r', encoding='utf-8') as f:
                details_data = json.load(f)
                # Check if the content is an empty list
                if details_data == []:
                    print(f"Warning: Missing claim data for page {page_num}. Skipping.")
                    continue
        except json.JSONDecodeError as e:
            print(f"Warning: JSON Error: Missing claim data for page {page_num}. Skipping.")
            continue

        total_line_items = 0
        for record in details_data:
            if not isinstance(record, str):
                if record.get("PatientFirstName") and record.get("PatientLastName"):
                    if record.get("ClaimControlNumber") or record.get("PayerClaimControlNumber"):
                        total_line_items += 1
        
        if total_line_items == 0:
            print(f"Warning: Missing claim data for page {page_num}. Skipping.")
            continue

        if page_payment_id and page_payment_id != current_batch_id:
            # A new, distinct payment ID is found. This starts a new batch.
            if current_batch:
                all_batches.append(current_batch)

            current_batch_id = page_payment_id
            current_batch = {
                'id': current_batch_id,
                'basic': basic_data,
                'details': details_data
            }
        elif current_batch:
            # Page belongs to the current batch (same ID or no ID on this page)
            current_batch['details'].extend(details_data)
        elif page_payment_id:
            # This is the very first page containing a payment ID
            current_batch_id = page_payment_id
            current_batch = {
                'id': current_batch_id,
                'basic': basic_data,
                'details': details_data
            }
        else:
            # First page has no payment ID. This is an edge case.
            print(f"Warning: First processed page {page_num} has no CheckNumber or EFTNumber to start a batch.", file=sys.stderr)
    
    if current_batch:
        all_batches.append(current_batch)
        
    # --- Generate XML for each completed batch ---
    if not all_batches:
        print("No complete remittance batches with payment identifiers were found to process.")
        return
        
    for i, batch in enumerate(all_batches, 1):
        # Create a unique output filename for each batch
        output_filename = f"{input_dir}/remittance_835_{batch['id']}.xml"
        generate_835_xml(batch, output_filename)

if __name__ == '__main__':
    main()