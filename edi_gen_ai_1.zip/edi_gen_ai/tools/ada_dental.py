from typing import Dict, List
from nicegui import ui

# Dictionary to store form data
form_data = {
    # Header Information
    "1_type_of_transaction": {
        "statement_of_actual_services": True,
        "request_for_predetermination": False,
        "epsdt_title_xix": False,
    },
    "2_predetermination_number": "PRED-12345",

    # Dental Benefit Plan Information
    "3_company_plan_name": "",
    "3_company_address": "",
    "3_company_city": "",
    "3_company_state": "",
    "3_company_zipcode": "",    
    "3_company_plan_name_address": "Dental Guardian Inc.\n123 Insurance Way\nHealthville, CA 90210",
    "3a_payer_id": "DG98765",

    # Other Coverage
    "4_other_coverage": {
        "dental": True,
        "medical": False
    },
    "5_other_insured_fname": "",
    "5_other_insured_lname": "",    
    "5_other_insured_name": "Jane Smith",
    "6_other_insured_dob": "01/15/1980",
    "7_other_insured_gender": "F",
    "8_other_insured_id": "WXYZ987654321",
    "9_other_plan_group_number": "GRP-B456",
    "10_patient_relationship_to_other_insured": "Spouse",
    "11_other_insurance_company_name": "",
    "11_other_insurance_company_address": "",
    "11_other_insurance_company_city": "",
    "11_other_insurance_company_state": "",
    "11_other_insurance_company_zipcode": "",
    "11_other_insurance_company_name_address": "Supplemental Dental Co.\n456 Coverage Ave\nInsureburg, TX 75001",
    "11a_other_payer_id": "SDC54321",

    # Policyholder/Subscriber Information
    "12_policyholder_fname": "",
    "12_policyholder_lname": "",
    "12_policyholder_address": "",
    "12_policyholder_city": "",
    "12_policyholder_state": "",
    "12_policyholder_zipcode": "",    
    "12_policyholder_name_address": "John Doe\n789 Patient Rd.\nSuburbia, CA 90211",
    "13_policyholder_dob": "05/20/1978",
    "14_policyholder_gender": "M",
    "15_policyholder_id": "ABCD123456789",
    "16_policyholder_plan_group_number": "GRP-A123",
    "17_employer_name": "Global Tech Innovations",

    # Patient Information
    "18_patient_relationship_to_policyholder": "Dependent Child",
    "19_reserved_for_future_use": "",
    "20_patient_fname": "",
    "20_patient_lname": "",
    "20_patient_address": "",
    "20_patient_city": "",
    "20_patient_state": "",
    "20_patient_zipcode": "",
    "20_patient_name_address": "Jimmy Doe\n789 Patient Rd.\nSuburbia, CA 90211",
    "21_patient_dob": "11/10/2010",
    "22_patient_gender": "M",
    "23_patient_id": "PAT-JD001",

    # Record of Services Provided (as a list of dictionaries)
    "service_lines": [
        {
            "procedure_date": "09/15/2025", "oral_cavity_area": "10", "tooth_system": "JP", "tooth_number": "3",
            "tooth_surface": "MOD", "procedure_code": "D2330", "diag_pointer": "A", "quantity": "1", "description": "Resin-based composite",
            "fee": "150.00"
        },
        {
            "procedure_date": "09/15/2025", "oral_cavity_area": "20", "tooth_system": "JP", "tooth_number": "14",
            "tooth_surface": "O", "procedure_code": "D2750", "diag_pointer": "B", "quantity": "1", "description": "Crown - porcelain/ceramic",
            "fee": "850.00"
        },
    ],

    # Other Fields
    "31a_other_fee": "25.00",
    "32_total_fee": "1025.00",
    "33_missing_teeth_information": {str(i): False for i in range(1, 33)},
    "34_diagnosis_code_list_qualifier": "B",
    "34a_diagnosis_codes": {"A": "K02.1", "B": "K03.6", "C": "", "D": ""},
    "35_remarks": "Patient reported sensitivity on upper right.",

    # Authorizations
    "36_patient_guardian_signature": "John Doe (on file)",
    "36_patient_guardian_signature_date": "09/15/2025",
    "37_subscriber_signature": "John Doe (on file)",
    "37_subscriber_signature_date": "09/15/2025",

    # Ancillary Claim/Treatment Information
    "38_place_of_treatment": "Office",
    "39_enclosures": "N",
    "39a_date_last_srp": "01/12/2024",
    "40_is_treatment_for_orthodontics": "N",
    "41_date_appliance_placed": "",
    "42_months_of_treatment": "",
    "43_replacement_of_prosthesis": "N",
    "44_date_of_prior_placement": "",
    "45_treatment_resulting_from": {
        "auto_accident": True,
        "employment": False,
        "other_accident": False,
    },
    "46_date_of_accident": "08/01/2025",
    "47_auto_accident_state": "CA",

    # Billing Dentist or Dental Entity
    "48_billing_dentist_name_address": "Downtown Dental Group\n100 Main Street\nHealthville, CA 90210",
    "49_billing_dentist_npi": "1234567890",
    "50_billing_dentist_license_number": "DEN-CA-9876",
    "51_billing_dentist_ssn_or_tin": "99-9999999",
    "52_billing_dentist_phone": "555-123-4567",
    "52a_billing_dentist_additional_provider_id": "BC-112233",

    # Treating Dentist and Treatment Location Information
    "53_treating_dentist_signature": "SIGNATURE ON FILE",
    "53_treating_dentist_signature_date": "09/15/2025",
    "53a_locum_tenens_treating_dentist": False,
    "54_treating_dentist_npi": "0987654321",
    "55_treating_dentist_license_number": "DEN-CA-6789",
    "56_provider_specialty_code": "GPR",
    "56a_treatment_location_address": "100 Main Street\nHealthville, CA 90210",
    "57_treatment_location_phone": "555-123-4567",
    "58_treatment_location_additional_provider_id": "BC-332211",
}

service_lines_container = None

def create_form(func_filter_name_contains):
    """ADA Dental Claim Form"""
    global service_lines_container
    with ui.row().classes('-m-4 p-0 w-full scroll-m-0'):
        # Header
        ui.label('ADA Dental Claim Form View').classes('text-lg font-bold text-center w-full bg-primary text-white')

        # Header Information
        with ui.row().classes('w-full no-wrap border gap-0'):
            with ui.column().classes('gap-0 no-wrap'):
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('HEADER INFORMATION').classes('font-bold')
                with ui.row().classes('w-full gap-0'):
                    ui.label('1. Type of Transaction (Mark all applicable boxes)')
                    ui.checkbox('Request for Predetermination/Preauthorization').bind_value(form_data['1_type_of_transaction'], 'request_for_predetermination')
                with ui.row().classes('w-full gap-0'):
                    ui.checkbox('Statement of Actual Services').bind_value(form_data['1_type_of_transaction'], 'statement_of_actual_services')
                    ui.checkbox('EPSDT/Title XIX').bind_value(form_data['1_type_of_transaction'], 'epsdt_title_xix')
                with ui.row().classes('w-full gap-0'):
                    ui.input('2. Predetermination/Preauthorization Number').bind_value(form_data, '2_predetermination_number').props('flat outlined dense').classes('w-full')

        with ui.grid(columns=2).classes('w-full gap-0'):
            # Left Column
            with ui.column().classes('w-full border no-wrap gap-0'):
                 # DENTAL BENEFIT PLAN INFORMATION
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('DENTAL BENEFIT PLAN INFORMATION').classes('font-bold')
                # ui.textarea('3. Company/Plan Name, Address, City, State, Zip Code').bind_value(form_data, '3_company_plan_name_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["3_company_plan_name_address_filter"]))
                ui.input('3. Company/Plan Name').bind_value(form_data, '3_company_plan_name').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["3_company_plan_name_filter"]))
                ui.input('3. Address').bind_value(form_data, '3_company_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["3_company_address_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('3. City').bind_value(form_data, '3_company_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["3_company_city_filter"]))
                    ui.input('3. State').bind_value(form_data, '3_company_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["3_company_state_filter"]))
                    ui.input('3. Zipcode').bind_value(form_data, '3_company_zipcode').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["3_company_zipcode_filter"]))
                ui.input('3a. Payer ID').bind_value(form_data, '3a_payer_id').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["3a_payer_id_filter"]))

                # OTHER COVERAGE
                with ui.row().classes('w-full bg-gray-200 p-1 mt-2'):
                    ui.label('OTHER COVERAGE').classes('font-bold')
                with ui.row().classes('w-full items-center border no-wrap gap-0'):
                    ui.label('4.')
                    ui.checkbox('Dental').bind_value(form_data['4_other_coverage'], 'dental')
                    ui.checkbox('Medical').bind_value(form_data['4_other_coverage'], 'medical')
                # ui.input('5. Name of Policyholder/Subscriber in #4').bind_value(form_data, '5_other_insured_name').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["5_other_insured_name_filter"]))
                with ui.row().classes('w-full items-center border no-wrap gap-0'):
                    ui.input('5. Other Insured (in #4) Last Name').bind_value(form_data, '5_other_insured_lname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["5_other_insured_lname_filter"]))
                    ui.input('5. Other Insured First Name').bind_value(form_data, '5_other_insured_fname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["5_other_insured_fname_filter"]))
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    ui.input('6. Date of Birth (MM/DD/CCYY)').bind_value(form_data, '6_other_insured_dob').props('flat outlined dense').classes('w-1/3')
                    with ui.column().classes('w-1/3 border'):
                         ui.label('7. Gender')
                         ui.toggle(['M', 'F', 'U']).bind_value(form_data, '7_other_insured_gender')
                    ui.input("8. Policyholder/Subscriber ID").bind_value(form_data, '8_other_insured_id').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["8_other_insured_id_filter"]))
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    ui.input("9. Plan/Group Number").bind_value(form_data, '9_other_plan_group_number').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["9_other_plan_group_number_filter"]))
                    with ui.column().classes('w-2/3 border'):
                        ui.label("10. Patient's Relationship to Person named in #5")
                        # CHANGED: Radio to Toggle
                        ui.toggle(['SELF', 'SPOUSE', 'DEPENDENT', 'OTHER']).bind_value(form_data, '10_patient_relationship_to_other_insured')
                # ui.textarea("11. Other Insurance Company/Dental Benefit Plan Name, Address, City, State, Zip Code").bind_value(form_data, '11_other_insurance_company_name_address').props('flat outlined dense').classes('w-full')
                ui.input('11. Other Insurance Company/Dental Benefit Plan Name').bind_value(form_data, '11_other_insurance_company_name').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["11_other_insurance_company_name_filter"]))
                ui.input('11. Address').bind_value(form_data, '11_other_insurance_company_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["11_other_insurance_company_address_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('11. City').bind_value(form_data, '11_other_insurance_company_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["11_other_insurance_company_city_filter"]))
                    ui.input('11. State').bind_value(form_data, '11_other_insurance_company_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["11_other_insurance_company_state_filter"]))
                    ui.input('11. Zipcode').bind_value(form_data, '11_other_insurance_company_zipcode').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["11_other_insurance_company_zipcode_filter"]))

                ui.input("11a. Other Payer ID").bind_value(form_data, '11a_other_payer_id').props('flat outlined dense').classes('w-full')

            # Right Column
            with ui.column().classes('border gap-0'):
                # POLICYHOLDER/SUBSCRIBER INFORMATION
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('POLICYHOLDER/SUBSCRIBER INFORMATION').classes('font-bold')
                # ui.textarea('12. Policyholder/Subscriber Name, Address, City, State, Zip Code').bind_value(form_data, '12_policyholder_name_address').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full gap-0'):
                    ui.input('12. Policyholder First Name').bind_value(form_data, '12_policyholder_fname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_fname_filter"]))
                    ui.input('12. Policyholder Last Name').bind_value(form_data, '12_policyholder_lname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_lname_filter"]))
                ui.input('12. Address').bind_value(form_data, '12_policyholder_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_address_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('12. City').bind_value(form_data, '12_policyholder_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_city_filter"]))
                    ui.input('12. State').bind_value(form_data, '12_policyholder_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_state_filter"]))
                    ui.input('12. Zipcode').bind_value(form_data, '12_policyholder_zipcode').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["12_policyholder_zipcode_filter"]))
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    ui.input('13. Date of Birth (MM/DD/CCYY)').bind_value(form_data, '13_policyholder_dob').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["13_policyholder_dob_filter"]))
                    with ui.column().classes('w-1/3 border'):
                        ui.label('14. Gender')
                        ui.toggle(['M', 'F', 'U']).bind_value(form_data, '14_policyholder_gender').on('Click',lambda:func_filter_name_contains(form_data["14_policyholder_gender_filter"]))
                    ui.input('15. Policyholder/Subscriber ID').bind_value(form_data, '15_policyholder_id').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["15_policyholder_id_filter"]))
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    ui.input('16. Plan/Group Number').bind_value(form_data, '16_policyholder_plan_group_number').props('flat outlined dense').classes('w-1/3')
                    ui.input('17. Employer Name').bind_value(form_data, '17_employer_name').props('flat outlined dense').classes('w-2/3')

                # PATIENT INFORMATION
                with ui.row().classes('w-full p-1'):
                    pass
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('PATIENT INFORMATION').classes('font-bold')
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    with ui.column().classes('w-2/3 border'):
                        ui.label("18. Relationship to Policyholder/Subscriber in #12 Above")
                        ui.toggle(['SELF', 'SPOUSE', 'DEPENDENT CHILD', 'OTHER']).bind_value(form_data, '18_patient_relationship_to_policyholder')
                    ui.input('19. Reserved For Future Use').bind_value(form_data, '19_reserved_for_future_use').props('flat outlined dense').classes('w-1/3')
                # ui.textarea('20. Name, Address, City, State, Zip Code').bind_value(form_data, '20_patient_name_address').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full gap-0'):
                    ui.input('20. Patient First Name').bind_value(form_data, '20_patient_fname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_fname_filter"]))
                    ui.input('20. Patient Last Name').bind_value(form_data, '20_patient_lname').props('flat outlined dense').classes('w-1/2').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_lname_filter"]))
                ui.input('20. Address').bind_value(form_data, '20_patient_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_address_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('20. City').bind_value(form_data, '20_patient_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_city_filter"]))
                    ui.input('20. State').bind_value(form_data, '20_patient_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_state_filter"]))
                    ui.input('20. Zipcode').bind_value(form_data, '20_patient_zipcode').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["20_patient_zipcode_filter"]))
                with ui.row().classes('w-full gap-0 items-stretch border no-wrap'):
                    ui.input('21. Date of Birth (MM/DD/CCYY)').bind_value(form_data, '21_patient_dob').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["21_patient_dob_filter"]))
                    with ui.column().classes('w-1/3 border'):
                        ui.label('22. Gender')
                        ui.toggle(['M', 'F', 'U']).bind_value(form_data, '22_patient_gender').on('Click',lambda:func_filter_name_contains(form_data["22_patient_gender_filter"]))
                    ui.input('23. Patient ID/Account # (Assigned by Dentist)').bind_value(form_data, '23_patient_id').props('flat outlined dense').classes('w-1/3')

        # RECORD OF SERVICES PROVIDED
        with ui.element('div').classes('w-full border-2 border-primary mt-2 p-1'):
            with ui.row().classes('w-full bg-gray-200 p-1'):
                ui.label('RECORD OF SERVICES PROVIDED').classes('font-bold')

            # Header Row
            with ui.grid(columns=11).classes('w-full gap-x-1 font-bold text-xs text-center'):
                ui.label('24. Procedure Date')
                ui.label('25. Area of Oral Cavity')
                ui.label('26. Tooth System')
                ui.label('27. Tooth Number(s)')
                ui.label('28. Tooth Surface')
                ui.label('29. Procedure Code')
                ui.label('29a. Diag. Pointer')
                ui.label('29b. Qty.')
                ui.label('30. Description')
                ui.label('31. Fee')
                ui.label('') # For delete button

            service_lines_container = ui.column().classes('w-full gap-0')

            with ui.row().classes('w-full mt-2'):
                ui.space()
                ui.button('(+) Add Service Line', on_click=lambda: add_service_line(None)).props('color=primary outlined dense')

        with ui.grid(columns=2).classes('w-full gap-0'):
            with ui.column().classes('border'):
                # Missing Teeth Information
                ui.label("33. Missing Teeth Information (Check mark each missing tooth.)").classes('font-bold')
                with ui.row().classes('w-full gap-0 items-stretch'):
                    for i in range(1, 17):
                        with ui.column().classes('border'):
                            ui.label(str(i))
                            ui.checkbox().bind_value(form_data['33_missing_teeth_information'], str(i)).props('outlined dense')
                with ui.row().classes('w-full gap-0'):
                    for i in range(32, 16, -1):
                        with ui.column().classes('border'):
                            ui.label(str(i))
                            ui.checkbox().bind_value(form_data['33_missing_teeth_information'], str(i)).props('outlined dense')

            with ui.column().classes('w-full gap-0 border'):
                with ui.row().classes('w-full gap-0'):
                    ui.input('34. Diagnosis Code List Qualifier').bind_value(form_data, '34_diagnosis_code_list_qualifier').props('flat outlined dense').classes('w-2/3')
                    ui.input('31a. Other Fee(s)').bind_value(form_data, '31a_other_fee').props('flat outlined dense').classes('w-1/3')

                with ui.row().classes('w-full gap-0'):
                    with ui.column().classes('border w-2/3 gap-0'):
                        ui.label("34a. Diagnosis Codes").classes('font-bold')
                        with ui.grid(columns=2).classes('w-full'):
                            ui.input('A.').bind_value(form_data['34a_diagnosis_codes'], 'A').props('flat outlined dense')
                            ui.input('B.').bind_value(form_data['34a_diagnosis_codes'], 'B').props('flat outlined dense')
                            ui.input('C.').bind_value(form_data['34a_diagnosis_codes'], 'C').props('flat outlined dense')
                            ui.input('D.').bind_value(form_data['34a_diagnosis_codes'], 'D').props('flat outlined dense')
                    ui.input('32. Total Fee').bind_value(form_data, '32_total_fee').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["32_total_fee_filter"]))

        ui.input("35. Remarks").bind_value(form_data, '35_remarks').props('flat outlined dense').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["35_remarks_filter"]))
        # Missing Teeth, Remarks, Authorizations
        with ui.grid(columns=2).classes('w-full gap-0'):
            with ui.column().classes('border gap-0 p-2'):
                # Authorizations
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('AUTHORIZATIONS').classes('font-bold')
                with ui.row().classes('w-full items-center gap-0'):
                    ui.input("36. Patient/Guardian Signature").bind_value(form_data, '36_patient_guardian_signature').props('flat outlined dense').classes('w-2/3').on('Focus',lambda:func_filter_name_contains(form_data["36_patient_guardian_signature_filter"]))
                    ui.input("Date").bind_value(form_data, '36_patient_guardian_signature_date').props('flat outlined dense').classes('w-1/3')
                with ui.row().classes('w-full items-center gap-0'):
                    ui.input("37. Subscriber Signature").bind_value(form_data, '37_subscriber_signature').props('flat outlined dense').classes('w-2/3').on('Focus',lambda:func_filter_name_contains(form_data["37_subscriber_signature_filter"]))
                    ui.input("Date").bind_value(form_data, '37_subscriber_signature_date').props('flat outlined dense').classes('w-1/3')

            with ui.column().classes('border gap-0 p-2'):
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('ANCILLARY CLAIM/TREATMENT INFORMATION').classes('font-bold')
                with ui.row().classes('w-full border no-wrap gap-0'):
                    with ui.column().classes('border w-2/3 gap-0'):
                        ui.input('38. Place of Treatment (e.g 11=office; 22=O/P Hospital)').classes('font-bold w-full').props('flat dense').set_enabled(False)
                        ui.input('Place of Service Code').bind_value(form_data, '38_place_of_treatment').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["38_place_of_treatment_filter"]))
                    with ui.column().classes('border w-1/3 gap-0'):
                        with ui.row().classes('w-full no-wrap'):
                            ui.label('39. Enclosures')
                            ui.toggle({'Y':'Y','N':'N'}).bind_value(form_data, '39_enclosures')
                        ui.input('39a. Date of Last SRP').bind_value(form_data, '39a_date_last_srp').props('flat outlined dense').classes('w-full')
                with ui.row().classes('w-full border no-wrap'):
                    with ui.column().classes('w-1/2 border gap-0'):
                        with ui.row().classes('w-full items-center no-wrap'):
                            ui.label('40. Is Treatment for Ortho?')
                            ui.toggle({'Y':'Y','N':'N'}).bind_value(form_data, '40_is_treatment_for_orthodontics')
                    ui.input('41. Date Appliance Placed').bind_value(form_data, '41_date_appliance_placed').props('flat outlined dense').classes('w-1/2')
                with ui.row().classes('w-full border no-wrap'):
                    ui.input('42. Months of Treatment').bind_value(form_data, '42_months_of_treatment').classes('w-1/3').props('flat outlined dense')
                    with ui.column().classes('w-1/3 border gap-0'):
                        ui.label('43. Replacement of Prosthesis?')
                        ui.toggle({'Y':'Y','N':'N'}).bind_value(form_data, '43_replacement_of_prosthesis')
                    ui.input('44. Date of Prior Placement').bind_value(form_data, '44_date_of_prior_placement').classes('w-1/3').props('flat outlined dense')
                with ui.row().classes('w-full border no-wrap'):
                    with ui.column().classes('w-full border gap-0'):
                        with ui.row().classes('w-full no-wrap'):
                            ui.label("45. Treatment Resulting From")
                        with ui.row().classes('w-full no-wrap'):
                            ui.checkbox('Auto Accident').bind_value(form_data['45_treatment_resulting_from'], 'auto_accident')
                            ui.checkbox('Employment').bind_value(form_data['45_treatment_resulting_from'], 'employment')
                            ui.checkbox('Other Accident').bind_value(form_data['45_treatment_resulting_from'], 'other_accident')
                with ui.row().classes('w-full border no-wrap'):
                    ui.input('46. Date of Accident').bind_value(form_data, '46_date_of_accident').props('flat outlined dense').classes('w-1/2')
                    ui.input('47. Auto Accident State').bind_value(form_data, '47_auto_accident_state').props('flat outlined dense').classes('w-1/2')


        # BILLING DENTIST & TREATING DENTIST
        with ui.grid(columns=2).classes('w-full gap-0'):
            with ui.column().classes('border gap-0 p-2'):
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('BILLING DENTIST OR DENTAL ENTITY').classes('font-bold')
                # ui.textarea('48. Name, Address, City, State, Zip Code').bind_value(form_data, '48_billing_dentist_name_address').props('flat outlined dense').classes('w-full')
                ui.input('48. Billing Provider Name').bind_value(form_data, '48_billing_dentist_name').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["48_billing_dentist_name_filter"]))
                ui.input('Address').bind_value(form_data, '48_billing_dentist_address').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["48_billing_dentist_address_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('City').bind_value(form_data, '48_billing_dentist_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["48_billing_dentist_city_filter"]))
                    ui.input('State').bind_value(form_data, '48_billing_dentist_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["48_billing_dentist_state_filter"]))
                    ui.input('Zipcode').bind_value(form_data, '48_billing_dentist_zip').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["48_billing_dentist_zip_filter"]))

                with ui.row().classes('w-full no-wrap gap-0'):
                    ui.input('49. NPI').bind_value(form_data, '49_billing_dentist_npi').classes('w-1/3').props('flat outlined dense').on('Focus',lambda:func_filter_name_contains(form_data["49_billing_dentist_npi_filter"]))
                    ui.input('50. License Number').bind_value(form_data, '50_billing_dentist_license_number').classes('w-1/3').props('flat outlined dense')
                    ui.input('51. SSN or TIN').bind_value(form_data, '51_billing_dentist_ssn_or_tin').classes('w-1/3').props('flat outlined dense').on('Focus',lambda:func_filter_name_contains(form_data["51_billing_dentist_ssn_or_tin_filter"]))
                with ui.row().classes('w-full no-wrap gap-0'):
                    ui.input('52. Phone Number').bind_value(form_data, '52_billing_dentist_phone').classes('w-1/2').props('flat outlined dense').on('Focus',lambda:func_filter_name_contains(form_data["52_billing_dentist_phone_filter"]))
                    ui.input('52a. Additional Provider ID').bind_value(form_data, '52a_billing_dentist_additional_provider_id').classes('w-1/2').props('flat outlined dense')

            with ui.column().classes('border gap-0 p-2'):
                with ui.row().classes('w-full bg-gray-200 p-1'):
                    ui.label('TREATING DENTIST AND TREATMENT LOCATION INFORMATION').classes('font-bold')
                with ui.row().classes('w-full items-center gap-0'):
                    ui.input("53. Treating Dentist Signature").bind_value(form_data, '53_treating_dentist_signature').props('flat outlined dense').classes('w-2/3')
                    ui.input("Date").bind_value(form_data, '53_treating_dentist_signature_date').props('flat outlined dense').classes('w-1/3')
                with ui.row():
                    ui.checkbox('53a. Locum Tenens Treating Dentist?').bind_value(form_data, '53a_locum_tenens_treating_dentist')
                with ui.row().classes('w-full gap-0'):
                    ui.input('54. NPI').bind_value(form_data, '54_treating_dentist_npi').classes('w-1/3').props('flat outlined dense').on('Focus',lambda:func_filter_name_contains(form_data["54_treating_dentist_npi_filter"]))
                    ui.input('55. License Number').bind_value(form_data, '55_treating_dentist_license_number').classes('w-1/3').props('flat outlined dense')
                    ui.input('56a. Provider Specialty Code').bind_value(form_data, '56_provider_specialty_code').classes('w-1/3').props('flat outlined dense')
                # ui.textarea('56. Address, City, State, Zip Code').bind_value(form_data, '56a_treatment_location_address').classes('w-full').props('flat outlined dense')
                ui.input('56. Address').bind_value(form_data, '56a_treatment_location_address_1').props('flat outlined dense').classes('w-full').on('Focus',lambda:func_filter_name_contains(form_data["56a_treatment_location_address_1_filter"]))
                with ui.row().classes('w-full gap-0'):
                    ui.input('City').bind_value(form_data, '56a_treatment_location_city').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["56a_treatment_location_city_filter"]))
                    ui.input('State').bind_value(form_data, '56a_treatment_location_state').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["56a_treatment_location_state_filter"]))
                    ui.input('Zipcode').bind_value(form_data, '56a_treatment_location_zip').props('flat outlined dense').classes('w-1/3').on('Focus',lambda:func_filter_name_contains(form_data["56a_treatment_location_zip_filter"]))

                with ui.row().classes('w-full gap-0'):
                    ui.input('57. Phone Number').bind_value(form_data, '57_treatment_location_phone').classes('w-1/2').props('flat outlined dense')
                    ui.input('58. Additional Provider ID').bind_value(form_data, '58_treatment_location_additional_provider_id').classes('w-1/2').props('flat outlined dense')


def create_service_line_row(line_data: Dict):
    if service_lines_container is None:
        return

    with service_lines_container:
        with ui.grid(columns=11).classes('w-full gap-x-1 items-center border-t-2 border-gray-200'):
            ui.input(label="MM/DD/CCYY").bind_value(line_data, 'procedure_date').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'oral_cavity_area').props('dense outlined max-length=2').classes('w-full')
            ui.input().bind_value(line_data, 'tooth_system').props('dense outlined max-length=2').classes('w-full')
            ui.input().bind_value(line_data, 'tooth_number').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'tooth_surface').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'procedure_code').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'diag_pointer').props('dense outlined max-length=4').classes('w-full')
            ui.input().bind_value(line_data, 'quantity').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'description').props('dense outlined').classes('w-full')
            ui.input().bind_value(line_data, 'fee').props('dense outlined').classes('w-full')
            ui.button(icon='delete', on_click=lambda: delete_service_line(line_data)).props('color=negative flat round dense')

def add_service_line(line_data: Dict = None):
    if line_data is None:
        line_data = {
            "procedure_date": "", "oral_cavity_area": "", "tooth_system": "", "tooth_number": "",
            "tooth_surface": "", "procedure_code": "", "diag_pointer": "", "quantity": "", "description": "",
            "fee": ""
        }
    form_data['service_lines'].append(line_data)
    create_service_line_row(line_data)

async def delete_service_line(line_data_to_delete: Dict):
    """Shows a confirmation dialog and deletes the service line if confirmed."""
    with ui.dialog() as dialog, ui.card():
        ui.label('Are you sure you want to delete this service line?')
        with ui.row().classes('w-full justify-end'):
            ui.button('Cancel', on_Focus=lambda: dialog.submit(False), color='secondary')
            ui.button('Delete', on_Focus=lambda: dialog.submit(True), color='negative')

    confirmed = await dialog
    if confirmed:
        try:
            form_data['service_lines'].remove(line_data_to_delete)
            refresh_service_lines()
            ui.notify('Service line deleted.', color='positive')
        except ValueError:
            ui.notify('Error: Could not find the service line to delete.', color='negative')

def refresh_service_lines():
    if service_lines_container:
        service_lines_container.clear()
        for sl in form_data['service_lines']:
            create_service_line_row(sl)

# Create the form UI
# create_form()

# Pre-populate the service lines from the dummy data
refresh_service_lines()

# Run the app
# ui.run()