import argparse
import subprocess
import sys
from pathlib import Path
import os
import re
import json
import time
import base64
import mimetypes
from pathlib import Path
from typing import Optional, Union
import requests
import concurrent.futures


def _encode_image_to_data_url(img_path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(img_path))
    if mime is None:
        # default to jpeg if unknown
        mime = "image/jpeg"
    with open(img_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:{mime};base64,{b64}"


def _extract_json_from_text(text: str) -> Union[dict, list]:
    m = re.search(r"```json\s*([\s\S]*?)\s*```", text, flags=re.IGNORECASE)
    if m:
        candidate = m.group(1).strip()
        return json.loads(candidate)

    m = re.search(r"```\s*([\s\S]*?)\s*```", text)
    if m:
        candidate = m.group(1).strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    def _scan_balanced(s: str, opener: str, closer: str) -> Optional[Union[dict, list]]:
        start = s.find(opener)
        while start != -1:
            depth = 0
            in_str = False
            escape = False
            for i in range(start, len(s)):
                ch = s[i]
                if in_str:
                    if escape:
                        escape = False
                    elif ch == "\\":
                        escape = True
                    elif ch == '"':
                        in_str = False
                else:
                    if ch == '"':
                        in_str = True
                    elif ch == opener:
                        depth += 1
                    elif ch == closer:
                        depth -= 1
                        if depth == 0:
                            candidate = s[start:i+1]
                            try:
                                return json.loads(candidate)
                            except json.JSONDecodeError:
                                break  # try next start
            start = s.find(opener, start + 1)
        return None

    for opener, closer in (("{", "}"), ("[", "]")):
        parsed = _scan_balanced(text, opener, closer)
        if parsed is not None:
            return parsed

    raise ValueError("No valid JSON found in response text.")


def _post_with_retries(url: str, headers: dict, payload: dict,
                       retries: int = 5, initial_backoff: float = 1.0, timeout: float = 120.0):
    backoff = initial_backoff
    for attempt in range(1, retries + 1):
        resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
        if resp.status_code < 400:
            return resp
        if resp.status_code in (429, 500, 502, 503, 504) and attempt < retries:
            print(f"Request failed with status {resp.status_code}. Retrying in {backoff} seconds...")
            time.sleep(backoff)
            backoff *= 2
            continue

        resp.raise_for_status()

    raise RuntimeError("Failed after retries")


def process_images_with_api(
    images_dir: Union[str, Path],
    prompt1: str,
    prompt2: str,
    *,
    base_url: str = "https://openrouter.ai/api",
    # model: str = "google/gemini-flash-1.5",
    model: str = "google/gemini-2.5-flash-lite",
    api_key: str = "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",
    output_dir: Optional[Union[str, Path]] = None,
    temperature: float = 0.0,
    max_tokens: int = 1000,
    max_workers: int = 10,
) -> None:

    images_dir = Path(images_dir).expanduser().resolve()
    if output_dir is None:
        output_dir = images_dir
    else:
        output_dir = Path(output_dir).expanduser().resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

    if not images_dir.exists() or not images_dir.is_dir():
        raise FileNotFoundError(f"Images directory not found: {images_dir}")

    api_key = api_key or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("API key is required. Set OPENAI_API_KEY or pass api_key=...")

    # Common request bits
    url = base_url.rstrip("/") + "/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # Pick common image types and sort them to ensure sequential processing
    exts = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff"}
    image_paths = sorted(p for p in images_dir.iterdir() if p.is_file() and p.suffix.lower() in exts)

    if not image_paths:
        raise FileNotFoundError(f"No images with extensions {sorted(exts)} found in {images_dir}")

    # Helper function to process a single prompt for a single image, designed to be run in a thread.
    def _send_and_save(prompt_text: str, data_url: str, img_path: Path, suffix: str):
        """Sends a single API request and saves the JSON response."""
        try:
            payload = {
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt_text},
                            {"type": "image_url", "image_url": {"url": data_url}},
                        ],
                    }
                ],
                "temperature": temperature,
                # "max_tokens": max_tokens,
            }

            resp = _post_with_retries(url, headers, payload)
            try:
                resp_json = resp.json()
            except Exception:
                raise RuntimeError(f"Non-JSON response for {img_path.name} (suffix: {suffix}): {resp.text[:500]}")

            # Extract the assistant text safely from possible variants
            content = None
            try:
                content = resp_json["choices"][0]["message"]["content"]
            except (KeyError, IndexError):
                try:
                    parts = resp_json["choices"][0]["message"].get("content", [])
                    if isinstance(parts, list):
                        content = "".join([p.get("text", "") if isinstance(p, dict) else str(p) for p in parts])
                except (KeyError, IndexError):
                    pass

            if not content or not isinstance(content, str):
                raise RuntimeError(f"Could not read message content for {img_path.name} (suffix: {suffix}): {json.dumps(resp_json)[:500]}")

            # Parse JSON from the model's text
            try:
                parsed = _extract_json_from_text(content)
            except Exception as e:
                raise RuntimeError(f"Failed to extract JSON from response for {img_path.name} (suffix: {suffix}): {e}\nRaw text:\n{content}")

            # Save as <image_name>_suffix.json in output_dir
            out_path = output_dir / (img_path.stem + suffix + ".json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(parsed, f, ensure_ascii=False, indent=2)

            print(f"✔ {img_path.name} ({suffix.strip('_')}) → {out_path.name}")
        except Exception as e:
            # Log the error and re-raise to be caught by the future result handler
            print(f"ERROR: Failed to process {img_path.name} ({suffix.strip('_')}). Reason: {e}", file=sys.stderr)
            raise

    # Use a ThreadPoolExecutor to run API calls concurrently
    print(f"Submitting jobs with a maximum of {max_workers} concurrent workers...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_job = {}

        for img_path in image_paths:
            print(f"Queueing jobs for {img_path.name}...")
            try:
                # Encode image once, before submitting jobs for it.
                data_url = _encode_image_to_data_url(img_path)

                # Submit job for prompt 1
                future1 = executor.submit(_send_and_save, prompt1, data_url, img_path, "_basic")
                future_to_job[future1] = f"{img_path.name} (_basic)"

                # Submit job for prompt 2
                future2 = executor.submit(_send_and_save, prompt2, data_url, img_path, "_details")
                future_to_job[future2] = f"{img_path.name} (_details)"

            except Exception as exc:
                print(f"ERROR: Failed to queue jobs for {img_path.name}. Reason: {exc}", file=sys.stderr)

        print(f"\nAll {len(future_to_job)} jobs submitted. Waiting for completion...")
        # Wait for all futures to complete and handle any exceptions
        for future in concurrent.futures.as_completed(future_to_job):
            job_desc = future_to_job[future]
            try:
                # result() will re-raise any exception that occurred in the worker thread
                future.result()
            except Exception as exc:
                # The _send_and_save function already logs detailed errors.
                # This is a final catch-all for the job.
                print(f"ERROR: Job '{job_desc}' failed with an exception.", file=sys.stderr)


def convert_pdf_to_images(pdf_path: str, out_dir: str, dpi: int = 100, device: str = "jpeg") -> None:
    pdf = Path(pdf_path).expanduser().resolve()
    if not pdf.exists():
        print(f"Error: PDF not found: {pdf}", file=sys.stderr)
        sys.exit(1)

    out_path = Path(out_dir).expanduser().resolve()
    out_path.mkdir(parents=True, exist_ok=True)
    base = pdf.stem
    output_pattern = str(out_path / f"{base}_%03d.jpg")

    cmd = [
        "gs",
        "-dNOPAUSE",
        "-dBATCH",
        "-dSAFER",
        f"-sDEVICE={device}",
        f"-r{dpi}",
        f"-sOutputFile={output_pattern}",
        str(pdf),
    ]

    try:
        print("Converting PDF to images...")
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except FileNotFoundError:
        print("Error: Ghostscript not found. On Ubuntu, install it with: sudo apt install ghostscript", file=sys.stderr)
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"Ghostscript failed with exit code {e.returncode}.", file=sys.stderr)
        print(f"Ghostscript stdout:\n{e.stdout}", file=sys.stderr)
        print(f"Ghostscript stderr:\n{e.stderr}", file=sys.stderr)
        sys.exit(e.returncode)

    print(f"Done. Images written to: {out_path}")

def main():
    parser = argparse.ArgumentParser(description="Convert a PDF to images and process each page with two API prompts.")
    parser.add_argument("pdf", help="Path to the input PDF file")
    parser.add_argument("outdir", help="Directory to save output images and JSON (will be created if missing)")
    parser.add_argument("--dpi", "-r", type=int, default=200, help="Output resolution in DPI (default: 200)")
    parser.add_argument("--device", "-d", default="jpeg", help="Ghostscript device (default: jpeg)")
    parser.add_argument("--workers", "-w", type=int, default=20, help="Maximum number of simultaneous API calls (default: 20)")
    args = parser.parse_args()

    convert_pdf_to_images(args.pdf, args.outdir, dpi=args.dpi, device=args.device)

    # Load the two prompt files
    prompt1_path = Path("/home/edipod/edi_gen_ai/tools/prompt1.txt") # cloud path DO NOT REMOVE
    if not prompt1_path.exists():
        raise FileNotFoundError(f"Missing prompt file: {prompt1_path}")
    prompt1_text = prompt1_path.read_text(encoding="utf-8").strip()

    prompt2_path = Path("/home/edipod/edi_gen_ai/tools/prompt2.txt") # cloud path DO NOT REMOVE
    if not prompt2_path.exists():
        raise FileNotFoundError(f"Missing prompt file: {prompt2_path}")
    prompt2_text = prompt2_path.read_text(encoding="utf-8").strip()

    print("\nStarting API processing...")
    process_images_with_api(
        images_dir=args.outdir,
        prompt1=prompt1_text,
        prompt2=prompt2_text,
        max_workers=args.workers, # Pass concurrency level
        # You can override other parameters here if needed, e.g.:
        # base_url="https://api.openai.com/v1",
        # model="gpt-4o-mini",
        # output_dir="out_json"
    )

if __name__ == "__main__":
    main()
