from nicegui import ui, app
from pathlib import Path
from typing import Dict, Any
from functools import partial
from datetime import datetime
from tools.cms_1500 import create_form, form_data, refresh_service_lines
from tools.xml_parser import parse_837_xml
from tools.edi_table_editor import create_table_editor, filter_name_contains, createCombinedPdfForAllClaims
import logging, os


logging.basicConfig(level=logging.INFO)
BASE_DIR = Path(__file__).resolve().parent.parent


def create_content(directory: str):
    """Creates the new EDI 837 viewer content based on the wireframe."""
    ui.add_head_html('<style>body { overflow: hidden; }</style>')
    with ui.row().classes("w-full gap-0 m-0 p-0 h-dvh"):
        # --- Data Loading ---
        workdir = BASE_DIR / "claims_upload" / directory
        xml_files = list(workdir.glob("*.xml"))
        if not xml_files:
            ui.label("No XML file found in this directory.").classes(
                "text-lg text-negative p-4"
            )
            return
        claim_data = parse_837_xml(xml_files[0])
        if "error" in claim_data:
            ui.label(f"Error processing file: {claim_data['error']}").classes(
                "text-lg text-negative p-4"
            )
            return
        # --- Page Header ---
        with ui.row().classes("w-full items-center gap").style('height: 5dvh'):
            ui.button(
                icon="arrow_back", on_click=ui.navigate.back, color="primary"
            ).props("flat round dense")
            ui.label(f"Claim Details: {xml_files[0].name}").classes(
                "text-lg font-semibold"
            )
        
        # --- Main Content Layout (2 columns) ---
        with ui.splitter(value=30).classes('w-full').style('height: 95dvh') as splitter:
            with splitter.before:
                # --- Left Panel: EDI 837 Tree Editor ---
                load_claim_for_editor = create_table_editor()

            with splitter.after:
                # --- Right Panel: Claim Grid and CMS Form ---
                files = [
                    f for f in os.listdir(workdir)
                    if os.path.isfile(os.path.join(workdir, f))
                    and not (f.endswith(".xml") or f == "info.json")
                ]

                with ui.row().classes('gap-2'):
                    ui.button("Download Full EDI",on_click=lambda: ui.download(f'{workdir}/{files[0]}',f'{xml_files[0].name.replace('.xml','')}.edi'))
                    ui.button("Generate Full PDF", on_click=lambda: createCombinedPdfForAllClaims(claim_data, xml_files[0].name))

                # --- Master Claim List ---
                columns = [
                {
                    "name": "claim_id",
                    "label": "Claim ID",
                    "field": "claim_id",
                    "sortable": True,
                    "filter": "agNumberColumnFilter",
                },
                {
                    "name": "patient_name",
                    "label": "Patient Name",
                    "field": "patient_name",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "dob",
                    "label": "DOB",
                    "field": "dob",
                    "sortable": True,
                    "filter": "agDateColumnFilter",
                },
                {
                    "name": "insurance",
                    "label": "Insurance",
                    "field": "insurance",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "subscriber_id",
                    "label": "Subscriber ID",
                    "field": "subscriber_id",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "provider_name",
                    "label": "Provider Name",
                    "field": "provider_name",
                    "sortable": True,
                    "filter": "agTextColumnFilter",
                },
                {
                    "name": "amount",
                    "label": "Amt",
                    "field": "amount",
                    "sortable": True,
                    "filter": "agNumberColumnFilter",
                },
                {
                    "name": "date",
                    "label": "Date",
                    "field": "date",
                    "sortable": True,
                    "filter": "agDateColumnFilter",
                },
                ]
                rows = [
                    {
                        "claim_id": c.get("claim_info", {}).get("claim_control_number", "N/A"),
                        # "patient_name": f"{c.get('subscriber', {}).get('first_name', '')} {c.get('subscriber', {}).get('last_name', '')}".strip(),
                        "patient_name": f"{c.get('patient', c.get('subscriber', {})).get('first_name', '')} {c.get('patient', c.get('subscriber', {})).get('last_name', '')}".strip(),
                        "dob": f'{datetime.strptime(c.get("patient", {}).get("dob", c.get("subscriber", {}).get("dob", "")),"%m/%d/%Y").date() if c.get("patient", {}).get("dob", c.get("subscriber", {}).get("dob", "")) != '' else '1/1/1800'}',
                        "insurance": c.get("subscriber", {}).get("sub_insurance_name", "N/A"),
                        "subscriber_id": c.get("subscriber", {}).get("subscriber_id", "N/A"),
                        "provider_name": c.get("billing_provider", {}).get("name", "N/A"),
                        "amount": float(c.get("claim_info", {}).get("total_claim_charge_amount", "0.00")),
                        "date": f'{datetime.strptime(claim_data.get("hierarchical_transaction", {}).get("creation_date", ""),"%m/%d/%Y").date() if claim_data.get("hierarchical_transaction", {}).get("creation_date", "") != '' else '1/1/1800'}',
                    }
                    for c in claim_data.get("claims", [])
                ]
                if not rows:
                    ui.label("No claims found in the XML file.").classes("p-4")
                    return

                grid = ui.aggrid(
                    {
                        "columnDefs": columns,
                        "rowData": rows,
                        "rowSelection": "single",
                        "autoSizeColumns": True,
                    }
                ).classes('h-1/3')

                def handle_selection(e):
                    if e.args['data']:
                        populate_cms_form(e.args["data"]["claim_id"])

                grid.on('cellClicked', handle_selection)

                @ui.refreshable
                def populate_cms_form(claim_id: str = None):
                    if claim_id is None:
                        if not rows:
                            return
                        claim_id = rows[0]["claim_id"]

                    # --- Load data into the tree view ---
                    if load_claim_for_editor:
                        xml_file_path = str(xml_files[0])
                        load_claim_for_editor(claim_id, xml_file_path)

                    full_claim_obj = next(
                        (
                            c
                            for c in claim_data.get("claims", [])
                            if c.get("claim_info", {}).get("claim_control_number") == claim_id
                        ),
                        None,
                    )
                    if not full_claim_obj:
                        return

                    # Clear previous data
                    for key in form_data:
                        if key != 'service_lines':
                            form_data[key] = ""
                    form_data['service_lines'] = []

                    #--- Populate Header Information ---
                    subscriber = full_claim_obj.get("subscriber", {})
                    other_insured = full_claim_obj.get("other_insured", {})
                    patient = full_claim_obj.get("patient", subscriber) 
                    billing_provider = full_claim_obj.get("billing_provider", {})
                    claim_info = full_claim_obj.get("claim_info", {})
                    referring_provider = full_claim_obj.get("referring_provider", {})
                    purchased_service = full_claim_obj.get("purchased_service", {})

                    form_data["1_insurance_type"] = subscriber.get("insurance_type", "")
                    form_data["1_insurance_type_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/SBR/SBR09"
                    form_data["1a_insured_id_number"] = subscriber.get("subscriber_id", "")
                    form_data["1a_insured_id_number_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM109"
                    form_data["2_patient_name"] = f'{patient.get("last_name", "")}, {patient.get("first_name", "")}'
                    form_data["2_patient_name_filter"] = "2010CA/NM1" if full_claim_obj.get("patient") else "2010BA/NM1"

                    form_data["2_patient_fname"] = f'{patient.get("first_name", "")}'
                    form_data["2_patient_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/NM1/NM104" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM104"
                    form_data["2_patient_mname"] = f'{patient.get("middle_name", "") if patient.get("middle_name", "") != None else "" }'
                    form_data["2_patient_mname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/NM1/NM105" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM105"
                    form_data["2_patient_lname"] = f'{patient.get("last_name", "")}'
                    form_data["2_patient_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/NM1/NM103" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM103"


                    form_data["3_patient_birth_date"] = patient.get("dob", "")
                    form_data["3_patient_birth_date_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/DMG/DMG02" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG02"
                    form_data["3_patient_sex"] = "M" if patient.get("gender", "") == "M" else "F" if patient.get("gender", "") == "F" else ""
                    form_data["3_patient_sex_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/DMG/DMG03" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/DMG/DMG03"
                    form_data["4_insured_name"] = f'{subscriber.get("last_name", "")}, {subscriber.get("first_name", "")}'
                    form_data["4_insured_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1"

                    form_data["4_insured_lname"] = f'{subscriber.get("last_name", "")}'
                    form_data["4_insured_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM103"
                    form_data["4_insured_fname"] = f'{subscriber.get("first_name", "")}'
                    form_data["4_insured_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM104"
                    form_data["4_insured_mname"] = f'{subscriber.get("middle_name", "")}' if subscriber.get("middle_name", "") != None else ""
                    form_data["4_insured_mname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/NM1/NM105"

                    form_data["5_patient_address_street"] = patient.get("address", "")
                    form_data["5_patient_address_street_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N3/N301" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N3/N301"
                    form_data["5_patient_address_city"] = patient.get("city", "")
                    form_data["5_patient_address_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N401" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N401"
                    form_data["5_patient_address_state"] = patient.get("state", "")
                    form_data["5_patient_address_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N402" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N402"
                    form_data["5_patient_address_zip"] = patient.get("zip", "")
                    form_data["5_patient_address_zip_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2000C/2010CA/N4/N403" if full_claim_obj.get("patient") else "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N403"
                    form_data["6_patient_relationship"] = patient.get("relationship", "").upper()
                    form_data["6_patient_relationship_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/SBR/SBR02"
                    form_data["7_insured_address_street"] = subscriber.get("address", "")
                    form_data["7_insured_address_street_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N3/N301"
                    form_data["7_insured_address_city"] = subscriber.get("city", "")
                    form_data["7_insured_address_city_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N401"
                    form_data["7_insured_address_state"] = subscriber.get("state", "")
                    form_data["7_insured_address_state_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N402"
                    form_data["7_insured_address_zip"] = subscriber.get("zip", "")
                    form_data["7_insured_address_zip_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2010BA/N4/N403"

                    form_data["9_other_insured_name"] = f'{other_insured.get("last_name", "")}, {other_insured.get("first_name", "")}, {other_insured.get("middle_name", "")}' if other_insured else ''
                    form_data["9_other_insured_name_filter"] = "2330A/NM1"

                    form_data["9_other_insured_fname"] = f'{other_insured.get("first_name", "")}' if other_insured else ''
                    form_data["9_other_insured_fname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM104"
                    form_data["9_other_insured_mname"] = f'{other_insured.get("middle_name", "")}' if other_insured else ''
                    form_data["9_other_insured_mname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM105"
                    form_data["9_other_insured_lname"] = f'{other_insured.get("last_name", "")}' if other_insured else ''
                    form_data["9_other_insured_lname_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM103"


                    form_data["9a_other_insured_policy_number"] = other_insured.get("policy_group_id", "")
                    form_data["9a_other_insured_policy_number_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/2330A/NM1/NM109"
                    form_data["9d_insurance_plan_name"] = other_insured.get("plan_name", "")
                    form_data["9d_insurance_plan_name_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2320/SBR/SBR09"

                    form_data["10a_employment"] = "Y" if claim_info.get("clm_related_causes_01", "") == "EM" or claim_info.get("clm_related_causes_02", "") == "EM" else "N"
                    form_data["10a_employment_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM11"
                    form_data["10b_auto_accident"] = "Y" if claim_info.get("clm_related_causes_01", "") == "AA" or claim_info.get("clm_related_causes_02", "") == "AA" else "N"
                    form_data["10b_auto_accident_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM11"
                    form_data["10b_auto_accident_place"] = claim_info.get("clm_related_causes_04", "") if claim_info.get("clm_related_causes_04", "") != "" else ""
                    form_data["10b_auto_accident_place_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM11-04"
                    form_data["10c_other_accident"] = "Y" if claim_info.get("clm_related_causes_01", "") == "OA" else "N"
                    form_data["10c_other_accident_filter"] = "837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/CLM/CLM11-01"

                    form_data["11_insured_policy_group_or_feca_number"] = subscriber.get("sub_group_feca_num", "")
                    form_data["11a_insured_birth_date"] = subscriber.get("dob", "")
                    form_data["11a_insured_sex"] = "MALE" if subscriber.get("gender", "") == "M" else "FEMALE" if subscriber.get("gender", "") == "F" else ""
                    form_data["11b_other_claim_id"] = subscriber.get("sub_other_claim_id", "")
                    form_data["11c_insurance_plan_name"] = subscriber.get("sub_insurance_name", "")
                    form_data["11d_is_there_another_health_benefit_plan"] = "YES" if other_insured.get("policy_group_id", "") != "" else "NO"

                    form_data["14_date_of_current_illness"] = claim_info.get("date_current_illness", "") if claim_info.get("date_current_illness_qual", "") in {"431","439","484"} else ""
                    form_data["14_qual"] = claim_info.get("date_current_illness_qual", "") if claim_info.get("date_current_illness_qual", "") in {"431","439","484"} else ""

                    form_data["15_other_date"] = claim_info.get("date_current_illness", "")  if claim_info.get("date_current_illness_qual", "") not in {"431", "439", "484","454", "360", "361", "435", "096", ""} else ""
                    form_data["15_qual"] = claim_info.get("date_current_illness_qual", "")  if claim_info.get("date_current_illness_qual", "") not in {"431","439","484","454", "360", "361", "435", "096", ""} and claim_info.get("date_current_illness_qual", "") != "-1" else ""

                    form_data["16_dates_patient_unable_to_work_from"] = claim_info.get("disability_begins", "")
                    form_data["16_dates_patient_unable_to_work_to"] = claim_info.get("disability_ends", "")

                    form_data["17_qualifier"] = referring_provider.get("qual", "")
                    form_data["17_name_of_referring_provider"] = ((referring_provider.get("first_name", "") if referring_provider.get("first_name", "") != "" else "") + " " + (referring_provider.get("mid_name", "") if referring_provider.get("mid_name", "") != "" else "") + " " + (referring_provider.get("last_name", "") if referring_provider.get("last_name", "") != "" else "")).strip()
                    form_data["17b_npi"] = referring_provider.get("npi", "")

                    form_data["18_hospitalization_dates_from"] = claim_info.get("hosp_admission", "")
                    form_data["18_hospitalization_dates_to"] = claim_info.get("hosp_discharge", "")
                    form_data["20_outside_lab"] = "YES" if purchased_service.get("charge", "") != "" else "NO"
                    form_data["20_charges"] = purchased_service.get("charge", "") if purchased_service.get("charge", "") != "" else ""
                    form_data["21_icd_ind_1"] = claim_info.get("diagnoses_q_1", "")
                    form_data["21_icd_ind_2"] = claim_info.get("diagnoses_q_2", "")
                    form_data["22_resubmission_code"] = claim_info.get("resubmission_code", "")
                    form_data["22_original_ref_no"] = claim_info.get("original_ref_no", "")

                    form_data["23_prior_authorization_number"] = claim_info.get("prior_authorization_number", "")
                    form_data["25_federal_tax_id_number"] = billing_provider.get("tax_id", "")
                    form_data["25_ein"] = True # Assuming EIN
                    form_data["26_patients_account_no"] = claim_info.get("patient_control_number", "")
                    form_data["27_accept_assignment"] = "YES" if claim_info.get("assignment_acceptance", "") == "A" else ( "NO" if claim_info.get("assignment_acceptance", "") == "C" else "" )
                    form_data["28_total_charge"] = claim_info.get("total_claim_charge_amount", "")
                    form_data["29_amount_paid"] = claim_info.get("amount_paid", "")

                    form_data["31_signature_of_physician"] = f'Signature on File'
                    form_data["31_date"] = claim_data.get("hierarchical_transaction", {}).get("creation_date","")
                    form_data["32_service_facility_location_information_a"] = f'{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
                    form_data["32_service_facility_location_information_b"] = billing_provider.get("npi", "")

                    form_data["33_billing_provider_info_and_ph"] = billing_provider.get("phone", "")
                    form_data["33_billing_provider_info_and_ph_a"] = f'{billing_provider.get("name", "")}\n{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
                    form_data["33_billing_provider_info_and_ph_b"] = billing_provider.get("npi", "")


                    #--- Populate Diagnoses ---
                    diagnoses = full_claim_obj.get('diagnoses', [])
                    for i, dx in enumerate(diagnoses[:12]): # CMS form has 12 diagnosis slots
                        form_data[f'21_diagnosis_{chr(97+i)}'] = dx.get('code', '')

                    #--- Populate Service Lines ---
                    service_lines = full_claim_obj.get("service_lines", [])
                    for sl in service_lines:
                        modifiers = sl.get("modifiers", [])
                        
                        # Pad the modifiers list to always have 4 elements
                        modifiers.extend([""] * (4 - len(modifiers)))
                        
                        new_line = {
                            "date_of_service_from": sl.get("date_of_service", ""),
                            "date_of_service_to": sl.get("date_of_service", ""),
                            "place_of_service": claim_info.get("place_of_service_code", ""),
                            "procedures_cpt_hcpcs": sl.get("procedure_code", ""),
                            "modifier_1": modifiers[0],
                            "modifier_2": modifiers[1],
                            "modifier_3": modifiers[2],
                            "modifier_4": modifiers[3],
                            "diagnosis_pointer": " ".join(map(str, sl.get("diagnosis_pointers", []))),
                            "charges": sl.get("line_item_charge_amount", ""),
                            "days_or_units": sl.get("quantity", ""),
                            "rendering_provider_id_npi": sl.get("rendering_provider", {}).get("npi", billing_provider.get("npi", "")),
                        }
                        form_data['service_lines'].append(new_line)

                    refresh_service_lines()

                with ui.scroll_area().classes('w-full m-0 p-0 gap-0 h-2/3'):
                    # --- Detail Area (CMS-1500 Form) ---
                    create_form( filter_name_contains )

                    # Initial population of the form
                    populate_cms_form()
