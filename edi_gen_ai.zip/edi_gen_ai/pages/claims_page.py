# pages/claims_page.py
import asyncio
import json
import shutil
import sys
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

from nicegui import ui, events, app

from tools.utils import run_and_stream, sanitize_filename, log
from tools.xmltotree import xml_tree_gen

BASE_DIR = Path(__file__).resolve().parent.parent


def create_content():
    """Creates the content for the Claims tab."""
    with ui.column().classes('p-4 gap-3 max-w-6xl w-full'):
        with ui.card().classes('w-full'):
            ui.label('Upload a text file to start processing.').classes('text-lg font-medium')
            upload = ui.upload(
                label='Upload Text File',
                on_upload=lambda e: handle_upload(e, table),
                auto_upload=True,
                multiple=False,
                max_file_size=100_000_000,
            ).props('accept=*/*')

        # This will be populated with a spinner during processing
        status_container = ui.row().classes('w-full items-center justify-center pt-4')
        
        # History Table
        ui.label('Processing History').classes('text-lg text-gray-800 font-medium pt-8')
        
        columns = [
            {'name': 'directory', 'label': 'Directory', 'field': 'directory', 'sortable': True},
            {'name': 'filename', 'label': 'Filename', 'field': 'filename', 'sortable': True},
            {'name': 'type', 'label': 'Type', 'field': 'type', 'sortable': True},
            {'name': 'created_at', 'label': 'Created At', 'field': 'created_at', 'sortable': True},
            {'name': 'actions', 'label': 'Actions', 'field': 'actions'},
        ]
        
        table = ui.table(columns=columns, rows=[], row_key='directory').classes('w-full h-96')
        
        with table.add_slot('body-cell-actions', """
            <q-td :props="props">
                <q-btn @click="$parent.$emit('view_xml', props.row)" icon="visibility" flat dense color="primary" />
                <q-btn @click="$parent.$emit('delete', props.row)" icon="delete" flat dense color="negative" />
            </q-td>
        """):
            pass

        with ui.row().classes('w-full items-center justify-between pt-4'):
            ui.label('Processing Log').classes('text-lg text-gray-800 font-medium')
            log_toggle = ui.switch('Show Logs', value=False)

        log_area = ui.textarea(
            placeholder='Logs are hidden. Toggle "Show Logs" to view details.',
        ).props('rows=16 autogrow readonly').classes('w-full')

        log_area.bind_visibility_from(log_toggle, 'value')

        path_label = ui.label('').classes('text-caption text-grey-7')

        def get_history():
            """Scans the claims_upload directory and returns a list of processing results."""
            root = BASE_DIR / 'claims_upload'
            history = []
            if not root.exists():
                return history
        
            for d in sorted(root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
                if d.is_dir():
                    xml_files = list(d.glob('*.xml'))
                    if xml_files:
                        xml_file = xml_files[0]
                        row = {
                            'directory': d.name,
                            'filename': xml_file.name.replace('.xml', ''),
                            'created_at': datetime.fromtimestamp(d.stat().st_mtime).strftime(
                                '%Y-%m-%d %H:%M:%S'),
                            'path': str(d),
                            'type': 'N/A'
                        }
                        info_file = d / 'info.json'
                        if info_file.exists():
                            with open(info_file, 'r') as f:
                                info = json.load(f)
                                row['type'] = info.get('type', 'N/A')
                        history.append(row)
            return history

        async def delete_directory(directory_path: str):
            """Deletes a directory after user confirmation."""
            dialog = ui.dialog()
            with dialog, ui.card():
                ui.label(f'Are you sure you want to delete the directory "{Path(directory_path).name}"?')
                with ui.row().classes('w-full justify-end'):
                    ui.button('Cancel', on_click=dialog.close)
                    
                    async def perform_delete():
                        try:
                            shutil.rmtree(directory_path)
                            ui.notify(f'Successfully deleted {Path(directory_path).name}', color='positive')
                            await asyncio.sleep(0.5) # Give time for notification
                            table.rows = get_history()
                        except Exception as ex:
                            ui.notify(f'Error deleting directory: {ex}', color='negative')
                        dialog.close()

                    ui.button('Delete', on_click=perform_delete, color='negative')
            await dialog

        def build_table_rows():
            table.rows = get_history()

        async def handle_delete(row):
            await delete_directory(row['path'])

        async def handle_view_xml(row):
            """Navigates to the claim details page."""
            directory_name = row['directory']
            claim_type = row['type']
            ui.navigate.to(f'/claims/{("dental/" + directory_name) if claim_type == '837-Den' else directory_name}')

        table.on('delete', lambda msg: handle_delete(msg.args))
        table.on('view_xml', lambda msg: handle_view_xml(msg.args))

        # Initial table load
        build_table_rows()

        async def handle_upload(e: events.UploadEventArguments, table_ref: ui.table):
            log_toggle.value = False
            log_area.value = ''
            log_area.props('placeholder="Logs are hidden. Toggle \'Show Logs\' to view details."')

            upload.disable()
            with status_container:
                spinner = ui.spinner(color='primary', size='lg')
            log_area.props('placeholder="Processing logs will appear here..."')

            orig_name = sanitize_filename(e.name or 'upload.txt')
            data = e.content.read()

            root = BASE_DIR / 'claims_upload'
            root.mkdir(exist_ok=True)
            unique = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
            workdir = root / unique
            workdir.mkdir(parents=True, exist_ok=True)

            input_path = workdir / orig_name
            input_path.write_bytes(data)

            path_label.set_text(f'Working directory: {workdir}')
            await log(log_area, f'Created working directory: {unique}')
            await log(log_area, f'Saved uploaded file as: {orig_name}')

            try:
                output_xml_path = input_path.with_suffix('.xml')
                await run_and_stream(
                    log_area,
                    f'Converting {input_path.name} to XML',
                    'x12xml', 
                    # '-c', '/home/rathin/edipod/files/pyx12/bin/pyx12.conf.xml', 
                    '-c', '/root/edipod/tools/pyx12-master/bin/pyx12.conf.xml', 
                    '-o', str(output_xml_path),
                    str(input_path)
                )

                if output_xml_path.exists():
                    await log(log_area, f"SUCCESS: Created {output_xml_path.name}")
                    
                    # Extract claim type and create info.json
                    claim_type = extract_claim_type(output_xml_path)
                    if claim_type:
                        info_path = workdir / 'info.json'
                        with open(info_path, 'w') as f:
                            json.dump({'type': claim_type}, f)
                        await log(log_area, f"Saved claim type '{claim_type}' to info.json")
                    else:
                        await log(log_area, "Could not determine claim type from XML.")
                        
                else:
                    await log(log_area, f"WARNING: x12xml ran but did not create {output_xml_path.name}")

            except Exception as ex:
                await log(log_area, f"FATAL ERROR during processing: {ex}")
                ui.notify('An error occurred. Check the log for details.', color='negative')
                log_toggle.value = True

            finally:
                status_container.clear()
                upload.enable()
                ui.notify('Processing complete ✅')
                build_table_rows()
                
def extract_claim_type(xml_path: Path) -> str | None:
    """Extracts the claim type from the XML file based on GS and ST segments."""
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        # Find GS01 and ST01 using the correct structure
        gs_code_element = root.find("./loop[@id='ISA_LOOP']/loop[@id='GS_LOOP']/seg[@id='GS']/ele[@id='GS08']")
        st_code_element = root.find("./loop[@id='ISA_LOOP']/loop[@id='GS_LOOP']/loop[@id='ST_LOOP']/seg[@id='ST']/ele[@id='ST01']")
        
        if gs_code_element is not None and st_code_element is not None:
            gs_code = gs_code_element.text
            st_code = st_code_element.text
            
            if "837" in st_code:
                if gs_code == '005010X222A1':
                    return '837-Pro'  # Professional
                elif gs_code == '005010X224A2':
                    return '837-Den'  # Dental
                elif gs_code == '005010X223A2':
                    return '837-Ins'  # Institutional
                    
    except ET.ParseError as e:
        print(f"Error parsing XML file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    return None
