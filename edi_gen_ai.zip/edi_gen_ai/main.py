# main.py
import os

from nicegui import ui, app

# Import the page builders and authentication
from components.layout import build_layout
from pages.login import login_page, require_auth_or_redirect
from pages import details_page, documents_page, claims_page, claims_details_page, dental_claims_details_page


@ui.page('/')
def main_page():
    """Main page that requires authentication and shows the main layout."""
    if not require_auth_or_redirect():
        return  # Stop execution if not authenticated
    # Ensure the 'Home' tab is active on initial load
    if not app.storage.user.get('active_tab'):
        app.storage.user['active_tab'] = 'Home'
    
    build_layout()


@ui.page('/claims')
def claims():
    """Page to display claims."""
    if not require_auth_or_redirect():
        return
    claims_page.create_content()


@ui.page('/documents/{directory_name}')
def show_documents(directory_name: str):
    """Page to display documents for a specific directory."""
    if not require_auth_or_redirect():
        return
    documents_page.create(directory_name)


@ui.page('/claims/{directory}')
def claim_details(directory: str):
    """Page to display claim details."""
    if not require_auth_or_redirect():
        return
    claims_details_page.create_content(directory)

@ui.page('/claims/dental/{directory}')
def claim_details(directory: str):
    """Page to display dental claim details."""
    if not require_auth_or_redirect():
        return
    dental_claims_details_page.create_content(directory)


if __name__ in {"__main__", "__mp_main__"}:
    # Use the secret from the original main_c.py for session consistency
    storage_secret = os.getenv('STORAGE_SECRET', '978q3v59nytc49fhamfr098q34c8nocqf')
    
    # Run the app
    app.add_static_files('/uploads', 'uploads')
    ui.run(
        title='EDI Processor',
        storage_secret=storage_secret,
        reload=True  # Set to True for development to auto-reload on changes
    )