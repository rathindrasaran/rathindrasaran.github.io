VALID_CREDENTIALS = {
    'paul': 'Nimda@321',
    'sundar_bala': 'Super@User@321'
}

API_KEY = ""

PRODUCTION = True

PROJECT_DIR = '/home/edipod/edi_gen_ai/' if PRODUCTION else '/home/rathin/Github/projects/python-workspace/edi_gen_ai/workspace/edi_gen_ai/'
UPLOAD_PATH = PROJECT_DIR+'uploads'
PYX12CONFIG_PATH = '/home/edipod/tools/pyx12-master/bin/pyx12.conf.xml' if PRODUCTION else '/home/rathin/edipod/files/pyx12/bin/pyx12.conf.xml'
EDI837D_SCHEMA = PROJECT_DIR+'tools/837.5010.X224.A2.xml'
EDI837P_SCHEMA = PROJECT_DIR+'tools/837.5010.X222.A1.xml'
PROMPT1_PATH = PROJECT_DIR+'tools/prompt1.txt'
PROMPT2_PATH = PROJECT_DIR+'tools/prompt2.txt'
