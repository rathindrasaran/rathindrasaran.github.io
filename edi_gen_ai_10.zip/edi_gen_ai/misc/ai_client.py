import requests

def call_openai_compatible_api(
    api_base_url: str,
    api_key: str,
    model: str,
    prompt: str,
    timeout: int = 30,
) -> str:
    # For OpenRouter, api_base_url should look like: "https://openrouter.ai/api/v1"
    url = f"{api_base_url.rstrip('/')}/chat/completions"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        # Optional but recommended for OpenRouter attribution:
        # "HTTP-Referer": "https://yourapp.example",
        # "X-Title": "My App Name",
    }

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.7,
    }

    resp = requests.post(url, headers=headers, json=payload, timeout=timeout)

    # If it's a normal HTTP error, raise it with the server's message.
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:500]}") from e

    # If the server returned non-JSON (HTML/plaintext/empty), show diagnostics.
    try:
        data = resp.json()
    except ValueError as e:
        ct = resp.headers.get("Content-Type", "")
        body_preview = (resp.text or "")[:800]
        raise RuntimeError(
            "Response was not valid JSON.\n"
            f"Status: {resp.status_code}\n"
            f"Content-Type: {ct}\n"
            f"Body preview:\n{body_preview}"
        ) from e

    return data["choices"][0]["message"]["content"]

def keep_numbers_and_dots(text: str) -> str:
    """
    Removes all characters except digits (0–9) and dots (.).
    """
    return re.sub(r"[^0-9.]", "", text)


# text = call_openai_compatible_api(
#     api_base_url="https://openrouter.ai/api/v1",
#     api_key="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",
#     model="google/gemini-2.5-flash-lite",
#     prompt="Please return the date in YYYYMMDD format in json format as 'date' from the mentioned date : 11/3/2025 12:00:00AM"
# )

# print(f"date: {text}")

import re
from typing import List, Dict, Any, Tuple, Set

def filter_rows(rows: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
    if query is None or len(str(query).strip()) < 3:
        return rows

    q = str(query).strip()

    # Supports:
    #   REF02(REF01=F8)
    #   REF/REF02(REF01=F8)
    #   2300/REF/REF02(REF01=F8)
    #   2300/DTP/DTP03(DTP01=...) etc.
    m = re.match(
        r'^\s*([A-Za-z0-9_/]+)\s*\(\s*([A-Za-z0-9_/]+)\s*=\s*([^)]+?)\s*\)\s*$',
        q
    )

    # Non-structured query: substring search across values
    if not m:
        ql = q.lower()
        return [
            row for row in rows
            if any(ql in str(value).lower() for value in row.values())
        ]

    target_expr, cond_expr, cond_value = m.groups()
    cond_value = cond_value.strip()

    def split_expr(expr: str) -> Tuple[str, str]:
        """
        "2300/DTP/DTP03" -> ("2300/DTP", "DTP03")
        "REF02" -> ("", "REF02")
        "REF/REF02" -> ("REF", "REF02")
        """
        parts = [p for p in expr.split("/") if p]
        if not parts:
            return ("", "")
        node = parts[-1]
        prefix = "/".join(parts[:-1])  # may be ""
        return (prefix, node)

    def has_scope(xml_path: str, scope: str) -> bool:
        """
        Scope match on PATH SEGMENTS (boundary-aware), not substring.

        scope="2300/DTP" matches:
          .../2300/DTP/...
        but NOT:
          .../2300/2400/DTP/...
        """
        if not scope:
            return True
        xp_norm = str(xml_path).strip("/")
        scope_norm = str(scope).strip("/")
        return re.search(rf'(^|/){re.escape(scope_norm)}(/|$)', xp_norm) is not None

    target_prefix, target_node = split_expr(target_expr)
    cond_prefix, cond_node = split_expr(cond_expr)

    def extract_index(xml_path: str, node: str) -> Tuple[str, bool]:
        """
        Returns (index, is_explicit).
        - DTP03[3] -> ("3", True)
        - DTP03 (present, unindexed) -> ("1", False)
        - not present -> ("", False)
        """
        xp = str(xml_path)

        m_idx = re.search(rf'{re.escape(node)}\[(\d+)\]', xp)
        if m_idx:
            return (m_idx.group(1), True)

        # node present but unindexed -> implicit [1]
        if re.search(rf'(^|/){re.escape(node)}($|/)', xp.strip("/")):
            return ("1", False)

        return ("", False)

    # 1) Find (index, explicitness) where the condition matches (scoped)
    matching_keys: Set[Tuple[str, bool]] = set()
    for row in rows:
        xp = str(row.get("xml-path", ""))

        if cond_prefix and not has_scope(xp, cond_prefix):
            continue

        tv = str(row.get("text-value", "")).strip()
        idx, explicit = extract_index(xp, cond_node)

        if idx and tv == cond_value:
            matching_keys.add((idx, explicit))

    # 2) Return only target rows whose (index, explicitness) matches (scoped)
    out: List[Dict[str, Any]] = []
    for row in rows:
        xp = str(row.get("xml-path", ""))

        if target_prefix and not has_scope(xp, target_prefix):
            continue

        idx, explicit = extract_index(xp, target_node)
        if idx and (idx, explicit) in matching_keys:
            out.append(row)

    return out


# ---------------- example ----------------
if __name__ == "__main__":
    input_rows = [
        {'node-text': 'DTP Date (DTP03)', 'text-value': '20200101',
         'xml-path': '837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/DTP/DTP03', 'sl': 10},
        {'node-text': 'DTP Date (DTP03)', 'text-value': '20200202',
         'xml-path': '837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2400/DTP/DTP03', 'sl': 11},
        {'node-text': 'DTP Qualifier (DTP01)', 'text-value': 'F8',
         'xml-path': '837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/DTP/DTP01', 'sl': 12},
        {'node-text': 'DTP Qualifier (DTP01)', 'text-value': 'F8',
         'xml-path': '837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/2400/DTP/DTP01', 'sl': 13},
    ]

    # This should only return the DTP03 under 2300/DTP, not 2300/2400/DTP
    print(filter_rows(input_rows, "2300/DTP/DTP03(DTP01=F8)"))
