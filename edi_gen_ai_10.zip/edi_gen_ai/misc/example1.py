from nicegui import ui

# Step 1: define the logical groups
INSURANCE_GROUPS = {
    'MEDICARE': ['MA', 'MB'],
    'MEDICAID': ['MC'],
    'TRICARE': ['CH'],
    'CHAMPVA': ['VA'],
    'GROUP HEALTH PLAN': ['CI', 'BL', 'HM'],
    'FECA BLK LUNG': ['OF'],
    'OTHER': ['11', 'ZZ'],
}

# Step 2: create the toggle using only human concepts
toggle = ui.toggle(
    options=list(INSURANCE_GROUPS.keys()),
    value='MEDICARE',
)

# Step 3: show what codes are implied by the selection
result_label = ui.label()

def update_result():
    selected_group = toggle.value
    codes = INSURANCE_GROUPS[selected_group]
    result_label.text = f'Selected group: {selected_group} → codes: {codes}'

toggle.on('update:model-value', update_result)

# initialize display
update_result()

ui.run()