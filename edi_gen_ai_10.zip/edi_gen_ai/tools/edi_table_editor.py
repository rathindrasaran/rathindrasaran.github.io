import sys
import xml.etree.ElementTree as ET
import os
import re
import io
import subprocess
from typing import Dict, Any, Optional, List, Set, Tuple, Union
from nicegui import ui, app, run
from pathlib import Path
from pypdf import PdfReader, PdfWriter
from .xmltotree import xml_tree_gen
from typing import List, Dict
from datetime import datetime
import copy
from edi_gen_ai.tools.cms_1500 import form_data
from edi_gen_ai.config import EDI837P_SCHEMA

# ---------- Config ----------
# Keep schema path consistent with edi_837_tree.py so both components load the same definition
SCHEMA_FILE = EDI837P_SCHEMA

grid = None
search_field = None

# Global: holds the parsed XML tree of the currently loaded SINGLE claim
data_tree: Optional[ET.ElementTree] = None

ANCHORS = {
    # common anchors you'll see early in EDI XML
    "ISA_LOOP", "GS_LOOP", "ST_LOOP", "HEADER", "DETAIL",
    # common loops/segments
    "1000A", "1000B", "2000A", "2000B", "2300", "2400",
    "CLM", "NM1", "HI", "SV1", "LX"
}

async def filter_name_contains(substr: str, fieldstr: str = None):
    global grid
    if fieldstr is not None:
        grid["filter_value_changed"](substr, fieldstr)
    else:
        grid["filter_value_changed"](substr)

# ---------- Single-claim extraction (kept API-compatible with edi_837_tree.py) ----------
def get_single_claim_xml(claim_id: str, xml_file_path: str) -> str | None:
    """Extract a single claim (by CLM01) from the given 837 XML file and fix counters."""
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except (FileNotFoundError, ET.ParseError) as e:
        print(f"Error reading or parsing source file {xml_file_path}: {e}")
        return None

    loop_2000a = root.find(".//loop[@id='2000A']")
    if loop_2000a is None:
        print("Error: Could not find the billing provider loop (2000A).")
        return None

    claim_found = False
    children_to_keep = []

    for child in loop_2000a:
        if child.get('id') != '2000B':
            children_to_keep.append(child)
            continue
        clm_segment = child.find(".//seg[@id='CLM']/ele[@id='CLM01']")
        if clm_segment is not None and clm_segment.text == claim_id:
            children_to_keep.append(child)
            claim_found = True

    if not claim_found:
        print(f"Claim with ID '{claim_id}' not found.")
        return None

    # Replace children in-place to preserve loop_2000a attributes
    loop_2000a[:] = children_to_keep

    # Recalculate HL counters
    hl_segments = root.findall('.//seg[@id="HL"]')
    old_to_new_hl_map = {}
    for i, hl_seg in enumerate(hl_segments, start=1):
        hl01 = hl_seg.find("ele[@id='HL01']")
        if hl01 is not None:
            old_hl_id = hl01.text
            new_hl_id = str(i)
            old_to_new_hl_map[old_hl_id] = new_hl_id
            hl01.text = new_hl_id
        hl02 = hl_seg.find("ele[@id='HL02']")
        if hl02 is not None and hl02.text in old_to_new_hl_map:
            hl02.text = old_to_new_hl_map[hl02.text]

    # Fix SE01 segment count
    st_loop = root.find(".//loop[@id='ST_LOOP']")
    if st_loop is not None:
        total_segments = len(st_loop.findall('.//seg'))
        se01 = st_loop.find("seg[@id='SE']/ele[@id='SE01']")
        if se01 is not None:
            se01.text = str(total_segments)

    return ET.tostring(root, encoding='unicode')


# ---------- Schema parsing with collision handling (from table editor) ----------
def parse_schema_hierarchically(schema_file: str):
    try:
        tree = ET.parse(schema_file)
        schema_root = tree.getroot()
    except (ET.ParseError, FileNotFoundError) as e:
        ui.notify(f"Fatal Error: Could not parse schema file '{schema_file}'. {e}", type='negative', multi_line=True)
        return None, None, None, None, None

    def _extract_display_name(elem: ET.Element, default: str) -> str:
        for tag in ('name', 'desc', 'description', 'title', 'label'):
            t = elem.findtext(tag)
            if t and t.strip():
                return t.strip()
        t = elem.get('name')
        if t and t.strip():
            return t.strip()
        return default

    def _parse_node(xml_element: ET.Element) -> Dict[str, Any]:
        node_id = xml_element.get('xid')
        node_info = {'name': _extract_display_name(xml_element, node_id), 'children': {}}
        valid_codes_elem = xml_element.find('valid_codes')
        if valid_codes_elem is not None:
            codes = [code.text for code in valid_codes_elem.findall('code') if code.text]
            if codes:
                node_info['codes'] = codes
        for child_xml in xml_element:
            if 'xid' in child_xml.attrib:
                child_id = child_xml.get('xid')
                node_info['children'][child_id] = _parse_node(child_xml)
        return node_info

    root_xid = schema_root.get('xid')
    hierarchical_schema = {root_xid: _parse_node(schema_root)}

    schema_path_index: Dict[Tuple[str, ...], Dict] = {}
    seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]] = {}
    flat_names: Dict[str, str] = {}
    xid_collisions: Dict[str, set] = {}

    def _index_paths(node: Dict, path: Tuple[str, ...]):
        schema_path_index[path] = node
        xid = path[-1] if len(path) >= 2 else None
        if isinstance(xid, str) and len(xid) >= 4 and xid[-2:].isdigit():
            seg_id = xid[:-2]
            key = (seg_id, xid)
            seg_ele_index.setdefault(key, []).append(path)
            name = node.get('name', xid)
            if xid in flat_names and flat_names[xid] != name:
                xid_collisions.setdefault(xid, set()).update([flat_names[xid], name])
            else:
                flat_names.setdefault(xid, name)
        for child_id, child_node in node.get('children', {}).items():
            _index_paths(child_node, path + (child_id,))

    _index_paths(hierarchical_schema[root_xid], (root_xid,))
    for k in list(flat_names.keys()):
        if k in xid_collisions:
            del flat_names[k]

    return hierarchical_schema, flat_names, schema_path_index, seg_ele_index, xid_collisions


# ---------- Name resolver (from table editor) ----------
def _name_for_xid(ele_id: str,
                  path_ids: Tuple[str, ...],
                  schema_path_index: Dict[Tuple[str, ...], Dict],
                  seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]],
                  flat_schema_unique: Dict[str, str]) -> str:
    node = schema_path_index.get(path_ids)
    if node:
        n = node.get('name')
        if n:
            return n
    if len(ele_id) >= 4 and ele_id[-2:].isdigit():
        seg_id = ele_id[:-2]
        paths = seg_ele_index.get((seg_id, ele_id)) or []
        if len(paths) == 1:
            node2 = schema_path_index.get(paths[0])
            if node2:
                n2 = node2.get('name')
                if n2:
                    return n2
    n3 = flat_schema_unique.get(ele_id)
    if n3:
        return n3
    return ele_id


def create_node_by_edi_path(root: ET.Element, edi_path: str) -> ET.Element:
    """
    Traverses an EDI path and creates any missing loops, segments, or elements,
    correctly handling indexed paths to create repeating segments.
    """
    parts = edi_path.strip("/").split("/")
    
    # Heuristic: If the path is ambiguous (e.g., .../REF/REF02[2]), it implies
    # the index should apply to the parent segment. We rewrite the path to be
    # unambiguous (e.g., .../REF[2]/REF02) before processing.
    if len(parts) >= 2:
        tag_ele, num_ele = parse_word_number(parts[-1])
        tag_seg, num_seg = parse_word_number(parts[-2])

        if num_ele is not None and num_ele > 1 and num_seg is None:
            parts[-1] = tag_ele
            parts[-2] = f"{tag_seg}[{num_ele}]"

    current = root
    for idx, part in enumerate(parts):
        tag_id, item_num = parse_word_number(part)
        
        # Default to the first instance (index 0) if no index is given
        target_index = (item_num - 1) if item_num is not None else 0
        if target_index < 0:
            target_index = 0

        matches = [child for child in current if child.get('id') == tag_id]
        node_tag = _infer_tag_from_path(parts, idx)

        # If not enough existing nodes are found, create new ones until the
        # target index can be fulfilled.
        while len(matches) <= target_index:
            new_node = ET.SubElement(current, node_tag, {"id": tag_id})
            matches.append(new_node)
        
        # Move traversal to the target node for the next part of the path.
        current = matches[target_index]
    
    return current

def _infer_tag_from_path(parts, idx):
    """
    pyx12 XML convention:
      - everything before the last 2 items => loop
      - second-to-last item => seg
      - last item => ele
    """
    n = len(parts)
    if idx == n - 1:
        return "ele"
    if idx == n - 2:
        return "seg"
    return "loop"




def parse_word_number(s: str) -> Tuple[str, Optional[int]]:
    """
    Parses a string like 'NM101' or 'REF[2]' into its name and an integer index.
    Returns the name and the index (if present), otherwise the index is None.
    """
    match = re.match(r'^([a-zA-Z0-9_-]+)(?:\[(\d+)\])?$', s)
    if match:
        word = match.group(1)
        number_str = match.group(2)
        number = int(number_str) if number_str else None
        return word, number
    return s, None

def get_node_by_edi_path(root: ET.Element, edi_path: str) -> Optional[ET.Element]:
    """
    Traverses an XML tree to find a specific node based on an indexed EDI path.
    e.g., ".../2300/REF[2]/REF01"
    """
    current = root
    parts = edi_path.strip("/").split("/")
    
    for part in parts:
        if current is None:
            return None
        
        tag_id, item_num = parse_word_number(part)
        # Default to the first occurrence (index 0) if no index is specified
        target_index = (item_num - 1) if item_num is not None else 0
        if target_index < 0:
            target_index = 0

        # Find all direct children that match the tag ID
        matches = [child for child in current if child.get('id') == tag_id]
        
        if len(matches) > target_index:
            current = matches[target_index]
        else:
            # The requested node or its specific instance does not exist
            return None
    return current

def form_to_edi_date(date_str, out_fmt='%Y%m%d'):
    if not date_str or not isinstance(date_str, str):
        return None

    supported_formats = [
        '%m/%d/%Y',  # Handles '05/15/2024'
        '%m/%d/%y',  # Handles '05/15/24'
        '%Y-%m-%d',  # Handles '2024-05-15'
        '%Y%m%d',    # Handles '20240515'
    ]

    for fmt in supported_formats:
        try:
            dt_obj = datetime.strptime(date_str, fmt)
            return dt_obj.strftime(out_fmt)
        except ValueError:
            continue

    print(f"Warning: Could not parse unsupported date format: '{date_str}'", file=sys.stderr)
    return date_str

def get_segment_id(path: str) -> str:
    """
    Extract the final EDI segment identifier from a path,
    removing any trailing [index].
    """
    last_part = path.rsplit("/", 1)[-1]
    return last_part.split("[", 1)[0]


def update_xml_from_grid(tree: ET.ElementTree, grid_data: List[Dict], form_data_dict: Dict):
    """
    Updates the XML tree from grid data and handles conditional node creation,
    correctly disambiguating filters that map to the same XML element.
    """
    root = tree.getroot()
    updated = 0
    # Create a map of {filter_path: form_data_key}, e.g., {'.../REF02(REF01=F8)': '2_original_ref_no_filter'}
    filter_map = {v: k for k, v in form_data_dict.items() if isinstance(k, str) and k.endswith('_filter')}

    def parse_filter_path(filter_path):
        match = re.match(r'^(.*?)\((.*?)=(.*?)\)$', filter_path)
        if match:
            base_path, cond_key, cond_val = match.groups()
            return base_path, cond_key, cond_val
        return filter_path, None, None

    def strip_indices(p):
        return re.sub(r'\[\d+\]', '', p)

    for item in grid_data:
        full_path = item.get('xml-path')
        path = full_path.replace('837/', '')
        val = item.get('text-value')

        if not path:
            continue

        if get_segment_id(path) in ("DMG02", "DTP03"):
            val = form_to_edi_date(val)
        
        node = create_node_by_edi_path(root, path)
        node.text = val
        updated += 1

        # --- AMBIGUITY-AWARE CONDITIONAL LOGIC ---
        stripped_item_path = strip_indices(full_path)
        
        # 1. Find all possible conditional filters that match the item's path.
        matching_filters = []
        for f_path in filter_map.keys():
            base_path, _, _ = parse_filter_path(f_path)
            if strip_indices(base_path) == stripped_item_path:
                matching_filters.append(f_path)
        
        # 2. If any filters match, decide which one to use.
        chosen_filter = None
        if len(matching_filters) == 1:
            chosen_filter = matching_filters[0]
        elif len(matching_filters) > 1:
            # Disambiguate by finding the filter whose corresponding form_data value
            # matches the value being saved from the grid item.
            for f_path in matching_filters:
                form_filter_key = filter_map[f_path]  # e.g., '2_original_ref_no_filter'
                form_data_key = form_filter_key.replace('_filter', '')  # e.g., '2_original_ref_no'
                
                # Check if the value from the main form dictionary matches the new value.
                if form_data_dict.get(form_data_key) == val:
                    chosen_filter = f_path
                    break
        
        # 3. If a filter was chosen, apply its conditional logic.
        if chosen_filter:
            _, cond_key, cond_val = parse_filter_path(chosen_filter)
            if cond_key:
                parent_path = '/'.join(path.split('/')[:-1])
                sibling_path = f"{parent_path}/{cond_key}"
                
                sibling_node = create_node_by_edi_path(root, sibling_path)
                sibling_node.text = cond_val

    return tree, updated

def update_xml_2000B_from_grid(topnode: ET.Element, grid_data: List[Dict], form_data_dict: Dict):
    """
    Updates a 2000B loop from grid data and handles conditional node creation,
    correctly disambiguating filters that map to the same XML element.
    """
    updated = 0
    # Create a map of {filter_path: form_data_key}, e.g., {'.../REF02(REF01=F8)': '2_original_ref_no_filter'}
    filter_map = {v: k for k, v in form_data_dict.items() if isinstance(k, str) and k.endswith('_filter')}

    def parse_filter_path(filter_path):
        match = re.match(r'^(.*?)\((.*?)=(.*?)\)$', filter_path)
        if match:
            base_path, cond_key, cond_val = match.groups()
            return base_path, cond_key, cond_val
        return filter_path, None, None

    def strip_indices(p):
        return re.sub(r'\[\d+\]', '', p)

    for item in grid_data:
        full_path = item.get('xml-path')
        parts = full_path.split('/')
        if '2000B' not in parts:
            continue
        
        idx = parts.index('2000B')
        scoped_path = '/'.join(parts[idx+1:])
        val = item.get('text-value')

        if get_segment_id(scoped_path) in ("DMG02", "DTP03"):
            val = form_to_edi_date(val)

        node = create_node_by_edi_path(topnode, scoped_path)
        node.text = val
        updated += 1
        
        # --- AMBIGUITY-AWARE CONDITIONAL LOGIC ---
        stripped_full_path = strip_indices(full_path)

        # 1. Find all possible conditional filters that match the item's path.
        matching_filters = []
        for f_path in filter_map.keys():
            base_path, _, _ = parse_filter_path(f_path)
            if strip_indices(base_path) == stripped_full_path:
                matching_filters.append(f_path)
        
        # 2. If any filters match, decide which one to use.
        chosen_filter = None
        if len(matching_filters) == 1:
            chosen_filter = matching_filters[0]
        elif len(matching_filters) > 1:
            # Disambiguate by finding the filter whose corresponding form_data value
            # matches the value being saved from the grid item.
            for f_path in matching_filters:
                form_filter_key = filter_map[f_path]
                form_data_key = form_filter_key.replace('_filter', '')
                
                if form_data_dict.get(form_data_key) == val:
                    chosen_filter = f_path
                    break
        
        # 3. If a filter was chosen, apply its conditional logic.
        if chosen_filter:
            _, cond_key, cond_val = parse_filter_path(chosen_filter)
            if cond_key:
                parent_scoped_path = '/'.join(scoped_path.split('/')[:-1])
                sibling_scoped_path = f"{parent_scoped_path}/{cond_key}"
                
                sibling_node = create_node_by_edi_path(topnode, sibling_scoped_path)
                sibling_node.text = cond_val
                
    return updated


# ---------- Build rows for grid (from table editor) ----------
def build_table_rows_from_tree(root: ET.Element,
                               hierarchical_schema: Dict,
                               flat_schema_unique: Dict[str, str],
                               schema_path_index: Dict[Tuple[str, ...], Dict],
                               seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]],
                               ) -> List[Dict[str, str]]:
    """
    Recursively builds a flat list of rows for the grid from the XML tree,
    correctly generating indexed paths for repeating segments and the specific
    redundant paths required for composite elements.
    """
    rows: List[Dict[str, str]] = []
    top_data_loop = root.find('loop')
    if top_data_loop is None:
        return rows
    
    top_schema_node = next(iter(hierarchical_schema.values()))['children'].get('ISA_LOOP')
    if not top_schema_node:
        return rows
        
    root_schema_xid = next(iter(hierarchical_schema.keys()))
    base_path = (root_schema_xid, 'ISA_LOOP')

    def walk(data_node: ET.Element, schema_node: Dict, path_ids: Tuple[str, ...], xml_path: str):
        # This function is called for a structural node (<loop> or <seg>)
        
        child_id_counts = {}
        for child in data_node:
            child_id = child.get('id')
            if child_id:
                child_id_counts[child_id] = child_id_counts.get(child_id, 0) + 1
        
        current_indices = {key: 0 for key in child_id_counts}

        for child_data in data_node:
            child_id = child_data.get('id')
            if not child_id:
                continue

            child_schema = schema_node.get('children', {}).get(child_id, schema_node)
            new_path_ids = path_ids + (child_id,)
            
            # --- Handle different node types based on their XML tag ---

            if child_data.tag in ('loop', 'seg'):
                new_xml_path_part = child_id
                if child_id_counts.get(child_id, 0) > 1:
                    current_indices[child_id] += 1
                    new_xml_path_part = f"{child_id}[{current_indices[child_id]}]"
                
                new_xml_path = f"{xml_path}/{new_xml_path_part}"
                walk(child_data, child_schema, new_path_ids, new_xml_path)

            elif child_data.tag == 'comp':
                # --- THIS IS THE CORRECTED LOGIC FOR COMPOSITE ELEMENTS ---
                comp_id = child_data.get('id')
                if not comp_id:
                    continue

                # The base path for sub-elements is the parent segment's path
                # PLUS the composite element's own ID.
                # e.g., .../2300/CLM -> .../2300/CLM/CLM
                comp_base_path = f"{xml_path}/{comp_id}"

                for sub_ele in child_data:
                    sub_ele_id = sub_ele.get('id')
                    if not sub_ele_id:
                        continue
                    
                    # The final path includes the composite ID segment.
                    # e.g., .../2300/CLM/CLM/CLM05-03
                    ele_xml_path = f"{comp_base_path}/{sub_ele_id}"
                    
                    current_value = (sub_ele.text or '').strip()
                    ele_path = new_path_ids + (sub_ele_id,)
                    ele_name = _name_for_xid(sub_ele_id, ele_path, schema_path_index, seg_ele_index, flat_schema_unique)
                    label_text = f'- {ele_name} ({sub_ele_id})'

                    rows.append({
                        'node-text': label_text,
                        'text-value': current_value,
                        'xml-path': ele_xml_path,
                    })
            
            elif child_data.tag == 'ele':
                ele_xml_path = f"{xml_path}/{child_id}"
                current_value = (child_data.text or '').strip()
                ele_name = _name_for_xid(child_id, new_path_ids, schema_path_index, seg_ele_index, flat_schema_unique)
                label_text = f'{ele_name} ({child_id})'

                rows.append({
                    'node-text': label_text,
                    'text-value': current_value,
                    'xml-path': ele_xml_path,
                })

    walk(top_data_loop, top_schema_node, base_path, f"{root_schema_xid}/ISA_LOOP")

    for i, r in enumerate(rows, start=1):
        r['sl'] = i
    return rows


# ---------- Component factory (DROP‑IN API) ----------
# This mirrors the shape of create_tree_editor() in edi_837_tree.py:
#   - Renders a self-contained UI fragment (card)
#   - Returns a callable load_claim_data(claim_id: str, xml_file: str)
#     which the parent app can call to inject the desired claim

def create_table_editor():
    """Creates the EDI 837 Table Editor component.

    Returns
    -------
    load_claim_data: callable
        Function taking (claim_id: str, xml_file: str) that loads the claim
        and populates the grid inside this component.
    """
    global grid
    global data_tree

    (hierarchical_schema,
     flat_schema_unique,
     schema_path_index,
     seg_ele_index,
     xid_collisions) = parse_schema_hierarchically(SCHEMA_FILE)

    if not (hierarchical_schema and flat_schema_unique is not None
            and schema_path_index and seg_ele_index is not None):
        ui.label('Could not load schema.').classes('text-negative')
        return lambda *_args, **_kwargs: None

    app.storage.user.setdefault('search_term', '')
    app.storage.user.setdefault('loaded_claim_id', '')
    app.storage.user.setdefault('xml_file_path', '')

    async def download_edi_file():
        """Generate and download the EDI file."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not claim_id or not xml_file:
            ui.notify('No claim loaded or file path is missing.', type='negative')
            return

        single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
        if not single_claim_xml_str:
            ui.notify(f"Failed to generate XML for claim '{claim_id}'.", type='negative')
            return

        output_dir = f'{os.path.dirname(xml_file)}/gen'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        xml_gen_path = os.path.join(output_dir, f"{claim_id}.xml")
        edi_file_path = os.path.join(output_dir, f"{claim_id}.edi")

        with open(xml_gen_path, 'w') as f:
            f.write(single_claim_xml_str)

        # Run the conversion command
        cmd = ['xmlx12', xml_gen_path, '--outputfile', edi_file_path]
        process = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Trigger the download
        ui.download(edi_file_path, f"{claim_id}.edi")

    async def save_changes():
        """Apply grid edits to both single-claim (in-memory) and the main XML file; save both into gen/."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not claim_id or not xml_file:
            ui.notify('No claim loaded or file path is missing.', type='negative')
            return
        if data_tree is None:
            ui.notify('No in-memory claim XML to update.', type='negative')
            return

        grid_data = grid["get_changes"]()

        _, single_updates = update_xml_from_grid(data_tree, grid_data, form_data)

        main_tree = ET.parse(xml_file)
        root = main_tree.getroot()

        def _find_claim_loop(root: ET.Element, claim_id: str) -> Optional[ET.Element]:
            for loop_b in root.findall(".//loop[@id='2000B']"):
                clm01 = loop_b.find(".//seg[@id='CLM']/ele[@id='CLM01']")
                if clm01 is not None and (clm01.text or '').strip() == (claim_id or '').strip():
                    return loop_b
            return None

        claim_loop = _find_claim_loop(root, claim_id)

        main_updates = 0

        if claim_loop is not None:
            main_updates = update_xml_2000B_from_grid(claim_loop, grid_data, form_data)

        outdir = Path(xml_file).parent / 'gen'
        outdir.mkdir(parents=True, exist_ok=True)

        claim_xml_path = outdir / f"{claim_id}.xml"
        data_tree.write(claim_xml_path, encoding='utf-8', xml_declaration=True)

        main_path = Path(xml_file)
        main_updated_path = Path(xml_file).parent / f"{main_path.stem}{main_path.suffix}"
        main_tree.write(main_updated_path, encoding='utf-8', xml_declaration=True)

        edited_by_path.clear()
        ui.notify(f"Saved {single_updates} field(s) in claim XML, {main_updates} in main XML → "
                f"{claim_xml_path.name}, {main_updated_path.name}", type='positive')

    def _open_settings_tree():
        """Open a modal containing a tree of the current XML and a field showing selected node path."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not xml_file:
            ui.notify('No XML loaded yet. Select a claim first.', type='warning')
            return

        title = f'Claim {claim_id} • Tree View' if claim_id else f'Tree View'

        with ui.dialog() as dlg, ui.card().classes('w-[80vw] max-w-[1100px] h-[75vh] p-0'):
            # header
            with ui.row().classes('items-center justify-between w-full p-3'):
                ui.label(title).classes('text-lg font-semibold')
                ui.button(icon='close', on_click=dlg.close).props('flat round dense')

            ui.separator()

            # path field with copy button
            with ui.row().classes('w-full items-center gap-2 px-3 py-2'):
                path_input = ui.input('Selected node path').props('readonly').classes('w-full')
                ui.button(icon='content_copy').tooltip('Copy path')
                # wire a simple clipboard write (works in browser contexts)
                ui.run_javascript(
                    f"document.querySelector('#{path_input.id}').nextElementSibling.onclick = () => "
                    f"navigator.clipboard.writeText(document.getElementById('{path_input.id}').value)"
                )

            # tree area
            with ui.scroll_area().classes('w-full h-[calc(75vh-120px)] px-3 pb-3'):
                single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
                tree = xml_tree_gen(single_claim_xml_str, is_text=True)

            # when a node is selected, update the path input with the node's 'id' (which is the full path)
            def _on_select(e):
                selected = getattr(e, 'value', None)  # ValueChangeEventArguments.value
                if isinstance(selected, (list, tuple)):
                    selected = selected[0] if selected else ''
                filter_text = (str(selected) if selected is not None else '').replace('X12','837')
                filter_text = re.sub(r'\[\d+\]', '', filter_text)
                path_input.set_value(filter_text)
                grid["filter_value_changed"](filter_text)
                

            # prefer the helper if available; otherwise fall back to the raw Quasar event name
            try:
                tree.on_select(_on_select)
            except Exception:
                tree.on('update:selected', _on_select)

            # optional: expand/collapse helpers
            with ui.row().classes('gap-2 px-3 pb-3'):
                ui.button('Expand All', on_click=lambda: ui.run_javascript(
                    f"document.querySelectorAll('#{tree.id} .q-tree__node').forEach(n=>n.__vueParent?.setExpanded?.(true))"
                )).props('outline dense')
                ui.button('Collapse All', on_click=lambda: ui.run_javascript(
                    f"document.querySelectorAll('#{tree.id} .q-tree__node--parent').forEach(n=>n.__vueParent?.setExpanded?.(false))"
                )).props('outline dense')

        dlg.open()



    with ui.card().classes('w-full h-full'):
        with ui.row().classes('w-full gap-1 no-wrap'):
            ui.button(icon='download').on('click', download_edi_file)
            ui.button(icon='save').on('click', save_changes)
            ui.button(icon='print').on('click', createClaimPdf)
            ui.button(icon='settings').on('click', _open_settings_tree)
        grid_options = {
            'columnDefs': [
                {'headerName': 'EDI Node', 'field': 'node-text', 'flex': 5, 'sortable': False, 'filter': True, 'floatingFilter': True},
                {'headerName': 'Value', 'field': 'text-value', 'flex': 2, 'editable': True, 'sortable': False, 'filter': True, 'floatingFilter': True},
                # {'headerName': 'xml-path', 'field': 'xml-path', 'editable': True, 'sortable': True, 'filter': True, 'floatingFilter': True},
                {'headerName': 'xml-path', 'field': 'xml-path', 'hide': True, 'sortable': True, 'filter': True},
            ],
            'rowData': [],
            'animateRows': True,
            'stopEditingWhenCellsLoseFocus': True,
            'defaultColDef': {'resizable': True},
        }
        rows = []
        grid = make_xml_node_table(rows,form_data)

        status = ui.label('').classes('text-sm text-gray-600')

        # Tracks edits keyed by xml-path so we don’t need to fetch client state back
        edited_by_path: Dict[str, Any] = {}

        def _rebuild_rows_from_current_tree():
            if not data_tree:
                grid["change_dataset"]([],form_data)
                return 0
            
            root = data_tree.getroot()
            rows = build_table_rows_from_tree(
                root,
                hierarchical_schema,
                flat_schema_unique,
                schema_path_index,
                seg_ele_index,
            )

            # --- MODIFICATION START ---
            # Check for the existence of the specific REF segment (REF01='F8')
            # and add it only if it's missing.
            
            loop_2300 = root.find('.//loop[@id="2300"]')
            f8_ref_exists = False
            ref_segments = []

            if loop_2300 is not None:
                # Find all current REF segments to check them and to determine the next index
                ref_segments = loop_2300.findall("./seg[@id='REF']")
                
                for ref_seg in ref_segments:
                    ref01_ele = ref_seg.find("./ele[@id='REF01']")
                    if ref01_ele is not None and ref01_ele.text == 'F8':
                        f8_ref_exists = True
                        break  # Found it, no need to add it

            # If the REF segment with REF01='F8' was not found, add the rows for it.
            if not f8_ref_exists:
                # Calculate the next index for the new REF segment (e.g., if 1 exists, this will be 2)
                new_ref_index = len(ref_segments) + 1

                ref01 = {
                        'node-text': 'Reference Identification Qualifier (REF01)',
                        'text-value': 'F8',
                        'xml-path': f'837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/REF[{new_ref_index}]/REF01',
                        'sl': 10000
                }
                ref02 = {
                        'node-text': 'Reference Number (REF02)',
                        'text-value': '00',
                        'xml-path': f'837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/REF[{new_ref_index}]/REF02',
                        'sl': 10001
                }

                rows.append(ref01)
                rows.append(ref02)
            # --- MODIFICATION END ---
            
            grid["change_dataset"](rows,form_data)

            return len(rows)

        def load_claim_data(claim_id: str, xml_file: str):
            """Loads a single claim into the component and refreshes the grid."""
            nonlocal status
            global data_tree
            if not claim_id or not xml_file:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text('No claim loaded.')
                return

            single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
            if not single_claim_xml_str:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text(f"Claim '{claim_id}' not found or parse failed.")
                ui.notify(f"Claim '{claim_id}' not found or parse failed.", type='negative')
                return

            try:
                root = ET.fromstring(single_claim_xml_str)
                data_tree = ET.ElementTree(root)
            except ET.ParseError as e:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text(f'XML parse error: {e}')
                ui.notify(f'Error parsing XML: {e}', type='negative', multi_line=True)
                return

            count = _rebuild_rows_from_current_tree()
            app.storage.user['loaded_claim_id'] = claim_id
            app.storage.user['xml_file_path'] = xml_file
            status.set_text(f"Loaded claim {claim_id} • {count} elements")
            ui.notify(f"Loaded claim '{claim_id}'", type='positive')


        # initial empty state
        _rebuild_rows_from_current_tree()

    return load_claim_data

# Helper function to safely split dates
def _split_date(date_string):
    if not date_string or len(date_string) != 10 or date_string.count('/') != 2:
        return '', '', ''
    parts = date_string.split('/')
    return parts[0], parts[1], parts[2] # MM, DD, YYYY

def createClaimPdf():
    """
    Generates a PDF for the single, currently displayed CMS-1500 claim
    using the data from the UI's form_data dictionary.
    """
    claim_id = app.storage.user.get('loaded_claim_id')
    xml_file_path = app.storage.user.get('xml_file_path')

    if not claim_id or not xml_file_path:
        ui.notify('Cannot generate PDF: No claim is currently loaded.', type='warning')
        return
        
    try:
        project_root = Path(__file__).resolve().parent.parent
        template_path = str(project_root / 'tools' / 'pdf_formats' / '837-p-form-cms1500-mod.pdf')
        output_dir = Path(xml_file_path).parent / 'pdf_gen'
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / f"{claim_id}_cms1500.pdf"
        
        final_writer = PdfWriter()
        
        # 1. Map data directly from the imported form_data dictionary
        pdf_data_common = {}
        
        # --- Start Data Mapping from form_data ---
        ins_type = form_data.get("1_insurance_type", "")
        pdf_data_common['chkMedicare'] = '/Yes' if ins_type == 'MEDICARE' else '/Off'
        pdf_data_common['chkMedicaid'] = '/Yes' if ins_type == 'MEDICAID' else '/Off'
        pdf_data_common['chkTricare'] = '/Yes' if ins_type == 'TRICARE' else '/Off'
        pdf_data_common['chkChampva'] = '/Yes' if ins_type == 'CHAMPVA' else '/Off'
        pdf_data_common['chkGroupHealthPlan'] = '/Yes' if ins_type == 'GROUP HEALTH PLAN' else '/Off'
        pdf_data_common['chkFecaBlkLung'] = '/Yes' if ins_type == 'FECA BLK LUNG' else '/Off'
        pdf_data_common['chkOtherCarrier'] = '/Yes' if ins_type == 'OTHER' else '/Off'
        
        pdf_data_common['txtInsuredsIDNumber'] = form_data.get("1a_insured_id_number", "")
        pdf_data_common['txtPatientsName'] = form_data.get("2_patient_name", "")
        mm, dd, yy = _split_date(form_data.get("3_patient_birth_date", ""))
        pdf_data_common['txtPatientsDOBMM'], pdf_data_common['txtPatientsDOBDD'], pdf_data_common['txtPatientsDOBYY'] = mm, dd, yy
        patient_sex = form_data.get("3_patient_sex", "")
        pdf_data_common['chkPatientMale'] = '/Yes' if patient_sex == 'MALE' else '/Off'
        pdf_data_common['chkPatientFemale'] = '/Yes' if patient_sex == 'FEMALE' else '/Off'
        pdf_data_common['txtInsuredsName'] = form_data.get("4_insured_name", "")
        pdf_data_common['txtPatientsAddress'] = form_data.get("5_patient_address_street", "")
        pdf_data_common['txtPatientsCity'] = form_data.get("5_patient_address_city", "")
        pdf_data_common['txtPatientsState'] = form_data.get("5_patient_address_state", "")
        pdf_data_common['txtPatientsZipcode'] = form_data.get("5_patient_address_zip", "")
        pdf_data_common['txtPatientsPhoneAreaCode'] = form_data.get("5_patient_address_telephone", "")
        relationship = form_data.get("6_patient_relationship", "")
        pdf_data_common['chkPatientInsuredSelf'] = '/Yes' if relationship == 'SELF' else '/Off'
        pdf_data_common['chkPatientInsuredSpouse'] = '/Yes' if relationship == 'SPOUSE' else '/Off'
        pdf_data_common['chkPatientInsuredChild'] = '/Yes' if relationship == 'CHILD' else '/Off'
        pdf_data_common['chkPatientInsuredOther'] = '/Yes' if relationship == 'OTHER' else '/Off'
        pdf_data_common['txtInsuredsAddress'] = form_data.get("7_insured_address_street", "")
        pdf_data_common['txtInsuredsCity'] = form_data.get("7_insured_address_city", "")
        pdf_data_common['txtInsuredsState'] = form_data.get("7_insured_address_state", "")
        pdf_data_common['txtInsuredsZipcode'] = form_data.get("7_insured_address_zip", "")
        pdf_data_common['txtOtherInsuredsName'] = form_data.get("9_other_insured_name", "")
        pdf_data_common['txtOtherInsuredsPolicyOrGroupNumber'] = form_data.get("9a_other_insured_policy_number", "")
        pdf_data_common['txtOtherInsurancePlanNameOrProgramName'] = form_data.get("9d_insurance_plan_name", "")
        is_employment = form_data.get("10a_employment") == 'YES'
        is_auto = form_data.get("10b_auto_accident") == 'YES'
        is_other_accident = form_data.get("10c_other_accident") == 'YES'
        pdf_data_common['chkPatientConditionRelatedToEmploymentYes'] = '/Yes' if is_employment else '/Off'
        pdf_data_common['chkPatientConditionRelatedToEmploymentNo'] = '/Yes' if not is_employment else '/Off'
        pdf_data_common['chkPatientConditionRelatedToAutoAccidentYes'] = '/Yes' if is_auto else '/Off'
        pdf_data_common['chkPatientConditionRelatedToAutoAccidentNo'] = '/Yes' if not is_auto else '/Off'
        pdf_data_common['txtPatientAutoAccidentState'] = form_data.get("10b_auto_accident_place", "") if is_auto else ""
        pdf_data_common['chkPatientConditionRelatedToOtherAccidentYes'] = '/Yes' if is_other_accident else '/Off'
        pdf_data_common['chkPatientConditionRelatedToOtherAccidentNo'] = '/Yes' if not is_other_accident else '/Off'
        pdf_data_common['txtInsuredsPolicyGroupOrFecaNumber'] = form_data.get("11_insured_policy_group_or_feca_number", "")
        mm, dd, yy = _split_date(form_data.get("11a_insured_birth_date", ""))
        pdf_data_common['txtInsuredsDOBMM'], pdf_data_common['txtInsuredsDOBDD'], pdf_data_common['txtInsuredsDOBYY'] = mm, dd, yy
        insured_sex = form_data.get("11a_insured_sex", "")
        pdf_data_common['chkInsuredMale'] = '/Yes' if insured_sex == 'MALE' else '/Off'
        pdf_data_common['chkInsuredFemale'] = '/Yes' if insured_sex == 'FEMALE' else '/Off'
        pdf_data_common['txtInsuredsInsurancePlanNameOrProgramName'] = form_data.get("11c_insurance_plan_name", "")
        has_other_plan = form_data.get("11d_is_there_another_health_benefit_plan") == 'YES'
        pdf_data_common['chkIsThereAnotherHealthPlanYes'] = '/Yes' if has_other_plan else '/Off'
        pdf_data_common['chkIsThereAnotherHealthPlanNo'] = '/Yes' if not has_other_plan else '/Off'
        pdf_data_common['txtPatientSignatureDate'] = form_data.get("12_date", "")
        mm, dd, yy = _split_date(form_data.get("14_date_of_current_illness", ""))
        pdf_data_common['txtDateOfIllnessMM'], pdf_data_common['txtDateOfIllnessDD'], pdf_data_common['txtDateOfIllnessYY'] = mm, dd, yy
        pdf_data_common['txtDateOfIllnessQualifier'] = form_data.get("14_qual", "")
        mm, dd, yy = _split_date(form_data.get("16_dates_patient_unable_to_work_from", ""))
        pdf_data_common['txtDatePatientUnableToWorkStartMM'], pdf_data_common['txtDatePatientUnableToWorkStartDD'], pdf_data_common['txtDatePatientUnableToWorkStartYY'] = mm, dd, yy
        mm, dd, yy = _split_date(form_data.get("16_dates_patient_unable_to_work_to", ""))
        pdf_data_common['txtDatePatientUnableToWorkEndMM'], pdf_data_common['txtDatePatientUnableToWorkEndDD'], pdf_data_common['txtDatePatientUnableToWorkEndYY'] = mm, dd, yy
        mm, dd, yy = _split_date(form_data.get("18_hospitalization_dates_from", ""))
        pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartMM'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartDD'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartYY'] = mm, dd, yy
        mm, dd, yy = _split_date(form_data.get("18_hospitalization_dates_to", ""))
        pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndMM'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndDD'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndYY'] = mm, dd, yy
        pdf_data_common['txtNameOfReferringProviderOrOtherSourceQualifier'] = form_data.get("17_qualifier", "")
        pdf_data_common['txtNameOfReferringProviderOrOtherSource'] = form_data.get("17_name_of_referring_provider", "")
        pdf_data_common['txtReferringProviderOrOtherSourceNPI'] = form_data.get("17b_npi", "")
        pdf_data_common['txt21ICDInd01'] = form_data.get("21_icd_ind_1", "")
        pdf_data_common['txt21ICDInd02'] = form_data.get("21_icd_ind_2", "")
        pdf_data_common['txt21DiagnosisCodeA'] = form_data.get("21_diagnosis_a", "")
        pdf_data_common['txt21DiagnosisCodeB'] = form_data.get("21_diagnosis_b", "")
        pdf_data_common['txt21DiagnosisCodeC'] = form_data.get("21_diagnosis_c", "")
        pdf_data_common['txt21DiagnosisCodeD'] = form_data.get("21_diagnosis_d", "")
        pdf_data_common['txt21DiagnosisCodeE'] = form_data.get("21_diagnosis_e", "")
        pdf_data_common['txt21DiagnosisCodeF'] = form_data.get("21_diagnosis_f", "")
        pdf_data_common['txt21DiagnosisCodeG'] = form_data.get("21_diagnosis_g", "")
        pdf_data_common['txt21DiagnosisCodeH'] = form_data.get("21_diagnosis_h", "")
        pdf_data_common['txt21DiagnosisCodeI'] = form_data.get("21_diagnosis_i", "")
        pdf_data_common['txt21DiagnosisCodeJ'] = form_data.get("21_diagnosis_j", "")
        pdf_data_common['txt21DiagnosisCodeK'] = form_data.get("21_diagnosis_k", "")
        pdf_data_common['txt21DiagnosisCodeL'] = form_data.get("21_diagnosis_l", "")
        pdf_data_common['txtResubmissionCode'] = form_data.get("22_resubmission_code", "")
        pdf_data_common['txtResubmissionCodeOriginalRefNumber'] = form_data.get("22_original_ref_no", "")
        pdf_data_common['txtPriorAuthorizationNumber'] = form_data.get("23_prior_authorization_number", "")
        pdf_data_common['txtFederalTaxIDNumber'] = form_data.get("25_federal_tax_id_number", "")
        pdf_data_common['chkFederalTaxIDSSN'] = '/Yes' if form_data.get("25_ssn") else '/Off'
        pdf_data_common['chkFederalTaxIDEIN'] = '/Yes' if form_data.get("25_ein") else '/Off'
        pdf_data_common['txtPatientsAccountNumber'] = form_data.get("26_patients_account_no", "")
        accept_assign = form_data.get("27_accept_assignment") == 'YES'
        pdf_data_common['chkAcceptAssignmentYes'] = '/Yes' if accept_assign else '/Off'
        pdf_data_common['chkAcceptAssignmentNo'] = '/Yes' if not accept_assign else '/Off'
        pdf_data_common['txt31DateOfAttestation'] = form_data.get("31_date", "")
        pdf_data_common['txt33BillingProviderInfo1'] = form_data.get("33_billing_provider_info_and_ph", "")
        pdf_data_common['txt33BillingProviderInfo2'] = form_data.get("33_billing_provider_info_and_ph_a", "")
        pdf_data_common['txt33BillingProviderPhone'] = "" # Phone is part of field 33
        pdf_data_common['txt33BillingProviderNPI'] = form_data.get("33_billing_provider_info_and_ph_b", "")

        # --- End Data Mapping ---

        # 2. Process service lines in chunks (CMS-1500 has 6 lines per page)
        service_lines = form_data.get('service_lines', [])
        if not service_lines:
            service_lines = [{}] 

        start_index = 0
        page_index = 0
        while start_index < len(service_lines):
            chunk = service_lines[start_index : start_index + 6]
            page_data = pdf_data_common.copy()
            
            # Create a filled, single-page PDF in memory
            reader = PdfReader(template_path)
            writer_for_page = PdfWriter()
            writer_for_page.append(reader)

            for i, line in enumerate(chunk):
                line_num = i + 1
                mm, dd, yy = _split_date(line.get('date_of_service_from', ''))
                page_data[f'txt24ALine{line_num}DateOfServiceFromMM'], page_data[f'txt24ALine{line_num}DateOfServiceFromDD'], page_data[f'txt24ALine{line_num}DateOfServiceFromYY'] = mm, dd, yy
                mm, dd, yy = _split_date(line.get('date_of_service_to', ''))
                page_data[f'txt24ALine{line_num}DateOfServiceToMM'], page_data[f'txt24ALine{line_num}DateOfServiceToDD'], page_data[f'txt24ALine{line_num}DateOfServiceToYY'] = mm, dd, yy
                page_data[f'txt24BLine{line_num}PlaceOfService'] = line.get("place_of_service", "")
                page_data[f'txt24DLine{line_num}CPTHCPCSCode'] = line.get("procedures_cpt_hcpcs", "")
                page_data[f'txt24DLine{line_num}CPTHCPCSMod1'] = line.get("modifier_1", "")
                page_data[f'txt24DLine{line_num}CPTHCPCSMod2'] = line.get("modifier_2", "")
                page_data[f'txt24DLine{line_num}CPTHCPCSMod3'] = line.get("modifier_3", "")
                page_data[f'txt24DLine{line_num}CPTHCPCSMod4'] = line.get("modifier_4", "")
                page_data[f'txt24ELine{line_num}DiagnosisPointer'] = line.get("diagnosis_pointer", "")
                page_data[f'txt24FLine{line_num}Charges'] = line.get("charges", "")
                page_data[f'txt24GLine{line_num}DaysOrUnits'] = line.get("days_or_units", "")
                page_data[f'txt24JLine{line_num}RenderingProviderNPI'] = line.get("rendering_provider_id_npi", "")

            # Add totals only on the last page
            if (start_index + 6) >= len(service_lines):
                page_data['txtTotalCharge'] = form_data.get("28_total_charge", "")
                page_data['txtAmountPaid'] = form_data.get("29_amount_paid", "")

            writer_for_page.update_page_form_field_values(writer_for_page.pages[0], fields=page_data)
            
            in_memory_stream = io.BytesIO()
            writer_for_page.write(in_memory_stream)
            in_memory_stream.seek(0)
            
            reader_for_merging = PdfReader(in_memory_stream)
            reader_for_merging.add_form_topname(f"p{page_index}")
            final_writer.append(reader_for_merging)

            start_index += 6
            page_index += 1
            
        # 3. Write the final file
        with open(output_path, "wb") as output_file:
            final_writer.write(output_file)
            
        ui.notify(f"Successfully generated PDF ({len(final_writer.pages)} page(s)): {output_path.name}", type='positive')
        ui.download(str(output_path))

    except Exception as e:
        ui.notify(f"An unexpected error occurred: {e}", type='negative', multi_line=True)


def _generate_writer_for_claim(claim_object: dict, template_path: str) -> PdfWriter:
    """
    Helper function that takes a single 837P claim object and generates a 
    PdfWriter containing all its filled CMS-1500 pages. It renames form fields on each
    page to prevent data conflicts within a single multi-page claim.
    """
    writer = PdfWriter()
    
    # 1. Map all common data from the claim object
    pdf_data_common = {}
    subscriber = claim_object.get("subscriber", {})
    patient = claim_object.get("patient", subscriber)
    billing_provider = claim_object.get("billing_provider", {})
    claim_info = claim_object.get("claim_info", {})
    other_insured = claim_object.get("other_insured", {})
    referring_provider = claim_object.get("referring_provider", {})

    # --- Start Data Mapping (This section is correct and unchanged) ---
    ins_type = subscriber.get("insurance_type", "")
    pdf_data_common['chkMedicare'] = '/Yes' if ins_type == 'MEDICARE' else '/Off'
    pdf_data_common['chkMedicaid'] = '/Yes' if ins_type == 'MEDICAID' else '/Off'
    pdf_data_common['chkTricare'] = '/Yes' if ins_type == 'TRICARE' else '/Off'
    pdf_data_common['chkChampva'] = '/Yes' if ins_type == 'CHAMPVA' else '/Off'
    pdf_data_common['chkGroupHealthPlan'] = '/Yes' if ins_type == 'GROUP HEALTH PLAN' else '/Off'
    pdf_data_common['chkFecaBlkLung'] = '/Yes' if ins_type == 'FECA BLK LUNG' else '/Off'
    pdf_data_common['chkOtherCarrier'] = '/Yes' if ins_type == 'OTHER' else '/Off'
    pdf_data_common['txtInsuredsIDNumber'] = subscriber.get("subscriber_id", "")
    pdf_data_common['txtPatientsName'] = f'{patient.get("last_name", "")}, {patient.get("first_name", "")}'
    mm, dd, yy = _split_date(patient.get("dob", ""))
    pdf_data_common['txtPatientsDOBMM'], pdf_data_common['txtPatientsDOBDD'], pdf_data_common['txtPatientsDOBYY'] = mm, dd, yy
    patient_sex = patient.get("gender", "")
    pdf_data_common['chkPatientMale'] = '/Yes' if patient_sex == 'M' else '/Off'
    pdf_data_common['chkPatientFemale'] = '/Yes' if patient_sex == 'F' else '/Off'
    pdf_data_common['txtInsuredsName'] = f'{subscriber.get("last_name", "")}, {subscriber.get("first_name", "")}'
    pdf_data_common['txtPatientsAddress'] = patient.get("address", "")
    pdf_data_common['txtPatientsCity'] = patient.get("city", "")
    pdf_data_common['txtPatientsState'] = patient.get("state", "")
    pdf_data_common['txtPatientsZipcode'] = patient.get("zip", "")
    relationship = subscriber.get("relationship", "")
    pdf_data_common['chkPatientInsuredSelf'] = '/Yes' if relationship == 'SELF' else '/Off'
    pdf_data_common['chkPatientInsuredSpouse'] = '/Yes' if relationship == 'SPOUSE' else '/Off'
    pdf_data_common['chkPatientInsuredChild'] = '/Yes' if relationship == 'CHILD' else '/Off'
    pdf_data_common['chkPatientInsuredOther'] = '/Yes' if relationship == 'OTHER' else '/Off'
    pdf_data_common['txtInsuredsAddress'] = subscriber.get("address", "")
    pdf_data_common['txtInsuredsCity'] = subscriber.get("city", "")
    pdf_data_common['txtInsuredsState'] = subscriber.get("state", "")
    pdf_data_common['txtInsuredsZipcode'] = subscriber.get("zip", "")
    mm, dd, yy = _split_date(subscriber.get("dob", ""))
    pdf_data_common['txtInsuredsDOBMM'], pdf_data_common['txtInsuredsDOBDD'], pdf_data_common['txtInsuredsDOBYY'] = mm, dd, yy
    insured_sex = subscriber.get("gender", "")
    pdf_data_common['chkInsuredMale'] = '/Yes' if insured_sex == 'M' else '/Off'
    pdf_data_common['chkInsuredFemale'] = '/Yes' if insured_sex == 'F' else '/Off'
    pdf_data_common['txtOtherInsuredsName'] = f'{other_insured.get("last_name", "")}, {other_insured.get("first_name", "")}'
    pdf_data_common['txtOtherInsuredsPolicyOrGroupNumber'] = other_insured.get("policy_group_id", "")
    pdf_data_common['txtOtherInsurancePlanNameOrProgramName'] = other_insured.get("plan_name", "")
    is_employment = claim_info.get("clm_related_causes_01") == 'EM'
    is_auto = claim_info.get("clm_related_causes_02") == 'AA'
    is_other_accident = claim_info.get("clm_related_causes_02") == 'OA'
    pdf_data_common['chkPatientConditionRelatedToEmploymentYes'] = '/Yes' if is_employment else '/Off'
    pdf_data_common['chkPatientConditionRelatedToEmploymentNo'] = '/Yes' if not is_employment else '/Off'
    pdf_data_common['chkPatientConditionRelatedToAutoAccidentYes'] = '/Yes' if is_auto else '/Off'
    pdf_data_common['chkPatientConditionRelatedToAutoAccidentNo'] = '/Yes' if not is_auto else '/Off'
    pdf_data_common['txtPatientAutoAccidentState'] = claim_info.get("clm_related_causes_04", "") if is_auto else ""
    pdf_data_common['chkPatientConditionRelatedToOtherAccidentYes'] = '/Yes' if is_other_accident else '/Off'
    pdf_data_common['chkPatientConditionRelatedToOtherAccidentNo'] = '/Yes' if not is_other_accident else '/Off'
    pdf_data_common['txtInsuredsPolicyGroupOrFecaNumber'] = subscriber.get("sub_group_feca_num", "")
    pdf_data_common['txtInsuredsInsurancePlanNameOrProgramName'] = subscriber.get("sub_insurance_name", "")
    has_other_plan = bool(other_insured)
    pdf_data_common['chkIsThereAnotherHealthPlanYes'] = '/Yes' if has_other_plan else '/Off'
    pdf_data_common['chkIsThereAnotherHealthPlanNo'] = '/Yes' if not has_other_plan else '/Off'
    pdf_data_common['txtPatientSignatureDate'] = claim_info.get("claim_service_date", "")
    mm, dd, yy = _split_date(claim_info.get("date_current_illness", ""))
    pdf_data_common['txtDateOfIllnessMM'], pdf_data_common['txtDateOfIllnessDD'], pdf_data_common['txtDateOfIllnessYY'] = mm, dd, yy
    pdf_data_common['txtDateOfIllnessQualifier'] = claim_info.get("date_current_illness_qual", "")
    mm, dd, yy = _split_date(claim_info.get("disability_begins", ""))
    pdf_data_common['txtDatePatientUnableToWorkStartMM'], pdf_data_common['txtDatePatientUnableToWorkStartDD'], pdf_data_common['txtDatePatientUnableToWorkStartYY'] = mm, dd, yy
    mm, dd, yy = _split_date(claim_info.get("disability_ends", ""))
    pdf_data_common['txtDatePatientUnableToWorkEndMM'], pdf_data_common['txtDatePatientUnableToWorkEndDD'], pdf_data_common['txtDatePatientUnableToWorkEndYY'] = mm, dd, yy
    mm, dd, yy = _split_date(claim_info.get("hosp_admission", ""))
    pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartMM'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartDD'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesStartYY'] = mm, dd, yy
    mm, dd, yy = _split_date(claim_info.get("hosp_discharge", ""))
    pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndMM'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndDD'], pdf_data_common['txtHospitalizationDateRelatedToCurrentServicesEndYY'] = mm, dd, yy
    pdf_data_common['txtNameOfReferringProviderOrOtherSourceQualifier'] = referring_provider.get("qual", "")
    pdf_data_common['txtNameOfReferringProviderOrOtherSource'] = f'{referring_provider.get("first_name", "")} {referring_provider.get("last_name", "")}'.strip()
    pdf_data_common['txtReferringProviderOrOtherSourceNPI'] = referring_provider.get("npi", "")
    pdf_data_common['txt21ICDInd01'] = claim_info.get("diagnoses_q_1", "")
    pdf_data_common['txt21ICDInd02'] = claim_info.get("diagnoses_q_2", "")
    diagnoses = claim_object.get("diagnoses", [])
    for i, diag in enumerate(diagnoses[:12]):
        field_letter = chr(65 + i)
        pdf_data_common[f'txt21DiagnosisCode{field_letter}'] = diag.get("code", "")
    pdf_data_common['txtResubmissionCode'] = claim_info.get("resubmission_code", "")
    pdf_data_common['txtResubmissionCodeOriginalRefNumber'] = claim_info.get("original_ref_no", "")
    pdf_data_common['txtPriorAuthorizationNumber'] = claim_info.get("prior_authorization_number", "")
    pdf_data_common['txtFederalTaxIDNumber'] = billing_provider.get("tax_id", "")
    pdf_data_common['chkFederalTaxIDEIN'] = '/Yes'
    pdf_data_common['txtPatientsAccountNumber'] = claim_info.get('claim_control_number')
    accept_assign = claim_info.get('assignment_acceptance') == 'A'
    pdf_data_common['chkAcceptAssignmentYes'] = '/Yes' if accept_assign else '/Off'
    pdf_data_common['chkAcceptAssignmentNo'] = '/Yes' if not accept_assign else '/Off'
    pdf_data_common['txt31DateOfAttestation'] = claim_info.get("claim_service_date", "")
    pdf_data_common['txt33BillingProviderInfo1'] = billing_provider.get("name", "")
    pdf_data_common['txt33BillingProviderInfo2'] = f'{billing_provider.get("address", "")}\n{billing_provider.get("city", "")} {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
    pdf_data_common['txt33BillingProviderPhone'] = billing_provider.get("phone", "")
    pdf_data_common['txt33BillingProviderNPI'] = billing_provider.get("npi", "")
    # --- End of Common Data Mapping ---

    # 2. Process service lines in chunks (CMS-1500 has 6 lines per page)
    service_lines = claim_object.get('service_lines', [])
    if not service_lines:
        service_lines = [{}] 

    start_index = 0
    page_index = 0
    while start_index < len(service_lines):
        chunk = service_lines[start_index : start_index + 6]
        page_data = pdf_data_common.copy()
        
        # Create a filled, single-page PDF in memory for this chunk
        reader = PdfReader(template_path)
        writer_for_page = PdfWriter()
        writer_for_page.append(reader)

        # Populate service line data for the current chunk
        for i, line in enumerate(chunk):
            line_num = i + 1
            mm, dd, yy = _split_date(line.get('date_of_service', ''))
            page_data[f'txt24ALine{line_num}DateOfServiceFromMM'], page_data[f'txt24ALine{line_num}DateOfServiceFromDD'], page_data[f'txt24ALine{line_num}DateOfServiceFromYY'] = mm, dd, yy
            page_data[f'txt24BLine{line_num}PlaceOfService'] = claim_info.get("place_of_service_code", "")
            page_data[f'txt24DLine{line_num}CPTHCPCSCode'] = line.get("procedure_code", "")
            modifiers = line.get("modifiers", [])
            for mod_idx, mod in enumerate(modifiers[:4]):
                page_data[f'txt24DLine{line_num}CPTHCPCSMod{mod_idx+1}'] = mod
            page_data[f'txt24ELine{line_num}DiagnosisPointer'] = "".join(line.get("diagnosis_pointers", []))
            page_data[f'txt24FLine{line_num}Charges'] = line.get("line_item_charge_amount", "")
            page_data[f'txt24GLine{line_num}DaysOrUnits'] = line.get("quantity", "")
            page_data[f'txt24JLine{line_num}RenderingProviderNPI'] = line.get("rendering_provider", {}).get("npi", "")

        # Add totals only on the last page for this claim
        if (start_index + 6) >= len(service_lines):
            page_data['txtTotalCharge'] = claim_info.get("total_claim_charge_amount", "")
            page_data['txtAmountPaid'] = claim_info.get("amount_paid", "")

        writer_for_page.update_page_form_field_values(writer_for_page.pages[0], fields=page_data)
        
        # Write to memory, read back, apply page prefix, and append to the main writer
        in_memory_stream = io.BytesIO()
        writer_for_page.write(in_memory_stream)
        in_memory_stream.seek(0)
        
        reader_for_merging = PdfReader(in_memory_stream)
        
        # --- THIS IS THE CORRECTED LINE ---
        # Only apply the page-level prefix here. The claim-level prefix
        # will be handled by the calling function.
        reader_for_merging.add_form_topname(f"p{page_index}")
        # ------------------------------------
        
        writer.append(reader_for_merging)

        start_index += 6
        page_index += 1
        
    return writer


def _run_pdf_generation_task(all_claims_data: dict, xml_file_name: str, template_path: str) -> dict:
    """
    Synchronous worker function to generate the combined CMS-1500 PDF.
    """
    try:
        master_merger = PdfWriter()

        for i, claim_object in enumerate(all_claims_data['claims']):
            claim_id = claim_object.get("claim_info", {}).get("claim_control_number", f"claim{i}")
            
            # Use the helper to get a writer with all pages for this single claim,
            # already prefixed internally for multi-page handling.
            # writer_for_this_claim = _generate_writer_for_claim(claim_object, template_path, f"claim_{claim_id}")
            writer_for_this_claim = _generate_writer_for_claim(claim_object, template_path)

            # Write this claim's pages to an in-memory stream
            claim_stream = io.BytesIO()
            writer_for_this_claim.write(claim_stream)
            claim_stream.seek(0)
            
            # Read the stream back and apply the unique claim-level prefix
            reader_for_merging = PdfReader(claim_stream)
            reader_for_merging.add_form_topname(f"claim_{claim_id}")
            
            # Append the prefixed pages to the master merger
            master_merger.append(reader_for_merging)
                        
            # The writer contains pages with fields like "claim_123_p0.FieldName".
            # We can now append these pages directly.
            # master_merger.append(writer_for_this_claim)

        # Define output paths
        project_root = Path(__file__).resolve().parent.parent
        xml_stem = Path(xml_file_name).stem
        output_dir = project_root / 'claims_upload' / xml_stem / 'pdf_gen'
        output_dir.mkdir(parents=True, exist_ok=True)
        output_filename = f"{xml_stem}_all_claims_cms1500.pdf"
        output_path = output_dir / output_filename

        # Write the final file
        with open(output_path, "wb") as f:
            master_merger.write(f)

        return {
            "success": True,
            "output_path": str(output_path),
            "output_filename": output_filename,
            "claim_count": len(all_claims_data['claims']),
            "page_count": len(master_merger.pages)
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


async def createCombinedPdfForAllClaims(all_claims_data: dict, xml_file_name: str):
    """
    Asynchronously generates a single, combined PDF file for all CMS-1500 claims.
    """
    if not all_claims_data or not all_claims_data.get('claims'):
        ui.notify("No claims data available to generate PDF.", type='warning')
        return

    notification = ui.notification('Starting CMS-1500 PDF generation... This may take a moment.', spinner=True, timeout=None)
    
    try:
        project_root = Path(__file__).resolve().parent.parent
        template_path = str(project_root / 'tools' / 'pdf_formats' / '837-p-form-cms1500-mod.pdf')
        
        result = await run.cpu_bound(
            _run_pdf_generation_task,
            all_claims_data,
            xml_file_name,
            template_path
        )

        notification.dismiss()

        if result["success"]:
            msg = f"Successfully generated '{result['output_filename']}' ({result['claim_count']} claims, {result['page_count']} pages)"
            ui.notify(msg, type='positive')
            ui.download(result['output_path'])
        else:
            ui.notify(f"An error occurred: {result['error']}", type='negative', multi_line=True)

    except Exception as e:
        notification.dismiss()
        ui.notify(f"An unexpected error occurred while setting up the PDF task: {e}", type='negative', multi_line=True)


def make_xml_node_table(rows: List[Dict[str, str]], form_data: dict[str, str]):
    """Render a simple 3-column table using ui.row and ui.column instead of ui.table."""
    global search_field
    current_field = None
    computed_rows = copy.deepcopy(rows)
    rows_workbench = copy.deepcopy(rows)
    # headers = ["node-text", "text-value","xml-path"]
    headers = ["node-text", "text-value"]
    input_registry: Dict[str, ui.input] = {}

    with ui.row().classes('gap-1 border no-wrap').style('width: 500px;'):
        clear_button = ui.button(icon='refresh').on_click(lambda: filter_value_changed('')).props('dense')
        filter_input = ui.input('').props('flat dense outline clearable').classes('w-full').style('height: 36px;')
        search_field = filter_input

    @ui.refreshable
    def render_table():
        nonlocal current_field
        input_registry.clear()
        with ui.element('div').style(
        'max-height:600px; overflow-y:auto; box-sizing:border-box;'
        'padding:0; margin:0;'
        ):
            with ui.column().style('min-width:500px').classes('gap-0 border w-full'):
                with ui.row().classes('gap-0 w-full border no-wrap'):
                    for header in headers:
                        with ui.column().classes('border w-2/3' if header == 'node-text' else 'border w-1/3'):
                            ui.input('EDI Node' if header == 'node-text' else 'Value').classes('w-full').props('flat dense outline readonly')
                
                for row in computed_rows:
                    with ui.row().classes('gap-0 w-full border no-wrap'):
                        for key in headers:
                            value = row.get(key, "")
                            with ui.column().classes('border w-2/3' if key == 'node-text' else 'border w-1/3'):
                                if key == "text-value":
                                    temp_input = ui.input('').props('flat dense outline').style('height: 36px;').classes('w-full')
                                    temp_path = row.get('xml-path',None)
                                    temp_input.value = get_text_value(temp_path)
                                    input_registry[temp_path] = temp_input

                                    temp_input.on_value_change(lambda e, p=temp_path: update_text_value(p,e.value))
                                    if temp_path is not None:
                                        tmp_key = get_key_by_ref(form_data,temp_path)
                                        # print(f't_key : {tmp_key} | path: {temp_path} | c_field: {current_field}')
                                        if tmp_key is not None:
                                            if current_field is not None:
                                                if tmp_key == current_field:
                                                    temp_input.bind_value(form_data,current_field)
                                                else:
                                                    temp_input.bind_value(form_data,current_field)
                                            else:
                                                temp_input.bind_value(form_data,tmp_key)
                                        elif current_field is not None:
                                            temp_input.bind_value(form_data,current_field)

                                        current_field = None
                                else:
                                    temp_input = ui.input('').props('flat dense outline readonly').style('height: 36px;').classes('w-full')
                                    temp_input.value = value

    def change_dataset(new_rows: List[Dict[str, str]], form_data: dict[str, str]):
        nonlocal rows, rows_workbench, computed_rows

        rows = copy.deepcopy(new_rows)
        rows_workbench = copy.deepcopy(new_rows)
        computed_rows = copy.deepcopy(new_rows)
        render_table.refresh()

    def get_changes()->List[Dict[str, str]]:
        changes: List[Dict[str, str]] = []
        for orig_row in rows:
            if get_text_value(orig_row["xml-path"]) != orig_row["text-value"]:
                changed_row = {"node-text": orig_row["node-text"], "text-value": get_text_value(orig_row["xml-path"]), "xml-path": orig_row["xml-path"]}
                changes.append(changed_row)

        return changes

    def get_key_by_ref(form_data, ref_value):
        for key, value in form_data.items():
            if key is not None:
                if key.endswith("_filter") and value == ref_value:
                    return key[:-7]
        return None


    def filter_rows(rows: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
        """
        Filters rows based on a simple text query or a structured conditional query,
        correctly handling indexed paths and sibling relationships.
        """
        if query is None or len(str(query).strip()) < 3:
            return rows

        q = str(query).strip()
        
        # Regex to parse a conditional query like: TARGET_PATH(CONDITION_ELEMENT=VALUE)
        # e.g., .../REF/REF02(REF01=F8)
        m = re.match(
            r'^\s*([a-zA-Z0-9_/\[\]-]+)\s*\(\s*([a-zA-Z0-9_-]+)\s*=\s*([^)]+?)\s*\)\s*$',
            q
        )

        # --- Case 1: Simple text search (no conditional parenthesis) ---
        if not m:
            ql = q.lower()
            return [
                row for row in rows
                if any(ql in str(value).lower() for value in row.values())
            ]

        # --- Case 2: Structured conditional search ---
        target_expr, cond_element_id, cond_value = m.groups()
        cond_value = cond_value.strip()

        def strip_indices(path: str) -> str:
            return re.sub(r'\[\d+\]', '', path)

        # 1. Group all elements by their immediate parent's path. This creates a
        #    structure that understands sibling relationships.
        grouped_by_parent: Dict[str, Dict[str, str]] = {}
        for row in rows:
            path = row.get('xml-path', '')
            if '/' not in path:
                continue
            
            parts = path.split('/')
            parent_path = '/'.join(parts[:-1])
            element_id = parts[-1]
            element_value = row.get('text-value', '')
            
            grouped_by_parent.setdefault(parent_path, {})[element_id] = element_value

        # 2. Identify the target element and its parent path from the query.
        target_element_id = target_expr.split('/')[-1]
        # This is the crucial part: we use the TARGET's parent path as our context.
        stripped_target_parent_path = strip_indices('/'.join(target_expr.split('/')[:-1]))

        # 3. Find the exact paths of the target rows that satisfy the condition.
        target_paths = set()
        for parent_path, children in grouped_by_parent.items():
            # Condition 1: Check if this group's parent path matches the target's parent path.
            if strip_indices(parent_path) == stripped_target_parent_path:
                # Condition 2: Check if the conditional element exists in this specific
                # sibling group and has the correct value.
                if children.get(cond_element_id) == cond_value:
                    # If both conditions are true, this is a valid group.
                    # Now, find the target element within this same valid group.
                    if target_element_id in children:
                        full_target_path = f"{parent_path}/{target_element_id}"
                        target_paths.add(full_target_path)
        
        # 4. Return only the original rows whose full path is in our set of valid targets.
        return [row for row in rows if row.get('xml-path') in target_paths]

    def filter_value_changed(value, field = None):
        nonlocal current_field
        if filter_input.value != value:
            filter_input.value = value
        nonlocal computed_rows
        computed_rows = filter_rows(rows, value)

        if field is not None:
            current_field = field
        else:
            current_field = None
        render_table.refresh()

    def update_text_value(xml_path: str, new_value: str):
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                row["text-value"] = new_value
                break

    def get_text_value(xml_path: str)->str:
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                return row["text-value"]
        return ""

    filter_input.on_value_change(lambda e: filter_value_changed(e.value))
    render_table()

    return {
        "filter_value_changed": filter_value_changed,
        "render_table": render_table,
        "get_changes": get_changes,
        "change_dataset": change_dataset
    }
