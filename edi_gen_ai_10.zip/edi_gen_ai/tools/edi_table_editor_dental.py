import sys
import xml.etree.ElementTree as ET
import os
import re
import io
import subprocess
from typing import Dict, Any, Optional, List, Set, Tuple, Union
from nicegui import ui, app, run
from pathlib import Path
from pypdf import PdfReader, PdfWriter
from .xmltotree import xml_tree_gen
from typing import List, Dict
from datetime import datetime
import copy
from edi_gen_ai.tools.ada_dental import form_data
from edi_gen_ai.config import EDI837D_SCHEMA

# ---------- Config ----------
# Keep schema path consistent with edi_837_tree.py so both components load the same definition
SCHEMA_FILE = EDI837D_SCHEMA

grid = None
search_field = None

# Global: holds the parsed XML tree of the currently loaded SINGLE claim
data_tree: Optional[ET.ElementTree] = None

ANCHORS = {
    # common anchors you'll see early in EDI XML
    "ISA_LOOP", "GS_LOOP", "ST_LOOP", "HEADER", "DETAIL",
    # common loops/segments
    "1000A", "1000B", "2000A", "2000B", "2300", "2400",
    "CLM", "NM1", "HI", "SV1", "LX"
}

async def filter_name_contains(substr: str, fieldstr: str = None):
    global grid
    if fieldstr is not None:
        grid["filter_value_changed"](substr, fieldstr)
    else:
        grid["filter_value_changed"](substr)

# ---------- Single-claim extraction (kept API-compatible with edi_837_tree.py) ----------
def get_single_claim_xml(claim_id: str, xml_file_path: str) -> str | None:
    """
    Parses an 837 EDI XML file, finds a single claim by its ID, and removes
    all other claims and billing provider loops (2000A) to isolate the
    single claim's hierarchy. It then readjusts segment and loop counters
    and returns the modified XML as a string.
    """
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except (FileNotFoundError, ET.ParseError) as e:
        print(f"Error reading or parsing source file {xml_file_path}: {e}")
        return None

    # Find the DETAIL loop which acts as the parent for all 2000A loops.
    detail_loop = root.find(".//loop[@id='DETAIL']")
    if detail_loop is None:
        print("Error: Could not find the main detail loop (DETAIL).")
        return None

    target_2000a = None
    target_2000b = None

    # Find the specific 2000A and 2000B loops containing the claim
    for loop_2000a in detail_loop.findall("loop[@id='2000A']"):
        for loop_2000b in loop_2000a.findall("loop[@id='2000B']"):
            clm_segment = loop_2000b.find(".//seg[@id='CLM']/ele[@id='CLM01']")
            if clm_segment is not None and clm_segment.text == claim_id:
                target_2000a = loop_2000a
                target_2000b = loop_2000b
                break  # Found the claim, exit inner loop
        if target_2000a:
            break  # Found the provider, exit outer loop

    if not target_2000a:
        print(f"Claim with ID '{claim_id}' not found.")
        return None

    # --- Filter Sibling 2000B Loops ---
    # Keep all children of the target 2000A loop EXCEPT for other 2000B loops.
    children_of_2000a_to_keep = []
    for child in target_2000a:
        if child.get('id') != '2000B':
            children_of_2000a_to_keep.append(child)
        elif child is target_2000b:  # Only keep the specific 2000B we found
            children_of_2000a_to_keep.append(child)
    
    target_2000a[:] = children_of_2000a_to_keep

    # --- Filter Sibling 2000A Loops ---
    # Replace all children of the DETAIL loop with only our modified target 2000A loop.
    detail_loop[:] = [target_2000a]

    # --- Recalculate Counters ---
    hl_segments = root.findall('.//seg[@id="HL"]')
    old_to_new_hl_map = {}
    for i, hl_seg in enumerate(hl_segments, start=1):
        hl01 = hl_seg.find("ele[@id='HL01']")
        if hl01 is not None:
            old_hl_id = hl01.text
            new_hl_id = str(i)
            old_to_new_hl_map[old_hl_id] = new_hl_id
            hl01.text = new_hl_id
        hl02 = hl_seg.find("ele[@id='HL02']")
        if hl02 is not None and hl02.text in old_to_new_hl_map:
            hl02.text = old_to_new_hl_map[hl02.text]

    st_loop = root.find(".//loop[@id='ST_LOOP']")
    if st_loop is not None:
        total_segments = len(st_loop.findall('.//seg'))
        se01 = st_loop.find("seg[@id='SE']/ele[@id='SE01']")
        if se01 is not None:
            se01.text = str(total_segments)

    return ET.tostring(root, encoding='unicode')

# ---------- Schema parsing with collision handling (from table editor) ----------
def parse_schema_hierarchically(schema_file: str):
    try:
        tree = ET.parse(schema_file)
        schema_root = tree.getroot()
    except (ET.ParseError, FileNotFoundError) as e:
        ui.notify(f"Fatal Error: Could not parse schema file '{schema_file}'. {e}", type='negative', multi_line=True)
        return None, None, None, None, None

    def _extract_display_name(elem: ET.Element, default: str) -> str:
        for tag in ('name', 'desc', 'description', 'title', 'label'):
            t = elem.findtext(tag)
            if t and t.strip():
                return t.strip()
        t = elem.get('name')
        if t and t.strip():
            return t.strip()
        return default

    def _parse_node(xml_element: ET.Element) -> Dict[str, Any]:
        node_id = xml_element.get('xid')
        node_info = {'name': _extract_display_name(xml_element, node_id), 'children': {}}
        valid_codes_elem = xml_element.find('valid_codes')
        if valid_codes_elem is not None:
            codes = [code.text for code in valid_codes_elem.findall('code') if code.text]
            if codes:
                node_info['codes'] = codes
        for child_xml in xml_element:
            if 'xid' in child_xml.attrib:
                child_id = child_xml.get('xid')
                node_info['children'][child_id] = _parse_node(child_xml)
        return node_info

    root_xid = schema_root.get('xid')
    hierarchical_schema = {root_xid: _parse_node(schema_root)}

    schema_path_index: Dict[Tuple[str, ...], Dict] = {}
    seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]] = {}
    flat_names: Dict[str, str] = {}
    xid_collisions: Dict[str, set] = {}

    def _index_paths(node: Dict, path: Tuple[str, ...]):
        schema_path_index[path] = node
        xid = path[-1] if len(path) >= 2 else None
        if isinstance(xid, str) and len(xid) >= 4 and xid[-2:].isdigit():
            seg_id = xid[:-2]
            key = (seg_id, xid)
            seg_ele_index.setdefault(key, []).append(path)
            name = node.get('name', xid)
            if xid in flat_names and flat_names[xid] != name:
                xid_collisions.setdefault(xid, set()).update([flat_names[xid], name])
            else:
                flat_names.setdefault(xid, name)
        for child_id, child_node in node.get('children', {}).items():
            _index_paths(child_node, path + (child_id,))

    _index_paths(hierarchical_schema[root_xid], (root_xid,))
    for k in list(flat_names.keys()):
        if k in xid_collisions:
            del flat_names[k]

    return hierarchical_schema, flat_names, schema_path_index, seg_ele_index, xid_collisions


# ---------- Name resolver (from table editor) ----------
def _name_for_xid(ele_id: str,
                  path_ids: Tuple[str, ...],
                  schema_path_index: Dict[Tuple[str, ...], Dict],
                  seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]],
                  flat_schema_unique: Dict[str, str]) -> str:
    node = schema_path_index.get(path_ids)
    if node:
        n = node.get('name')
        if n:
            return n
    if len(ele_id) >= 4 and ele_id[-2:].isdigit():
        seg_id = ele_id[:-2]
        paths = seg_ele_index.get((seg_id, ele_id)) or []
        if len(paths) == 1:
            node2 = schema_path_index.get(paths[0])
            if node2:
                n2 = node2.get('name')
                if n2:
                    return n2
    n3 = flat_schema_unique.get(ele_id)
    if n3:
        return n3
    return ele_id

def create_node_by_edi_path(root: ET.Element, edi_path: str) -> ET.Element:
    """
    Traverses an EDI path and creates any missing loops, segments, or elements,
    correctly handling indexed paths to create repeating segments.
    """
    parts = edi_path.strip("/").split("/")
    
    # Heuristic: If the path is ambiguous (e.g., .../REF/REF02[2]), it implies
    # the index should apply to the parent segment. We rewrite the path to be
    # unambiguous (e.g., .../REF[2]/REF02) before processing.
    if len(parts) >= 2:
        tag_ele, num_ele = parse_word_number(parts[-1])
        tag_seg, num_seg = parse_word_number(parts[-2])

        if num_ele is not None and num_ele > 1 and num_seg is None:
            parts[-1] = tag_ele
            parts[-2] = f"{tag_seg}[{num_ele}]"

    current = root
    for idx, part in enumerate(parts):
        tag_id, item_num = parse_word_number(part)
        
        # Default to the first instance (index 0) if no index is given
        target_index = (item_num - 1) if item_num is not None else 0
        if target_index < 0:
            target_index = 0

        matches = [child for child in current if child.get('id') == tag_id]
        node_tag = _infer_tag_from_path(parts, idx)

        # If not enough existing nodes are found, create new ones until the
        # target index can be fulfilled.
        while len(matches) <= target_index:
            new_node = ET.SubElement(current, node_tag, {"id": tag_id})
            matches.append(new_node)
        
        # Move traversal to the target node for the next part of the path.
        current = matches[target_index]
    
    return current

def _infer_tag_from_path(parts, idx):
    """
    pyx12 XML convention:
      - everything before the last 2 items => loop
      - second-to-last item => seg
      - last item => ele
    """
    n = len(parts)
    if idx == n - 1:
        return "ele"
    if idx == n - 2:
        return "seg"
    return "loop"



def parse_word_number(s: str) -> Tuple[str, Optional[int]]:
    """
    Parses a string like 'NM101' or 'REF[2]' into its name and an integer index.
    Returns the name and the index (if present), otherwise the index is None.
    """
    match = re.match(r'^([a-zA-Z0-9_-]+)(?:\[(\d+)\])?$', s)
    if match:
        word = match.group(1)
        number_str = match.group(2)
        number = int(number_str) if number_str else None
        return word, number
    return s, None

def get_node_by_edi_path(root: ET.Element, edi_path: str) -> Optional[ET.Element]:
    """
    Traverses an XML tree to find a specific node based on an indexed EDI path.
    e.g., ".../2300/REF[2]/REF01"
    """
    current = root
    parts = edi_path.strip("/").split("/")
    
    for part in parts:
        if current is None:
            return None
        
        tag_id, item_num = parse_word_number(part)
        # Default to the first occurrence (index 0) if no index is specified
        target_index = (item_num - 1) if item_num is not None else 0
        if target_index < 0:
            target_index = 0

        # Find all direct children that match the tag ID
        matches = [child for child in current if child.get('id') == tag_id]
        
        if len(matches) > target_index:
            current = matches[target_index]
        else:
            # The requested node or its specific instance does not exist
            return None
    return current

def form_to_edi_date(date_str, out_fmt='%Y%m%d'):
    if not date_str or not isinstance(date_str, str):
        return None

    supported_formats = [
        '%m/%d/%Y',  # Handles '05/15/2024'
        '%m/%d/%y',  # Handles '05/15/24'
        '%Y-%m-%d',  # Handles '2024-05-15'
        '%Y%m%d',    # Handles '20240515'
    ]

    for fmt in supported_formats:
        try:
            dt_obj = datetime.strptime(date_str, fmt)
            return dt_obj.strftime(out_fmt)
        except ValueError:
            continue

    print(f"Warning: Could not parse unsupported date format: '{date_str}'", file=sys.stderr)
    return date_str

def get_segment_id(path: str) -> str:
    """
    Extract the final EDI segment identifier from a path,
    removing any trailing [index].
    """
    last_part = path.rsplit("/", 1)[-1]
    return last_part.split("[", 1)[0]



def update_xml_from_grid(tree: ET.ElementTree, grid_data: List[Dict], form_data_dict: Dict):
    """
    Updates the XML tree from grid data and handles conditional node creation,
    correctly disambiguating filters that map to the same XML element.
    """
    root = tree.getroot()
    updated = 0
    # Create a map of {filter_path: form_data_key}, e.g., {'.../REF02(REF01=F8)': '2_original_ref_no_filter'}
    filter_map = {v: k for k, v in form_data_dict.items() if isinstance(k, str) and k.endswith('_filter')}

    def parse_filter_path(filter_path):
        match = re.match(r'^(.*?)\((.*?)=(.*?)\)$', filter_path)
        if match:
            base_path, cond_key, cond_val = match.groups()
            return base_path, cond_key, cond_val
        return filter_path, None, None

    def strip_indices(p):
        return re.sub(r'\[\d+\]', '', p)

    for item in grid_data:
        full_path = item.get('xml-path')
        path = full_path.replace('837/', '')
        val = item.get('text-value')

        if not path:
            continue

        if get_segment_id(path) in ("DMG02", "DTP03"):
            val = form_to_edi_date(val)
        
        node = create_node_by_edi_path(root, path)
        node.text = val
        updated += 1

        # --- AMBIGUITY-AWARE CONDITIONAL LOGIC ---
        stripped_item_path = strip_indices(full_path)
        
        # 1. Find all possible conditional filters that match the item's path.
        matching_filters = []
        for f_path in filter_map.keys():
            base_path, _, _ = parse_filter_path(f_path)
            if strip_indices(base_path) == stripped_item_path:
                matching_filters.append(f_path)
        
        # 2. If any filters match, decide which one to use.
        chosen_filter = None
        if len(matching_filters) == 1:
            chosen_filter = matching_filters[0]
        elif len(matching_filters) > 1:
            # Disambiguate by finding the filter whose corresponding form_data value
            # matches the value being saved from the grid item.
            for f_path in matching_filters:
                form_filter_key = filter_map[f_path]  # e.g., '2_original_ref_no_filter'
                form_data_key = form_filter_key.replace('_filter', '')  # e.g., '2_original_ref_no'
                
                # Check if the value from the main form dictionary matches the new value.
                if form_data_dict.get(form_data_key) == val:
                    chosen_filter = f_path
                    break
        
        # 3. If a filter was chosen, apply its conditional logic.
        if chosen_filter:
            _, cond_key, cond_val = parse_filter_path(chosen_filter)
            if cond_key:
                parent_path = '/'.join(path.split('/')[:-1])
                sibling_path = f"{parent_path}/{cond_key}"
                
                sibling_node = create_node_by_edi_path(root, sibling_path)
                sibling_node.text = cond_val

    return tree, updated



def update_xml_2000B_from_grid(topnode: ET.Element, grid_data: List[Dict], form_data_dict: Dict):
    """
    Updates a 2000B loop from grid data and handles conditional node creation,
    correctly disambiguating filters that map to the same XML element.
    """
    updated = 0
    # Create a map of {filter_path: form_data_key}, e.g., {'.../REF02(REF01=F8)': '2_original_ref_no_filter'}
    filter_map = {v: k for k, v in form_data_dict.items() if isinstance(k, str) and k.endswith('_filter')}

    def parse_filter_path(filter_path):
        match = re.match(r'^(.*?)\((.*?)=(.*?)\)$', filter_path)
        if match:
            base_path, cond_key, cond_val = match.groups()
            return base_path, cond_key, cond_val
        return filter_path, None, None

    def strip_indices(p):
        return re.sub(r'\[\d+\]', '', p)

    for item in grid_data:
        full_path = item.get('xml-path')
        parts = full_path.split('/')
        if '2000B' not in parts:
            continue
        
        idx = parts.index('2000B')
        scoped_path = '/'.join(parts[idx+1:])
        val = item.get('text-value')

        if get_segment_id(scoped_path) in ("DMG02", "DTP03"):
            val = form_to_edi_date(val)

        node = create_node_by_edi_path(topnode, scoped_path)
        node.text = val
        updated += 1
        
        # --- AMBIGUITY-AWARE CONDITIONAL LOGIC ---
        stripped_full_path = strip_indices(full_path)

        # 1. Find all possible conditional filters that match the item's path.
        matching_filters = []
        for f_path in filter_map.keys():
            base_path, _, _ = parse_filter_path(f_path)
            if strip_indices(base_path) == stripped_full_path:
                matching_filters.append(f_path)
        
        # 2. If any filters match, decide which one to use.
        chosen_filter = None
        if len(matching_filters) == 1:
            chosen_filter = matching_filters[0]
        elif len(matching_filters) > 1:
            # Disambiguate by finding the filter whose corresponding form_data value
            # matches the value being saved from the grid item.
            for f_path in matching_filters:
                form_filter_key = filter_map[f_path]
                form_data_key = form_filter_key.replace('_filter', '')
                
                if form_data_dict.get(form_data_key) == val:
                    chosen_filter = f_path
                    break
        
        # 3. If a filter was chosen, apply its conditional logic.
        if chosen_filter:
            _, cond_key, cond_val = parse_filter_path(chosen_filter)
            if cond_key:
                parent_scoped_path = '/'.join(scoped_path.split('/')[:-1])
                sibling_scoped_path = f"{parent_scoped_path}/{cond_key}"
                
                sibling_node = create_node_by_edi_path(topnode, sibling_scoped_path)
                sibling_node.text = cond_val
                
    return updated




# ---------- Build rows for grid (from table editor) ----------
def build_table_rows_from_tree(root: ET.Element,
                               hierarchical_schema: Dict,
                               flat_schema_unique: Dict[str, str],
                               schema_path_index: Dict[Tuple[str, ...], Dict],
                               seg_ele_index: Dict[Tuple[str, str], List[Tuple[str, ...]]],
                               ) -> List[Dict[str, str]]:
    """
    Recursively builds a flat list of rows for the grid from the XML tree,
    correctly generating indexed paths for repeating segments and the specific
    redundant paths required for composite elements.
    """
    rows: List[Dict[str, str]] = []
    top_data_loop = root.find('loop')
    if top_data_loop is None:
        return rows
    
    top_schema_node = next(iter(hierarchical_schema.values()))['children'].get('ISA_LOOP')
    if not top_schema_node:
        return rows
        
    root_schema_xid = next(iter(hierarchical_schema.keys()))
    base_path = (root_schema_xid, 'ISA_LOOP')

    def walk(data_node: ET.Element, schema_node: Dict, path_ids: Tuple[str, ...], xml_path: str):
        # This function is called for a structural node (<loop> or <seg>)
        
        child_id_counts = {}
        for child in data_node:
            child_id = child.get('id')
            if child_id:
                child_id_counts[child_id] = child_id_counts.get(child_id, 0) + 1
        
        current_indices = {key: 0 for key in child_id_counts}

        for child_data in data_node:
            child_id = child_data.get('id')
            if not child_id:
                continue

            child_schema = schema_node.get('children', {}).get(child_id, schema_node)
            new_path_ids = path_ids + (child_id,)
            
            # --- Handle different node types based on their XML tag ---

            if child_data.tag in ('loop', 'seg'):
                new_xml_path_part = child_id
                if child_id_counts.get(child_id, 0) > 1:
                    current_indices[child_id] += 1
                    new_xml_path_part = f"{child_id}[{current_indices[child_id]}]"
                
                new_xml_path = f"{xml_path}/{new_xml_path_part}"
                walk(child_data, child_schema, new_path_ids, new_xml_path)

            elif child_data.tag == 'comp':
                # --- THIS IS THE CORRECTED LOGIC FOR COMPOSITE ELEMENTS ---
                comp_id = child_data.get('id')
                if not comp_id:
                    continue

                # The base path for sub-elements is the parent segment's path
                # PLUS the composite element's own ID.
                # e.g., .../2300/CLM -> .../2300/CLM/CLM
                comp_base_path = f"{xml_path}/{comp_id}"

                for sub_ele in child_data:
                    sub_ele_id = sub_ele.get('id')
                    if not sub_ele_id:
                        continue
                    
                    # The final path includes the composite ID segment.
                    # e.g., .../2300/CLM/CLM/CLM05-03
                    ele_xml_path = f"{comp_base_path}/{sub_ele_id}"
                    
                    current_value = (sub_ele.text or '').strip()
                    ele_path = new_path_ids + (sub_ele_id,)
                    ele_name = _name_for_xid(sub_ele_id, ele_path, schema_path_index, seg_ele_index, flat_schema_unique)
                    label_text = f'- {ele_name} ({sub_ele_id})'

                    rows.append({
                        'node-text': label_text,
                        'text-value': current_value,
                        'xml-path': ele_xml_path,
                    })
            
            elif child_data.tag == 'ele':
                ele_xml_path = f"{xml_path}/{child_id}"
                current_value = (child_data.text or '').strip()
                ele_name = _name_for_xid(child_id, new_path_ids, schema_path_index, seg_ele_index, flat_schema_unique)
                label_text = f'{ele_name} ({child_id})'

                rows.append({
                    'node-text': label_text,
                    'text-value': current_value,
                    'xml-path': ele_xml_path,
                })

    walk(top_data_loop, top_schema_node, base_path, f"{root_schema_xid}/ISA_LOOP")

    for i, r in enumerate(rows, start=1):
        r['sl'] = i
    return rows


# ---------- Component factory (DROP‑IN API) ----------
# This mirrors the shape of create_tree_editor() in edi_837_tree.py:
#   - Renders a self-contained UI fragment (card)
#   - Returns a callable load_claim_data(claim_id: str, xml_file: str)
#     which the parent app can call to inject the desired claim

def create_table_editor():
    """Creates the EDI 837 Table Editor component.

    Returns
    -------
    load_claim_data: callable
        Function taking (claim_id: str, xml_file: str) that loads the claim
        and populates the grid inside this component.
    """
    global grid
    global data_tree

    (hierarchical_schema,
     flat_schema_unique,
     schema_path_index,
     seg_ele_index,
     xid_collisions) = parse_schema_hierarchically(SCHEMA_FILE)

    if not (hierarchical_schema and flat_schema_unique is not None
            and schema_path_index and seg_ele_index is not None):
        ui.label('Could not load schema.').classes('text-negative')
        return lambda *_args, **_kwargs: None

    app.storage.user.setdefault('search_term', '')
    app.storage.user.setdefault('loaded_claim_id', '')
    app.storage.user.setdefault('xml_file_path', '')

    async def download_edi_file():
        """Generate and download the EDI file."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not claim_id or not xml_file:
            ui.notify('No claim loaded or file path is missing.', type='negative')
            return

        single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
        if not single_claim_xml_str:
            ui.notify(f"Failed to generate XML for claim '{claim_id}'.", type='negative')
            return

        output_dir = f'{os.path.dirname(xml_file)}/gen'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        xml_gen_path = os.path.join(output_dir, f"{claim_id}.xml")
        edi_file_path = os.path.join(output_dir, f"{claim_id}.edi")

        with open(xml_gen_path, 'w') as f:
            f.write(single_claim_xml_str)

        # Run the conversion command
        cmd = ['xmlx12', xml_gen_path, '--outputfile', edi_file_path]
        process = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Trigger the download
        ui.download(edi_file_path, f"{claim_id}.edi")

    async def save_changes():
        """Apply grid edits to both single-claim (in-memory) and the main XML file; save both into gen/."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not claim_id or not xml_file:
            ui.notify('No claim loaded or file path is missing.', type='negative')
            return
        if data_tree is None:
            ui.notify('No in-memory claim XML to update.', type='negative')
            return

        grid_data = grid["get_changes"]()

        _, single_updates = update_xml_from_grid(data_tree, grid_data, form_data)

        main_tree = ET.parse(xml_file)
        root = main_tree.getroot()

        def _find_claim_loop(root: ET.Element, claim_id: str) -> Optional[ET.Element]:
            for loop_b in root.findall(".//loop[@id='2000B']"):
                clm01 = loop_b.find(".//seg[@id='CLM']/ele[@id='CLM01']")
                if clm01 is not None and (clm01.text or '').strip() == (claim_id or '').strip():
                    return loop_b
            return None

        claim_loop = _find_claim_loop(root, claim_id)
        main_updates = 0

        if claim_loop is not None:
            main_updates = update_xml_2000B_from_grid(claim_loop, grid_data, form_data)

        outdir = Path(xml_file).parent / 'gen'
        outdir.mkdir(parents=True, exist_ok=True)

        claim_xml_path = outdir / f"{claim_id}.xml"
        data_tree.write(claim_xml_path, encoding='utf-8', xml_declaration=True)

        main_path = Path(xml_file)
        main_updated_path = Path(xml_file).parent / f"{main_path.stem}{main_path.suffix}"
        main_tree.write(main_updated_path, encoding='utf-8', xml_declaration=True)

        edited_by_path.clear()
        ui.notify(f"Saved {single_updates} field(s) in claim XML, {main_updates} in main XML → "
                f"{claim_xml_path.name}, {main_updated_path.name}", type='positive')

    def _open_settings_tree():
        """Open a modal containing a tree of the current XML and a field showing selected node path."""
        claim_id = app.storage.user.get('loaded_claim_id')
        xml_file = app.storage.user.get('xml_file_path')

        if not xml_file:
            ui.notify('No XML loaded yet. Select a claim first.', type='warning')
            return

        title = f'Claim {claim_id} • Tree View' if claim_id else f'Tree View'

        with ui.dialog() as dlg, ui.card().classes('w-[80vw] max-w-[1100px] h-[75vh] p-0'):
            # header
            with ui.row().classes('items-center justify-between w-full p-3'):
                ui.label(title).classes('text-lg font-semibold')
                ui.button(icon='close', on_click=dlg.close).props('flat round dense')

            ui.separator()

            # path field with copy button
            with ui.row().classes('w-full items-center gap-2 px-3 py-2'):
                path_input = ui.input('Selected node path').props('readonly').classes('w-full')
                ui.button(icon='content_copy').tooltip('Copy path')
                # wire a simple clipboard write (works in browser contexts)
                ui.run_javascript(
                    f"document.querySelector('#{path_input.id}').nextElementSibling.onclick = () => "
                    f"navigator.clipboard.writeText(document.getElementById('{path_input.id}').value)"
                )

            # tree area
            with ui.scroll_area().classes('w-full h-[calc(75vh-120px)] px-3 pb-3'):
                single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
                tree = xml_tree_gen(single_claim_xml_str, is_text=True)

            # when a node is selected, update the path input with the node's 'id' (which is the full path)
            def _on_select(e):
                selected = getattr(e, 'value', None)  # ValueChangeEventArguments.value
                if isinstance(selected, (list, tuple)):
                    selected = selected[0] if selected else ''
                filter_text = (str(selected) if selected is not None else '').replace('X12','837')
                filter_text = re.sub(r'\[\d+\]', '', filter_text)
                path_input.set_value(filter_text)
                grid["filter_value_changed"](filter_text)
                

            # prefer the helper if available; otherwise fall back to the raw Quasar event name
            try:
                tree.on_select(_on_select)
            except Exception:
                tree.on('update:selected', _on_select)

            # optional: expand/collapse helpers
            with ui.row().classes('gap-2 px-3 pb-3'):
                ui.button('Expand All', on_click=lambda: ui.run_javascript(
                    f"document.querySelectorAll('#{tree.id} .q-tree__node').forEach(n=>n.__vueParent?.setExpanded?.(true))"
                )).props('outline dense')
                ui.button('Collapse All', on_click=lambda: ui.run_javascript(
                    f"document.querySelectorAll('#{tree.id} .q-tree__node--parent').forEach(n=>n.__vueParent?.setExpanded?.(false))"
                )).props('outline dense')

        dlg.open()



    with ui.card().classes('w-full h-full'):
        with ui.row().classes('w-full gap-1 no-wrap'):
            ui.button(icon='download').on('click', download_edi_file)
            ui.button(icon='save').on('click', save_changes)
            ui.button(icon='print').on('click', createClaimPdf)
            ui.button(icon='settings').on('click', _open_settings_tree)
        grid_options = {
            'columnDefs': [
                {'headerName': 'EDI Node', 'field': 'node-text', 'flex': 5, 'sortable': False, 'filter': True, 'floatingFilter': True},
                {'headerName': 'Value', 'field': 'text-value', 'flex': 2, 'editable': True, 'sortable': False, 'filter': True, 'floatingFilter': True},
                # {'headerName': 'xml-path', 'field': 'xml-path', 'editable': True, 'sortable': True, 'filter': True, 'floatingFilter': True},
                {'headerName': 'xml-path', 'field': 'xml-path', 'hide': True, 'sortable': True, 'filter': True},
            ],
            'rowData': [],
            'animateRows': True,
            'stopEditingWhenCellsLoseFocus': True,
            'defaultColDef': {'resizable': True},
        }
        rows = []
        grid = make_xml_node_table(rows,form_data)

        status = ui.label('').classes('text-sm text-gray-600')

        # Tracks edits keyed by xml-path so we don’t need to fetch client state back
        edited_by_path: Dict[str, Any] = {}

        def _rebuild_rows_from_current_tree():
            if not data_tree:
                grid["change_dataset"]([],form_data)
                return 0
            
            root = data_tree.getroot()
            rows = build_table_rows_from_tree(
                root,
                hierarchical_schema,
                flat_schema_unique,
                schema_path_index,
                seg_ele_index,
            )

            # --- MODIFICATION START ---
            # Check for the existence of the specific REF segment (REF01='F8')
            # and add it only if it's missing.
            
            loop_2300 = root.find('.//loop[@id="2300"]')
            f8_ref_exists = False
            ref_segments = []

            if loop_2300 is not None:
                # Find all current REF segments to check them and to determine the next index
                ref_segments = loop_2300.findall("./seg[@id='REF']")
                
                for ref_seg in ref_segments:
                    ref01_ele = ref_seg.find("./ele[@id='REF01']")
                    if ref01_ele is not None and ref01_ele.text == 'F8':
                        f8_ref_exists = True
                        break  # Found it, no need to add it

            # If the REF segment with REF01='F8' was not found, add the rows for it.
            if not f8_ref_exists:
                # Calculate the next index for the new REF segment (e.g., if 1 exists, this will be 2)
                new_ref_index = len(ref_segments) + 1

                ref01 = {
                        'node-text': 'Reference Identification Qualifier (REF01)',
                        'text-value': 'F8',
                        'xml-path': f'837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/REF[{new_ref_index}]/REF01',
                        'sl': 10000
                }
                ref02 = {
                        'node-text': 'Reference Number (REF02)',
                        'text-value': '00',
                        'xml-path': f'837/ISA_LOOP/GS_LOOP/ST_LOOP/DETAIL/2000A/2000B/2300/REF[{new_ref_index}]/REF02',
                        'sl': 10001
                }

                rows.append(ref01)
                rows.append(ref02)
            # --- MODIFICATION END ---
            
            grid["change_dataset"](rows,form_data)

            return len(rows)

        def load_claim_data(claim_id: str, xml_file: str):
            """Loads a single claim into the component and refreshes the grid."""
            nonlocal status
            global data_tree
            if not claim_id or not xml_file:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text('No claim loaded.')
                return

            single_claim_xml_str = get_single_claim_xml(claim_id, xml_file)
            if not single_claim_xml_str:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text(f"Claim '{claim_id}' not found or parse failed.")
                ui.notify(f"Claim '{claim_id}' not found or parse failed.", type='negative')
                return

            try:
                root = ET.fromstring(single_claim_xml_str)
                data_tree = ET.ElementTree(root)
            except ET.ParseError as e:
                data_tree = None
                _rebuild_rows_from_current_tree()
                status.set_text(f'XML parse error: {e}')
                ui.notify(f'Error parsing XML: {e}', type='negative', multi_line=True)
                return

            count = _rebuild_rows_from_current_tree()
            app.storage.user['loaded_claim_id'] = claim_id
            app.storage.user['xml_file_path'] = xml_file
            status.set_text(f"Loaded claim {claim_id} • {count} elements")
            ui.notify(f"Loaded claim '{claim_id}'", type='positive')


        # initial empty state
        _rebuild_rows_from_current_tree()

    return load_claim_data

# Helper function to safely split dates
def _split_date(date_string):
    if not date_string or len(date_string) != 10 or date_string.count('/') != 2:
        return '', '', ''
    parts = date_string.split('/')
    return parts[0], parts[1], parts[2] # MM, DD, YYYY



def createClaimPdf():
    """
    Generates a filled PDF for the currently loaded claim. If the claim has more 
    than 10 service lines, it creates a multi-page document by renaming form 
    fields on each page with a unique prefix to prevent data conflicts.
    The generated PDF is saved in a 'pdf_gen' subdirectory within the claim's folder.
    """
    # 1. Get the current claim's context from the application storage
    claim_id = app.storage.user.get('loaded_claim_id')
    xml_file_path = app.storage.user.get('xml_file_path')

    if not claim_id or not xml_file_path:
        ui.notify('Cannot generate PDF: No claim is currently loaded.', type='warning')
        return

    try:
        # 2. Define all necessary file paths
        project_root = Path(__file__).resolve().parent.parent
        template_path = project_root / 'tools' / 'pdf_formats' / '837-d-ada_dental_claim-mod-f.pdf'
        
        output_dir = Path(xml_file_path).parent / 'pdf_gen'
        output_path = output_dir / f"{claim_id}.pdf"
        output_dir.mkdir(parents=True, exist_ok=True)

        # 3. Prepare a dictionary for data that is COMMON to all pages
        pdf_data_common = {}

        # --- Map all data EXCEPT service lines and totals ---
        # (This entire data mapping section is correct and unchanged)
        # Box 1: Type of Transaction
        trans_type = form_data.get('1_type_of_transaction', {})
        pdf_data_common['F1chkRequestForPredetPreauth'] = '/Yes' if trans_type.get('request_for_predetermination') else '/Off'
        pdf_data_common['F1chkStatementOfActualServices'] = '/Yes' if trans_type.get('statement_of_actual_services') else '/Off'
        pdf_data_common['F1chkEPSDTTitleXIX'] = '/Yes' if trans_type.get('epsdt_title_xix') else '/Off'
        # Box 2: Predetermination Number
        pdf_data_common['F2PredetPreAuthNumber'] = form_data.get('2_predetermination_number', '')
        # Box 3: Dental Benefit Plan Information
        pdf_data_common['F3CompanyPlanName'] = form_data.get('3_company_plan_name_address', '')
        pdf_data_common['F3aPayerID'] = form_data.get('3a_payer_id', '')
        # Box 4-11: Other Coverage Information
        other_cov = form_data.get('4_other_coverage', {})
        pdf_data_common['F4chkOtherCoverageDental'] = '/Yes' if other_cov.get('dental') else '/Off'
        pdf_data_common['F4chkOtherCoverageMedical'] = '/Yes' if other_cov.get('medical') else '/Off'
        pdf_data_common['F5NameOfPolicyHolder'] = form_data.get('5_other_insured_name', '')
        pdf_data_common['F6DateOFBirth'] = form_data.get('6_other_insured_dob', '')
        gender_7 = form_data.get('7_other_insured_gender', '')
        pdf_data_common['F7chkGenderMale'] = '/Yes' if gender_7 == 'M' else '/Off'
        pdf_data_common['F7chkGenderFemale'] = '/Yes' if gender_7 == 'F' else '/Off'
        pdf_data_common['F7chkGenderUnknown'] = '/Yes' if gender_7 == 'U' else '/Off'
        pdf_data_common['F8PolicyHolderID'] = form_data.get('8_other_insured_id', '')
        pdf_data_common['F9PlanGroupNumber'] = form_data.get('9_other_plan_group_number', '')
        rel_10 = form_data.get('10_patient_relationship_to_other_insured', '')
        pdf_data_common['F10chkPatientRelationshipSelf'] = '/Yes' if rel_10 == 'SELF' else '/Off'
        pdf_data_common['F10chkPatientRelationshipSpouse'] = '/Yes' if rel_10 == 'SPOUSE' else '/Off'
        pdf_data_common['F10chkPatientRelationshipDependent'] = '/Yes' if rel_10 == 'DEPENDENT' else '/Off'
        pdf_data_common['F10chkPatientRelationshipOther'] = '/Yes' if rel_10 == 'OTHER' else '/Off'
        pdf_data_common['F11OtherInsuranceCompanyDetails'] = form_data.get('11_other_insurance_company_name_address', '')
        pdf_data_common['F11aOtherPayerID'] = form_data.get('11a_other_payer_id', '')
        # Box 12-17: Policyholder/Subscriber Information
        pdf_data_common['F12PolicyHolderNameDetails'] = form_data.get('12_policyholder_name_address', '')
        pdf_data_common['F13DateOfBirth'] = form_data.get('13_policyholder_dob', '')
        gender_14 = form_data.get('14_policyholder_gender', '')
        pdf_data_common['F14chkGenderMale'] = '/Yes' if gender_14 == 'M' else '/Off'
        pdf_data_common['F14chkGenderFemale'] = '/Yes' if gender_14 == 'F' else '/Off'
        pdf_data_common['F14chkGenderUnknown'] = '/Yes' if gender_14 == 'U' else '/Off'
        pdf_data_common['F15PolicyHolderID'] = form_data.get('15_policyholder_id', '')
        pdf_data_common['F16PlanGroupNumber'] = form_data.get('16_policyholder_plan_group_number', '')
        pdf_data_common['F17EmployerName'] = form_data.get('17_employer_name', '')
        # Box 18-23: Patient Information
        rel_18 = form_data.get('18_patient_relationship_to_policyholder', '')
        pdf_data_common['F18chkRelationshipToPolicyHolderSelf'] = '/Yes' if rel_18 == 'SELF' else '/Off'
        pdf_data_common['F18chkRelationshipToPolicyHolderSpouse'] = '/Yes' if rel_18 == 'SPOUSE' else '/Off'
        pdf_data_common['F18chkRelationshipToPolicyHolderDependentChild'] = '/Yes' if rel_18 == 'DEPENDENT CHILD' else '/Off'
        pdf_data_common['F18chkRelationshipToPolicyHolderOther'] = '/Yes' if rel_18 == 'OTHER' else '/Off'
        pdf_data_common['F20PatientInformationNameDetails'] = form_data.get('20_patient_name_address', '')
        pdf_data_common['F21DateOfBirth'] = form_data.get('21_patient_dob', '')
        gender_22 = form_data.get('22_patient_gender', '')
        pdf_data_common['F22chkGenderMale'] = '/Yes' if gender_22 == 'M' else '/Off'
        pdf_data_common['F22chkGenderFemale'] = '/Yes' if gender_22 == 'F' else '/Off'
        pdf_data_common['F22chkGenderUnknown'] = '/Yes' if gender_22 == 'U' else '/Off'
        pdf_data_common['F23PatientIDAccountNumber'] = form_data.get('23_patient_id', '')
        # Box 33: Missing Teeth Information
        missing_teeth = form_data.get('33_missing_teeth_information', {})
        for i in range(1, 33):
            pdf_data_common[f'F33MissingTooth{i}'] = '/Yes' if missing_teeth.get(str(i)) else '/Off'
        # Box 34: Diagnosis Codes
        pdf_data_common['F34DiagnosisCodeListQual1'] = form_data.get('34_diagnosis_code_list_qualifier', '')
        diag_codes = form_data.get('34a_diagnosis_codes', {})
        pdf_data_common['F34aDiagnosisCodeA'] = diag_codes.get('A', '')
        pdf_data_common['F34aDiagnosisCodeB'] = diag_codes.get('B', '')
        pdf_data_common['F34aDiagnosisCodeC'] = diag_codes.get('C', '')
        pdf_data_common['F34aDiagnosisCodeD'] = diag_codes.get('D', '')
        # Box 36 & 37: Authorizations
        pdf_data_common['F36PatientGuardianSignature'] = form_data.get('36_patient_guardian_signature', '')
        pdf_data_common['F36Date'] = form_data.get('36_patient_guardian_signature_date', '')
        pdf_data_common['F37SubscriberSignature'] = form_data.get('37_subscriber_signature', '')
        pdf_data_common['F37Date'] = form_data.get('37_subscriber_signature_date', '')
        # Box 38-47: Ancillary Claim/Treatment Information
        pdf_data_common['F38PlaceOfTreatment'] = form_data.get('38_place_of_treatment', '')
        pdf_data_common['F39EnclosuresYN'] = form_data.get('39_enclosures', '')
        pdf_data_common['F39aDateOfLastSRP'] = form_data.get('39a_date_last_srp', '')
        ortho = form_data.get('40_is_treatment_for_orthodontics', 'N')
        pdf_data_common['F40chkTreatmentForOrthodonticsYes'] = '/Yes' if ortho == 'Y' else '/Off'
        pdf_data_common['F40chkTreatmentForOrthodonticsNo'] = '/Yes' if ortho != 'Y' else '/Off'
        pdf_data_common['F41DateAppliancePlaced'] = form_data.get('41_date_appliance_placed', '')
        pdf_data_common['F42MonthsOfTreatment'] = form_data.get('42_months_of_treatment', '')
        prosthesis = form_data.get('43_replacement_of_prosthesis', 'N')
        pdf_data_common['F43chkReplacementOfProsthesisYes'] = '/Yes' if prosthesis == 'Y' else '/Off'
        pdf_data_common['F43chkReplacementOfProsthesisNo'] = '/Yes' if prosthesis != 'Y' else '/Off'
        pdf_data_common['F44DateOfPriorPlacement'] = form_data.get('44_date_of_prior_placement', '')
        treatment_from = form_data.get('45_treatment_resulting_from', {})
        pdf_data_common['F45chkTreatmentFromAutoAccident'] = '/Yes' if treatment_from.get('auto_accident') else '/Off'
        pdf_data_common['F45chkTreatmentFromOccupation'] = '/Yes' if treatment_from.get('employment') else '/Off'
        pdf_data_common['F45chkTreatmentFromOtherAccident'] = '/Yes' if treatment_from.get('other_accident') else '/Off'
        pdf_data_common['F46DateOfAccident'] = form_data.get('46_date_of_accident', '')
        pdf_data_common['F47AutoAccidentState'] = form_data.get('47_auto_accident_state', '')
        # Box 48-52a: Billing Dentist or Dental Entity
        pdf_data_common['F48BillingDentistDetails'] = form_data.get('48_billing_dentist_name_address', '')
        pdf_data_common['F49BillingDentistNPI'] = form_data.get('49_billing_dentist_npi', '')
        pdf_data_common['F50BillingDentistLicenseNumber'] = form_data.get('50_billing_dentist_license_number', '')
        pdf_data_common['F51BillingDentistSSNorTIN'] = form_data.get('51_billing_dentist_ssn_or_tin', '')
        pdf_data_common['F52PhoneNumber'] = form_data.get('52_billing_dentist_phone', '')
        pdf_data_common['F52aAdditionalProviderID'] = form_data.get('52a_billing_dentist_additional_provider_id', '')
        # Box 53-58: Treating Dentist and Treatment Location Information
        pdf_data_common['F53TreatingDentistSignature'] = form_data.get('53_treating_dentist_signature', '')
        pdf_data_common['F53Date'] = form_data.get('53_treating_dentist_signature_date', '')
        pdf_data_common['F53aChkLocumTenensTreatingDentist'] = '/Yes' if form_data.get('53a_locum_tenens_treating_dentist') else '/Off'
        pdf_data_common['F54TreatingDentistNPI'] = form_data.get('54_treating_dentist_npi', '')
        pdf_data_common['F55LicenseNumber'] = form_data.get('55_treating_dentist_license_number', '')
        pdf_data_common['F56aProviderSpecialityCode'] = form_data.get('56_provider_specialty_code', '')
        pdf_data_common['F56TreatingDentistAddressDetails'] = form_data.get('56a_treatment_location_address', '')
        pdf_data_common['F57PhoneNumber'] = form_data.get('57_treatment_location_phone', '')
        pdf_data_common['F58AdditionalProviderID'] = form_data.get('58_treatment_location_additional_provider_id', '')

        # 4. Create a list of filled, single-page PDFs in memory
        pages_in_memory = []
        service_lines = form_data.get('service_lines', [])
        if not service_lines:
            service_lines = [{}] 

        start_index = 0
        while start_index < len(service_lines):
            chunk = service_lines[start_index : start_index + 10]
            page_data = pdf_data_common.copy()
            
            # Create a temporary writer for this page
            reader = PdfReader(template_path)
            writer_for_page = PdfWriter()
            writer_for_page.append(reader)

            # Populate service lines for the current chunk
            for i, line in enumerate(chunk):
                line_num = i + 1
                page_data[f'F24L{line_num}ProcedureDate'] = line.get('procedure_date', '')
                page_data[f'F25L{line_num}AreaOfOralCavity'] = line.get('oral_cavity_area', '')
                page_data[f'F26L{line_num}ToothSystem'] = line.get('tooth_system', '')
                page_data[f'F27L{line_num}ToothNumbersOrLetters'] = line.get('tooth_number', '')
                page_data[f'F28L{line_num}ToothSurface'] = line.get('tooth_surface', '')
                page_data[f'F29L{line_num}ProcedureCode'] = line.get('procedure_code', '')
                page_data[f'F29aL{line_num}DiagPointer'] = line.get('diag_pointer', '')
                page_data[f'F29bL{line_num}Qty'] = str(line.get('quantity', ''))
                page_data[f'F30L{line_num}Description'] = line.get('description', '')
                page_data[f'F31L{line_num}Fee'] = str(line.get('fee', ''))

            # Add totals only on the last page
            if (start_index + 10) >= len(service_lines):
                page_data['F31aOtherFees'] = form_data.get('31a_other_fee', '')
                page_data['F32TotalFee'] = form_data.get('32_total_fee', '')
            
            # Update fields for this specific page
            writer_for_page.update_page_form_field_values(
                writer_for_page.pages[0], fields=page_data
            )
            
            # Write the filled page to an in-memory stream and add to our list
            in_memory_stream = io.BytesIO()
            writer_for_page.write(in_memory_stream)
            in_memory_stream.seek(0)
            pages_in_memory.append(in_memory_stream)

            start_index += 10

        # 5. Merge the in-memory pages, using add_form_topname to prevent field conflicts
        final_writer = PdfWriter()
        for i, page_stream in enumerate(pages_in_memory):
            reader_for_page = PdfReader(page_stream)
            
            # This is the critical step: Give each page's form a unique prefix
            reader_for_page.add_form_topname(f"p{i}")
            
            final_writer.append(reader_for_page)
            
        # Write the final, merged PDF to the output file
        with open(output_path, "wb") as output_file:
            final_writer.write(output_file)
            
        ui.notify(f"Successfully generated PDF ({len(final_writer.pages)} page(s)): {output_path.name}", type='positive')
        ui.download(str(output_path))

    except FileNotFoundError:
        ui.notify(f"Error: PDF template not found at {template_path}", type='negative')
    except Exception as e:
        ui.notify(f"An unexpected error occurred while creating the PDF: {e}", type='negative', multi_line=True)



# In tools/edi_table_editor_dental.py

# (Keep your existing _generate_writer_for_claim function as it is. It's a perfect helper.)
def _generate_writer_for_claim(claim_object: dict, template_path: str) -> PdfWriter:
    """
    A helper function that takes a single claim object and generates a 
    PdfWriter containing all its filled pages. It renames form fields on each
    page to prevent data conflicts within a single multi-page claim.
    
    Args:
        claim_object: The dictionary for a single claim.
        template_path: The path to the PDF template file.
        
    Returns:
        A PdfWriter object with the filled and prefixed pages for the claim.
    """
    writer = PdfWriter()
    
    # 1. Map all common data from the claim object
    pdf_data_common = {}
    subscriber = claim_object.get("subscriber", {})
    primary_payer_info = claim_object.get("primary_payer_info", {})
    other_insured = claim_object.get("other_insured", {})
    patient = claim_object.get("patient", subscriber)
    billing_provider = claim_object.get("billing_provider", {})
    claim_info = claim_object.get("claim_info", {})

    # --- Start Data Mapping (This section is correct) ---
    trans_type = {'request_for_predetermination': claim_info.get("req_for_predet_preauth",False),
                  'statement_of_actual_services': claim_info.get("stmt_of_actual_service",False),
                  'epsdt_title_xix': claim_info.get("epsdt_title_xix",False)}
    pdf_data_common['F1chkRequestForPredetPreauth'] = '/Yes' if trans_type.get('request_for_predetermination') else '/Off'
    pdf_data_common['F1chkStatementOfActualServices'] = '/Yes' if trans_type.get('statement_of_actual_services') else '/Off'
    pdf_data_common['F1chkEPSDTTitleXIX'] = '/Yes' if trans_type.get('epsdt_title_xix') else '/Off'
    pdf_data_common['F2PredetPreAuthNumber'] = claim_info.get("predet_preauth_number","")
    pdf_data_common['F3CompanyPlanName'] = f'{primary_payer_info.get("name", "")}\n{primary_payer_info.get("address", "")}\n{primary_payer_info.get("city", "")}, {primary_payer_info.get("state", "")} {primary_payer_info.get("zipcode", "")}'
    pdf_data_common['F3aPayerID'] = primary_payer_info.get("payer_id","")
    other_cov = {'dental': claim_info.get("other_coverage_dental_flag",False),
                 'medical': claim_info.get("other_coverage_medical_flag",False)}
    pdf_data_common['F4chkOtherCoverageDental'] = '/Yes' if other_cov.get('dental') else '/Off'
    pdf_data_common['F4chkOtherCoverageMedical'] = '/Yes' if other_cov.get('medical') else '/Off'
    pdf_data_common['F5NameOfPolicyHolder'] = f'{other_insured.get("last_name","")} {other_insured.get("first_name","")} {other_insured.get("middle_name","")} {other_insured.get("suffix","")}'
    pdf_data_common['F6DateOFBirth'] = ""
    gender_7 = ""
    pdf_data_common['F7chkGenderMale'] = '/Yes' if gender_7 == 'M' else '/Off'
    pdf_data_common['F7chkGenderFemale'] = '/Yes' if gender_7 == 'F' else '/Off'
    pdf_data_common['F7chkGenderUnknown'] = '/Yes' if gender_7 == 'U' else '/Off'
    pdf_data_common['F8PolicyHolderID'] = other_insured.get("policy_sub_id","")
    pdf_data_common['F9PlanGroupNumber'] = other_insured.get("other_sub_plan_grp_number","")
    rel_10 = other_insured.get('other_plan_relation', '')
    pdf_data_common['F10chkPatientRelationshipSelf'] = '/Yes' if rel_10 == 'SELF' else '/Off'
    pdf_data_common['F10chkPatientRelationshipSpouse'] = '/Yes' if rel_10 == 'SPOUSE' else '/Off'
    pdf_data_common['F10chkPatientRelationshipDependent'] = '/Yes' if rel_10 == 'DEPENDENT' else '/Off'
    pdf_data_common['F10chkPatientRelationshipOther'] = '/Yes' if rel_10 == 'OTHER' else '/Off'
    pdf_data_common['F11OtherInsuranceCompanyDetails'] = f'{other_insured.get("other_payer_name","")}\n{other_insured.get("other_payer_address","")}\n{other_insured.get("other_payer_city","")}, {other_insured.get("other_payer_state","")} {other_insured.get("other_payer_zipcode","")}'
    pdf_data_common['F11aOtherPayerID'] = other_insured.get("other_payer_id","")
    pdf_data_common['F12PolicyHolderNameDetails'] = f'{subscriber.get("first_name", "")} {subscriber.get("last_name", "")}\n{subscriber.get("address", "")}\n{subscriber.get("city", "")}, {subscriber.get("state", "")} {subscriber.get("zip", "")}'
    pdf_data_common['F13DateOfBirth'] = subscriber.get("dob", "")
    gender_14 = subscriber.get('gender', '')
    pdf_data_common['F14chkGenderMale'] = '/Yes' if gender_14 == 'M' else '/Off'
    pdf_data_common['F14chkGenderFemale'] = '/Yes' if gender_14 == 'F' else '/Off'
    pdf_data_common['F14chkGenderUnknown'] = '/Yes' if gender_14 == 'U' else '/Off'
    pdf_data_common['F15PolicyHolderID'] = subscriber.get("subscriber_id", "")
    pdf_data_common['F16PlanGroupNumber'] = subscriber.get("sub_group_feca_num", "")
    pdf_data_common['F17EmployerName'] = ""
    rel_18 = subscriber.get('relationship', '')
    pdf_data_common['F18chkRelationshipToPolicyHolderSelf'] = '/Yes' if rel_18 == 'SELF' else '/Off'
    pdf_data_common['F18chkRelationshipToPolicyHolderSpouse'] = '/Yes' if rel_18 == 'SPOUSE' else '/Off'
    pdf_data_common['F18chkRelationshipToPolicyHolderDependentChild'] = '/Yes' if rel_18 == 'DEPENDENT CHILD' else '/Off'
    pdf_data_common['F18chkRelationshipToPolicyHolderOther'] = '/Yes' if rel_18 == 'OTHER' else '/Off'
    pdf_data_common['F20PatientInformationNameDetails'] = f'{patient.get("first_name", "")} {patient.get("last_name", "")}\n{patient.get("address", "")}\n{patient.get("city", "")}, {patient.get("state", "")} {patient.get("zip", "")}'
    pdf_data_common['F21DateOfBirth'] = patient.get("dob", "")
    gender_22 = patient.get('gender', '')
    pdf_data_common['F22chkGenderMale'] = '/Yes' if gender_22 == 'M' else '/Off'
    pdf_data_common['F22chkGenderFemale'] = '/Yes' if gender_22 == 'F' else '/Off'
    pdf_data_common['F22chkGenderUnknown'] = '/Yes' if gender_22 == 'U' else '/Off'
    pdf_data_common['F23PatientIDAccountNumber'] = claim_info.get('claim_control_number')
    missing_teeth_info = {str(i): (str(i) in claim_info.get("missing_teeth", [])) for i in range(1, 33)}
    for i in range(1, 33):
        pdf_data_common[f'F33MissingTooth{i}'] = '/Yes' if missing_teeth_info.get(str(i)) else '/Off'
    pdf_data_common['F34DiagnosisCodeListQual1'] = f'{claim_info.get("diagnoses_q_1","")}{"|" if claim_info.get("diagnoses_q_1","") != "" else ""}{claim_info.get("diagnoses_q_2","")}'
    diagnoses_codes = {chr(65 + i): dx.get("code", "") for i, dx in enumerate(claim_object.get("diagnoses", [])[:4])}
    pdf_data_common['F34aDiagnosisCodeA'] = diagnoses_codes.get('A', '')
    pdf_data_common['F34aDiagnosisCodeB'] = diagnoses_codes.get('B', '')
    pdf_data_common['F34aDiagnosisCodeC'] = diagnoses_codes.get('C', '')
    pdf_data_common['F34aDiagnosisCodeD'] = diagnoses_codes.get('D', '')
    pdf_data_common['F36PatientGuardianSignature'] = "Signature on File" if claim_info.get("patient_sign",False) else "Unavailable"
    pdf_data_common['F36Date'] = claim_info.get("claim_service_date", "")
    pdf_data_common['F37SubscriberSignature'] = "Signature on File" if claim_info.get("subscriber_sign",False) else "Unavailable"
    pdf_data_common['F37Date'] = claim_info.get("claim_service_date", "")
    pdf_data_common['F38PlaceOfTreatment'] = claim_info.get("place_of_service_code", "")
    pdf_data_common['F39EnclosuresYN'] = "N"
    pdf_data_common['F39aDateOfLastSRP'] = ""
    ortho = claim_info.get('ortho_treatment', False)
    pdf_data_common['F40chkTreatmentForOrthodonticsYes'] = '/Yes' if ortho else '/Off'
    pdf_data_common['F40chkTreatmentForOrthodonticsNo'] = '/Yes' if not ortho else '/Off'
    pdf_data_common['F41DateAppliancePlaced'] = claim_info.get("ortho_appliance_pl_date", "")
    pdf_data_common['F42MonthsOfTreatment'] = claim_info.get("months_of_treatment", "")
    prosthesis = claim_info.get('prosthesis_replacement', False)
    pdf_data_common['F43chkReplacementOfProsthesisYes'] = '/Yes' if prosthesis else '/Off'
    pdf_data_common['F43chkReplacementOfProsthesisNo'] = '/Yes' if not prosthesis else '/Off'
    pdf_data_common['F44DateOfPriorPlacement'] = ""
    treatment_from = {'auto_accident': claim_info.get('clm_related_causes_02') == 'AA',
                      'employment': claim_info.get('clm_related_causes_01') == 'EM',
                      'other_accident': claim_info.get('clm_related_causes_02') == 'OA'}
    pdf_data_common['F45chkTreatmentFromAutoAccident'] = '/Yes' if treatment_from.get('auto_accident') else '/Off'
    pdf_data_common['F45chkTreatmentFromOccupation'] = '/Yes' if treatment_from.get('employment') else '/Off'
    pdf_data_common['F45chkTreatmentFromOtherAccident'] = '/Yes' if treatment_from.get('other_accident') else '/Off'
    pdf_data_common['F46DateOfAccident'] = ""
    pdf_data_common['F47AutoAccidentState'] = ""
    pdf_data_common['F48BillingDentistDetails'] = f'{billing_provider.get("name", "")}\n{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
    pdf_data_common['F49BillingDentistNPI'] = billing_provider.get("npi", "")
    pdf_data_common['F50BillingDentistLicenseNumber'] = ""
    pdf_data_common['F51BillingDentistSSNorTIN'] = billing_provider.get("tax_id", "")
    pdf_data_common['F52PhoneNumber'] = billing_provider.get("phone", "")
    pdf_data_common['F52aAdditionalProviderID'] = ""
    pdf_data_common['F53TreatingDentistSignature'] = "SIGNATURE ON FILE"
    pdf_data_common['F53Date'] = claim_info.get("claim_service_date", "")
    pdf_data_common['F53aChkLocumTenensTreatingDentist'] = '/Off'
    pdf_data_common['F54TreatingDentistNPI'] = billing_provider.get("npi", "")
    pdf_data_common['F55LicenseNumber'] = ""
    pdf_data_common['F56aProviderSpecialityCode'] = ""
    pdf_data_common['F56TreatingDentistAddressDetails'] = f'{billing_provider.get("address", "")}\n{billing_provider.get("city", "")}, {billing_provider.get("state", "")} {billing_provider.get("zip", "")}'
    pdf_data_common['F57PhoneNumber'] = billing_provider.get("phone", "")
    pdf_data_common['F58AdditionalProviderID'] = ""
    # --- End Data Mapping ---

    # 2. Process service lines in chunks to create pages
    service_lines = claim_object.get('service_lines', [])
    if not service_lines:
        service_lines = [{}] 

    start_index = 0
    page_index = 0
    while start_index < len(service_lines):
        chunk = service_lines[start_index : start_index + 10]
        page_data = pdf_data_common.copy()
        
        temp_writer = PdfWriter()
        reader = PdfReader(template_path)
        temp_writer.append(reader)

        for i, line in enumerate(chunk):
            line_num = i + 1
            page_data[f'F24L{line_num}ProcedureDate'] = line.get('date_of_service', '')
            page_data[f'F25L{line_num}AreaOfOralCavity'] = line.get('area_of_oral_cavity', '')
            page_data[f'F26L{line_num}ToothSystem'] = line.get('tooth_system', '')
            page_data[f'F27L{line_num}ToothNumbersOrLetters'] = line.get('tooth_number', '')
            page_data[f'F28L{line_num}ToothSurface'] = line.get('tooth_surface', '')
            page_data[f'F29L{line_num}ProcedureCode'] = line.get('procedure_code', '')
            page_data[f'F29aL{line_num}DiagPointer'] = " ".join(map(str, line.get("diagnosis_pointers", [])))
            page_data[f'F29bL{line_num}Qty'] = str(line.get('quantity', ''))
            page_data[f'F30L{line_num}Description'] = ""
            page_data[f'F31L{line_num}Fee'] = str(line.get('line_item_charge_amount', ''))

        if (start_index + 10) >= len(service_lines):
            page_data['F31aOtherFees'] = ""
            page_data['F32TotalFee'] = claim_info.get("total_claim_charge_amount", "")

        temp_writer.update_page_form_field_values(temp_writer.pages[0], fields=page_data)

        in_memory_stream = io.BytesIO()
        temp_writer.write(in_memory_stream)
        in_memory_stream.seek(0)
        
        reader_for_merging = PdfReader(in_memory_stream)
        reader_for_merging.add_form_topname(f"p{page_index}")
        
        writer.append(reader_for_merging)

        start_index += 10
        page_index += 1
        
    return writer


# NEW: Synchronous "worker" function for heavy lifting
def _run_pdf_generation_task(all_claims_data: dict, xml_file_name: str, template_path: str) -> dict:
    """
    This is a synchronous function designed to be run in a separate thread.
    It performs the heavy CPU-bound work of generating the combined PDF.
    It does not interact with the UI directly.
    """
    try:
        master_merger = PdfWriter()

        for i, claim_object in enumerate(all_claims_data['claims']):
            claim_id = claim_object.get("claim_info", {}).get("claim_control_number", f"claim{i}")
            
            # Use the helper to get a writer for this single claim
            writer_for_this_claim = _generate_writer_for_claim(claim_object, template_path)
            
            # Write this claim's pages to an in-memory stream
            claim_stream = io.BytesIO()
            writer_for_this_claim.write(claim_stream)
            claim_stream.seek(0)
            
            # Read the stream back and apply the unique claim-level prefix
            reader_for_merging = PdfReader(claim_stream)
            reader_for_merging.add_form_topname(f"claim_{claim_id}")
            
            # Append the prefixed pages to the master merger
            master_merger.append(reader_for_merging)

        # Define output paths
        project_root = Path(__file__).resolve().parent.parent
        xml_stem = Path(xml_file_name).stem
        output_dir = project_root / 'claims_upload' / xml_stem / 'pdf_gen'
        output_dir.mkdir(parents=True, exist_ok=True)
        output_filename = f"{xml_stem}_all_claims.pdf"
        output_path = output_dir / output_filename

        # Write the final file
        with open(output_path, "wb") as f:
            master_merger.write(f)

        # Return a dictionary with the results for the UI
        return {
            "success": True,
            "output_path": str(output_path),
            "output_filename": output_filename,
            "claim_count": len(all_claims_data['claims']),
            "page_count": len(master_merger.pages)
        }
    except Exception as e:
        # Return an error message if anything goes wrong
        return {"success": False, "error": str(e)}

# MODIFIED: The UI-facing function is now async
async def createCombinedPdfForAllClaims(all_claims_data: dict, xml_file_name: str):
    """
    Asynchronously generates a single, combined PDF file for all claims.
    This function manages the UI notifications and runs the blocking PDF
    generation task in a background thread to keep the UI responsive.
    """
    if not all_claims_data or not all_claims_data.get('claims'):
        ui.notify("No claims data available to generate PDF.", type='warning')
        return

    # Let the user know the process has started
    notification = ui.notification('Starting PDF generation for all claims... This may take a moment.', spinner=True, timeout=None)
    
    try:
        project_root = Path(__file__).resolve().parent.parent
        template_path = str(project_root / 'tools' / 'pdf_formats' / '837-d-ada_dental_claim-mod-f.pdf')
        
        # --- THIS IS THE CORRECTED LINE ---
        # Run the synchronous worker function in a background thread
        # and await its result without blocking the UI.
        result = await run.cpu_bound(
            _run_pdf_generation_task,
            all_claims_data,
            xml_file_name,
            template_path
        )
        # ------------------------------------

        notification.dismiss() # Close the "processing" notification

        if result["success"]:
            msg = f"Successfully generated '{result['output_filename']}' ({result['claim_count']} claims, {result['page_count']} pages)"
            ui.notify(msg, type='positive')
            ui.download(result['output_path'])
        else:
            ui.notify(f"An error occurred: {result['error']}", type='negative', multi_line=True)

    except Exception as e:
        notification.dismiss()
        ui.notify(f"An unexpected error occurred while setting up the PDF task: {e}", type='negative', multi_line=True)

def make_xml_node_table(rows: List[Dict[str, str]], form_data: dict[str, str]):
    """Render a simple 3-column table using ui.row and ui.column instead of ui.table."""
    global search_field
    current_field = None
    computed_rows = copy.deepcopy(rows)
    rows_workbench = copy.deepcopy(rows)
    # headers = ["node-text", "text-value","xml-path"]
    headers = ["node-text", "text-value"]
    input_registry: Dict[str, ui.input] = {}

    with ui.row().classes('gap-1 border no-wrap').style('width: 500px;'):
        clear_button = ui.button(icon='refresh').on_click(lambda: filter_value_changed('')).props('dense')
        filter_input = ui.input('').props('flat dense outline clearable').classes('w-full').style('height: 36px;')
        search_field = filter_input

    @ui.refreshable
    def render_table():
        nonlocal current_field
        input_registry.clear()
        with ui.element('div').style(
        'max-height:600px; overflow-y:auto; box-sizing:border-box;'
        'padding:0; margin:0;'
        ):
            with ui.column().style('min-width:500px').classes('gap-0 border w-full'):
                with ui.row().classes('gap-0 w-full border no-wrap'):
                    for header in headers:
                        with ui.column().classes('border w-2/3' if header == 'node-text' else 'border w-1/3'):
                            ui.input('EDI Node' if header == 'node-text' else 'Value').classes('w-full').props('flat dense outline readonly')
                
                for row in computed_rows:
                    with ui.row().classes('gap-0 w-full border no-wrap'):
                        for key in headers:
                            value = row.get(key, "")
                            with ui.column().classes('border w-2/3' if key == 'node-text' else 'border w-1/3'):
                                if key == "text-value":
                                    temp_input = ui.input('').props('flat dense outline').style('height: 36px;').classes('w-full')
                                    temp_path = row.get('xml-path',None)
                                    temp_input.value = get_text_value(temp_path)
                                    input_registry[temp_path] = temp_input

                                    temp_input.on_value_change(lambda e, p=temp_path: update_text_value(p,e.value))
                                    if temp_path is not None:
                                        tmp_key = get_key_by_ref(form_data,temp_path)
                                        # print(f't_key : {tmp_key} | path: {temp_path} | c_field: {current_field}')
                                        if tmp_key is not None:
                                            if current_field is not None:
                                                if tmp_key == current_field:
                                                    temp_input.bind_value(form_data,current_field)
                                                else:
                                                    temp_input.bind_value(form_data,current_field)
                                            else:
                                                temp_input.bind_value(form_data,tmp_key)
                                        elif current_field is not None:
                                            temp_input.bind_value(form_data,current_field)

                                        current_field = None
                                else:
                                    temp_input = ui.input('').props('flat dense outline readonly').style('height: 36px;').classes('w-full')
                                    temp_input.value = value

    def change_dataset(new_rows: List[Dict[str, str]], form_data: dict[str, str]):
        nonlocal rows, rows_workbench, computed_rows

        rows = copy.deepcopy(new_rows)
        rows_workbench = copy.deepcopy(new_rows)
        computed_rows = copy.deepcopy(new_rows)
        render_table.refresh()

    def get_changes()->List[Dict[str, str]]:
        changes: List[Dict[str, str]] = []
        for orig_row in rows:
            if get_text_value(orig_row["xml-path"]) != orig_row["text-value"]:
                changed_row = {"node-text": orig_row["node-text"], "text-value": get_text_value(orig_row["xml-path"]), "xml-path": orig_row["xml-path"]}
                changes.append(changed_row)

        return changes

    def get_key_by_ref(form_data, ref_value):
        for key, value in form_data.items():
            if key is not None:
                if key.endswith("_filter") and value == ref_value:
                    return key[:-7]
        return None


    def filter_rows(rows: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
        """
        Filters rows based on a simple text query or a structured conditional query,
        correctly handling indexed paths and sibling relationships.
        """
        if query is None or len(str(query).strip()) < 3:
            return rows

        q = str(query).strip()
        
        # Regex to parse a conditional query like: TARGET_PATH(CONDITION_ELEMENT=VALUE)
        # e.g., .../REF/REF02(REF01=F8)
        m = re.match(
            r'^\s*([a-zA-Z0-9_/\[\]-]+)\s*\(\s*([a-zA-Z0-9_-]+)\s*=\s*([^)]+?)\s*\)\s*$',
            q
        )

        # --- Case 1: Simple text search (no conditional parenthesis) ---
        if not m:
            ql = q.lower()
            return [
                row for row in rows
                if any(ql in str(value).lower() for value in row.values())
            ]

        # --- Case 2: Structured conditional search ---
        target_expr, cond_element_id, cond_value = m.groups()
        cond_value = cond_value.strip()

        def strip_indices(path: str) -> str:
            return re.sub(r'\[\d+\]', '', path)

        # 1. Group all elements by their immediate parent's path. This creates a
        #    structure that understands sibling relationships.
        grouped_by_parent: Dict[str, Dict[str, str]] = {}
        for row in rows:
            path = row.get('xml-path', '')
            if '/' not in path:
                continue
            
            parts = path.split('/')
            parent_path = '/'.join(parts[:-1])
            element_id = parts[-1]
            element_value = row.get('text-value', '')
            
            grouped_by_parent.setdefault(parent_path, {})[element_id] = element_value

        # 2. Identify the target element and its parent path from the query.
        target_element_id = target_expr.split('/')[-1]
        # This is the crucial part: we use the TARGET's parent path as our context.
        stripped_target_parent_path = strip_indices('/'.join(target_expr.split('/')[:-1]))

        # 3. Find the exact paths of the target rows that satisfy the condition.
        target_paths = set()
        for parent_path, children in grouped_by_parent.items():
            # Condition 1: Check if this group's parent path matches the target's parent path.
            if strip_indices(parent_path) == stripped_target_parent_path:
                # Condition 2: Check if the conditional element exists in this specific
                # sibling group and has the correct value.
                if children.get(cond_element_id) == cond_value:
                    # If both conditions are true, this is a valid group.
                    # Now, find the target element within this same valid group.
                    if target_element_id in children:
                        full_target_path = f"{parent_path}/{target_element_id}"
                        target_paths.add(full_target_path)
        
        # 4. Return only the original rows whose full path is in our set of valid targets.
        return [row for row in rows if row.get('xml-path') in target_paths]

    def filter_value_changed(value, field = None):
        nonlocal current_field
        if filter_input.value != value:
            filter_input.value = value
        nonlocal computed_rows
        computed_rows = filter_rows(rows, value)

        if field is not None:
            current_field = field
        else:
            current_field = None
        render_table.refresh()

    def update_text_value(xml_path: str, new_value: str):
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                row["text-value"] = new_value
                break

    def get_text_value(xml_path: str)->str:
        for row in rows_workbench:
            if row.get("xml-path") == xml_path:
                return row["text-value"]
        return ""

    filter_input.on_value_change(lambda e: filter_value_changed(e.value))
    render_table()

    return {
        "filter_value_changed": filter_value_changed,
        "render_table": render_table,
        "get_changes": get_changes,
        "change_dataset": change_dataset
    }
