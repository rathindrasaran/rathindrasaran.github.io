import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Any, List, Optional

def getFieldData(node: ET.Element, path: str) -> Optional[str]:
    """
    Traverses an XML node based on a path string and returns the data.

    Args:
        node: The starting xml.etree.ElementTree.Element node.
        path: A string representing the traversal path, with segments separated by '|'.
              The last segment can include a condition in the format 'TARGET[KEY=VALUE]'.

    Returns:
        A string containing the data if found, otherwise None.
    """
    path_parts = path.split('|')
    current_node = node

    # Traverse through the path parts that are loops (all but the last part)
    for part in path_parts[:-1]:
        if current_node is None:
            return None
        current_node = current_node.find(f".//loop[@id='{part}']")

    if current_node is None:
        return None

    # Handle the last part of the path, which specifies the target data
    last_part = path_parts[-1]

    if '[' in last_part and last_part.endswith(']'):
        # This part has a condition, e.g., 'PER04[PER03=TE]'
        main_part, condition = last_part[:-1].split('[')
        condition_key, condition_value = condition.split('=')
        target_element_id = main_part
        # Determine the segment name by removing numbers (e.g., 'PER' from 'PER01')
        segment_name = condition_key[:-2]

        # Find all segments matching the name and check for the condition
        for seg in current_node.findall(f".//seg[@id='{segment_name}']"):
            key_element = seg.find(f".//ele[@id='{condition_key}']")
            if key_element is not None and key_element.text == condition_value:
                target_element = seg.find(f".//ele[@id='{target_element_id}']")
                if target_element is not None:
                    return target_element.text
        return None  # No element matched the condition
    else:
        # No condition, direct lookup of the element
        # Check for composite elements like 'CLM05-01'
        if '-' in last_part:
            comp_id = last_part.split('-')[0][:-2]
            target_element = current_node.find(f".//comp[@id='{comp_id}']/subele[@id='{last_part}']")
        else:
            target_element = current_node.find(f".//ele[@id='{last_part}']")
        
        if target_element is not None:
            return target_element.text
        return None

def getFieldDataStr(node: ET.Element, path: str) -> Optional[str]:
    tempFieldData = getFieldData(node, path)
    return tempFieldData if tempFieldData is not None else ""

def get_element_text(element: Optional[ET.Element], *sub_element_ids: str) -> Optional[str]:
    """
    Safely retrieves the text from a nested sub-element.
    
    Args:
        element: The parent ET.Element to search within.
        sub_element_ids: A sequence of sub-element IDs to traverse.
        
    Returns:
        The text of the found sub-element, or None if not found.
    """
    if element is None:
        return None
    
    temp_element = element
    for i, an_id in enumerate(sub_element_ids):
        # Correctly format the XPath to find a direct child 'ele' with a specific 'id'
        xpath = f"./ele[@id='{an_id}']"
        found_element = temp_element.find(xpath)
        if found_element is None:
            # If not found, try to find a comp/subele structure
            xpath_comp = f"./comp[@id='{an_id.split('-')[0]}']/subele[@id='{an_id}']"
            found_element = temp_element.find(xpath_comp)

        if found_element is None:
            return None # Exit if any part of the path is missing
        temp_element = found_element
        
        if isinstance(temp_element, int):
            return str(temp_element)

    return temp_element.text

def format_date(date_str: Optional[str]) -> str:
    """Formats a YYYYMMDD date string to MM/DD/YYYY."""
    if not date_str or len(date_str) != 8:
        return ""
    return f"{date_str[4:6]}/{date_str[6:8]}/{date_str[0:4]}"

def parse_837_xml(file_path: Path) -> Dict[str, Any]:
    """
    Parses an 837 XML file and extracts key information into a structured dictionary.
    
    Args:
        file_path: The path to the XML file.
        
    Returns:
        A dictionary containing the parsed claim data.
    """
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
    except ET.ParseError:
        return {"error": "Failed to parse XML file."}

    # Placeholder for the final parsed data
    parsed_data = {}

    # --- 1. Transaction / File Metadata (ISA, GS, ST, BHT) ---
    isa_loop = root.find("./loop[@id='ISA_LOOP']")
    gs_loop = isa_loop.find("./loop[@id='GS_LOOP']") if isa_loop else None
    st_loop = gs_loop.find("./loop[@id='ST_LOOP']") if gs_loop else None

    # Interchange Control Header (ISA)
    isa_segment = isa_loop.find("./seg[@id='ISA']") if isa_loop else None
    parsed_data['interchange_control'] = {
        'sender_id': get_element_text(isa_segment, 'ISA06'),
        'receiver_id': get_element_text(isa_segment, 'ISA08'),
        'control_number': get_element_text(isa_segment, 'ISA13'),
        'date': get_element_text(isa_segment, 'ISA09'),
        'time': get_element_text(isa_segment, 'ISA10'),
    }

    # Functional Group Header (GS)
    gs_segment = gs_loop.find("./seg[@id='GS']") if gs_loop else None
    parsed_data['functional_group'] = {
        'group_control_number': get_element_text(gs_segment, 'GS06'),
        'version': get_element_text(gs_segment, 'GS08'),
    }

    # Transaction Set Header (ST)
    st_segment = st_loop.find("./seg[@id='ST']") if st_loop else None
    parsed_data['transaction_set'] = {
        'control_number': get_element_text(st_segment, 'ST02'),
        'type': get_element_text(st_segment, 'ST01'),
    }

    # Beginning of Hierarchical Transaction (BHT)
    bht_segment = st_loop.find(".//seg[@id='BHT']") if st_loop else None
    if bht_segment is not None:
        parsed_data['hierarchical_transaction'] = {
            'structure_code': get_element_text(bht_segment, 'BHT01'),
            'purpose_code': get_element_text(bht_segment, 'BHT02'),
            'creation_date': format_date(get_element_text(bht_segment, 'BHT04')),
        }

    # --- 2. Extract All Claims ---
    parsed_data['claims'] = []
    if st_loop:
        # Find all hierarchical level loops that contain claim info
        hl_loops = st_loop.findall(".//loop[@id='2000A']")  # Typically starts with provider
        for hl_loop in hl_loops:
            # --- Provider Details (Loop 2010AA - Billing Provider) ---
            provider_loop = hl_loop.find("./loop[@id='2010AA']")
            n1_provider_seg = provider_loop.find("./seg[@id='NM1']") if provider_loop else None
            n3_provider_seg = provider_loop.find("./seg[@id='N3']") if provider_loop else None
            n4_provider_seg = provider_loop.find("./seg[@id='N4']") if provider_loop else None
            ref_provider_seg = provider_loop.find("./seg[@id='REF']") if provider_loop else None
            per_provider_segs = provider_loop.findall("./seg[@id='PER']") if provider_loop else None
            per_provider_seg1 = provider_loop.find("./seg[@id='PER']") if provider_loop else None

            billing_provider_name = get_element_text(n1_provider_seg, 'NM103')
            billing_provider_phone = ""


            if isinstance(per_provider_segs, list):
                for per_segment in per_provider_segs:
                    per_type = get_element_text(per_segment, 'PER03')
                    if per_type == "TE":
                        billing_provider_phone = get_element_text(per_segment, 'PER04')
            elif per_provider_seg1 is not None:
                per_type = get_element_text(per_provider_seg1, 'PER03')
                if per_type == "TE":
                    billing_provider_phone = get_element_text(per_provider_seg1, 'PER04')


            if get_element_text(n1_provider_seg, 'NM104') is not None:
                billing_provider_name = get_element_text(n1_provider_seg, 'NM104') + " " + billing_provider_name

            billing_provider_details = {
                'fname': getFieldDataStr(provider_loop,"NM104"),
                'lname': getFieldDataStr(provider_loop,"NM103"),
                'npi': get_element_text(n1_provider_seg, 'NM109'),
                'address': get_element_text(n3_provider_seg, 'N301'),
                'city': get_element_text(n4_provider_seg, 'N401'),
                'state': get_element_text(n4_provider_seg, 'N402'),
                'zip': get_element_text(n4_provider_seg, 'N403'),
                'tax_id': getFieldDataStr(provider_loop,"REF02[REF01=EI]") if getFieldDataStr(provider_loop,"REF02[REF01=EI]") != "" else (getFieldDataStr(provider_loop,"REF02[REF01=SY]") if getFieldDataStr(provider_loop,"REF02[REF01=SY]") != "" else ""),
                'ein_found': True if getFieldDataStr(provider_loop,"REF02[REF01=EI]") != "" else False,
                'ssn_found': True if (getFieldDataStr(provider_loop,"REF02[REF01=SY]") != "" and getFieldDataStr(provider_loop,"REF02[REF01=EI]") == "" ) else False,
                'phone': billing_provider_phone
            }

            # --- Subscriber/Patient loops (2000B) ---
            subscriber_loops = hl_loop.findall(".//loop[@id='2000B']")
            for sub_loop in subscriber_loops:
                # --- Subscriber Details (Loop 2010BA - Subscriber) ---
                subscriber_details_loop = sub_loop.find("./loop[@id='2010BA']")
                n1_sub_seg = subscriber_details_loop.find("./seg[@id='NM1']") if subscriber_details_loop else None
                n3_sub_seg = subscriber_details_loop.find("./seg[@id='N3']") if subscriber_details_loop else None
                n4_sub_seg = subscriber_details_loop.find("./seg[@id='N4']") if subscriber_details_loop else None
                dmg_sub_seg = subscriber_details_loop.find("./seg[@id='DMG']") if subscriber_details_loop else None
                ref_sub_seg = subscriber_details_loop.find("./seg[@id='REF']") if subscriber_details_loop else None
                sub_relation = get_element_text(sub_loop.find("./seg[@id='SBR']"),'SBR02')
                sub_group_feca_num = get_element_text(sub_loop.find("./seg[@id='SBR']"),'SBR03')
                sub_insurance_type = get_element_text(sub_loop.find("./seg[@id='SBR']"),'SBR09')
                sub_insurance_name = getFieldDataStr(sub_loop,"2010BB|NM103")

                if sub_relation is None or sub_relation == "":
                    sub_relation = '18'

                insurance_types = {
                    "MA": "MA",
                    "MB": "MB",
                    "MC": "MC",
                    "CH": "CH",
                    "VA": "VA",
                    "CI": "CI",
                    "BL": "BL",
                    "HM": "HM",
                    "OF": "OF",
                    "11": "11",
                    "ZZ": "ZZ"
                }

                if sub_insurance_type is not None:
                    sub_insurance_type = insurance_types.get(sub_insurance_type,"ZZ")

                sub_other_claim_id = ""
                if ref_sub_seg:
                    for ref_seg in ref_sub_seg:
                        ref01_temp = get_element_text(ref_seg, 'REF01')
                        if ref01_temp == "Y4":
                            sub_other_claim_id = get_element_text(ref_seg, 'REF02')

                subscriber_details = {
                    'last_name': get_element_text(n1_sub_seg, 'NM103'),
                    'first_name': get_element_text(n1_sub_seg, 'NM104'),
                    'middle_name': get_element_text(n1_sub_seg, 'NM105'),
                    'subscriber_id': get_element_text(n1_sub_seg, 'NM109'),
                    'address': get_element_text(n3_sub_seg, 'N301'),
                    'city': get_element_text(n4_sub_seg, 'N401'),
                    'state': get_element_text(n4_sub_seg, 'N402'),
                    'zip': get_element_text(n4_sub_seg, 'N403'),
                    'dob': format_date(get_element_text(dmg_sub_seg, 'DMG02')),
                    'gender': get_element_text(dmg_sub_seg, 'DMG03'),
                    'relationship': sub_relation,
                    'insurance_type': sub_insurance_type,
                    'sub_group_feca_num': sub_group_feca_num,
                    'sub_insurance_name': sub_insurance_name,
                    'sub_other_claim_id': sub_other_claim_id
                }
                
                # --- Patient Details (Loop 2000C -> 2010CA) ---
                patient_details = {}
                patient_loop = sub_loop.find("./loop[@id='2000C']")
                if patient_loop:
                    pat_seg = patient_loop.find("./seg[@id='PAT']")
                    patient_details_loop = patient_loop.find("./loop[@id='2010CA']")
                    n1_pat_seg = patient_details_loop.find("./seg[@id='NM1']") if patient_details_loop else None
                    n3_pat_seg = patient_details_loop.find("./seg[@id='N3']") if patient_details_loop else None
                    n4_pat_seg = patient_details_loop.find("./seg[@id='N4']") if patient_details_loop else None
                    dmg_pat_seg = patient_details_loop.find("./seg[@id='DMG']") if patient_details_loop else None
                    patient_details = {
                        'relationship': sub_relation,
                        'last_name': get_element_text(n1_pat_seg, 'NM103'),
                        'first_name': get_element_text(n1_pat_seg, 'NM104'),
                        'middle_name': get_element_text(n1_pat_seg, 'NM105'),
                        'address': get_element_text(n3_pat_seg, 'N301'),
                        'city': get_element_text(n4_pat_seg, 'N401'),
                        'state': get_element_text(n4_pat_seg, 'N402'),
                        'zip': get_element_text(n4_pat_seg, 'N403'),
                        'dob': format_date(get_element_text(dmg_pat_seg, 'DMG02')),
                        'gender': get_element_text(dmg_pat_seg, 'DMG03'),
                    }

                # --- Other insured (2320) + (2330A) ---
                other_plan_loop = sub_loop.find(".//loop[@id='2320']")
                n1_other_plan_seg = other_plan_loop.find("./seg[@id='SBR']") if other_plan_loop else None
                other_insured_loop = sub_loop.find(".//loop[@id='2330A']")
                n1_other_sub_seg = other_insured_loop.find("./seg[@id='NM1']") if other_insured_loop else None
                other_insured_details = {}
                if n1_other_plan_seg and n1_other_sub_seg:
                    other_insured_details = {
                        'last_name': get_element_text(n1_other_sub_seg, 'NM103'),
                        'first_name': get_element_text(n1_other_sub_seg, 'NM104'),
                        'middle_name': get_element_text(n1_other_sub_seg, 'NM105') or '',
                        'policy_group_id': get_element_text(n1_other_sub_seg, 'NM109'),
                        'plan_name': get_element_text(n1_other_plan_seg, 'SBR04')
                    }




                # --- Claims for this Subscriber (Loop 2300) ---
                claim_loops = sub_loop.findall(".//loop[@id='2300']")
                for clm_loop in claim_loops:
                    claim = {}

                    # Claim Information (CLM)
                    clm_segment = clm_loop.find("./seg[@id='CLM']")
                    ref_segment = clm_loop.find("./seg[@id='REF']") # Prior Auth
                    dtp_segment = clm_loop.find("./seg[@id='DTP']")
                    amt_segment = clm_loop.find(".//seg[@id='AMT']")


                    common_dtp_quals = {"431","454","304","453","439","484","455","471","444","050","297","296"}

                    dtp_current_illness = dtp_segment if dtp_segment is not None else ""
                    disability_begins = ""
                    disability_ends = ""
                    hosp_admission = ""
                    hosp_discharge = ""
                    multi_dtp_segs = clm_loop.findall("./seg[@id='DTP']")

                    for dtp_seg in multi_dtp_segs:
                        dtp_qual = get_element_text(dtp_seg, 'DTP01')
                        if dtp_qual in common_dtp_quals:
                            dtp_current_illness = dtp_seg
                        if dtp_qual == "360":
                            disability_begins = dtp_seg
                        if dtp_qual == "361":
                            disability_ends = dtp_seg
                        if dtp_qual == "435":
                            hosp_admission = dtp_seg
                        if dtp_qual == "096":
                            hosp_discharge = dtp_seg
                    
                    amount_paid = 0
                    if get_element_text(amt_segment, 'AMT01') == "F5":
                        amount_paid = get_element_text(amt_segment, 'AMT02')

                    claim['claim_info'] = {
                        'claim_control_number': get_element_text(clm_segment, 'CLM01'),
                        'total_claim_charge_amount': get_element_text(clm_segment, 'CLM02'),
                        'place_of_service_code': get_element_text(clm_segment, 'CLM05-01'),
                        'prior_authorization_number': getFieldDataStr(clm_loop,"REF02[REF01=G1]"),
                        'clm_related_causes_01': get_element_text(clm_segment, 'CLM11-01'),
                        'clm_related_causes_02': get_element_text(clm_segment, 'CLM11-02'),
                        'clm_related_causes_04': get_element_text(clm_segment, 'CLM11-04'),
                        'date_current_illness': format_date(get_element_text(dtp_current_illness, 'DTP03')),
                        'date_current_illness_qual': get_element_text(dtp_current_illness, 'DTP01'),
                        'disability_begins': format_date(get_element_text(disability_begins, 'DTP03')),
                        'disability_ends': format_date(get_element_text(disability_ends, 'DTP03')),
                        'hosp_admission': format_date(get_element_text(hosp_admission, 'DTP03')),
                        'hosp_discharge': format_date(get_element_text(hosp_discharge, 'DTP03')),
                        'amount_paid': amount_paid,
                        'assignment_acceptance': get_element_text(clm_segment, 'CLM07')
                    }

                    # Assign the provider and subscriber info gathered above
                    claim['billing_provider'] = billing_provider_details
                    claim['subscriber'] = subscriber_details
                    if patient_details:
                        claim['patient'] = patient_details
                    if other_insured_details:
                        claim['other_insured'] = other_insured_details


                    # Health Care Diagnosis Code (HI)
                    claim['claim_info']['diagnoses_q_1'] = ""
                    claim['claim_info']['diagnoses_q_2'] = ""
                    hi_segment = clm_loop.find("./seg[@id='HI']")
                    if hi_segment is not None:
                        claim['diagnoses'] = []
                        
                        # 1. Find all 'subele' descendants within the HI segment.
                        all_subeles = hi_segment.findall(".//subele")
                        
                        # 2. Loop through the results and filter in Python.
                        for subele in all_subeles:
                            element_id = subele.get('id', '')  # Safely get the 'id' attribute
                            
                            # 3. Check if the ID matches the pattern for a diagnosis code.
                            if element_id and element_id.startswith('HI') and element_id.endswith('-02'):
                                diag_code = subele.text
                                if diag_code:
                                    claim['diagnoses'].append({'code': diag_code})

                        qualifier_element_1 = hi_segment.find(".//subele[@id='HI01-01']")
                        if qualifier_element_1 is not None and qualifier_element_1.text:
                            qualifier_code = qualifier_element_1.text.strip()
                            
                            if qualifier_code in ['ABK', 'ABF']:
                                claim['claim_info']['diagnoses_q_1'] = "0"
                                claim['claim_info']['diagnoses_q_2'] = "0"
                            elif qualifier_code in ['BK', 'BF']:
                                claim['claim_info']['diagnoses_q_1'] = "9"
                                claim['claim_info']['diagnoses_q_2'] = "9"

                    # Rendering Provider (Loop 2310B)
                    rendering_provider = {}
                    rendering_loop = clm_loop.find("./loop[@id='2310B']")
                    if rendering_loop:
                        n1_rendering_seg = rendering_loop.find("./seg[@id='NM1']")
                        rendering_provider = {
                            'npi': get_element_text(n1_rendering_seg, 'NM109')
                        }

                    # Referring Provider (Loop 2310A)
                    referring_provider = {}
                    referring_loop = clm_loop.find("./loop[@id='2310A']")
                    if referring_loop:
                        n1_referring_seg = referring_loop.find("./seg[@id='NM1']")
                        referring_provider = {
                            'qual': get_element_text(n1_referring_seg, 'NM101'),
                            'npi': get_element_text(n1_referring_seg, 'NM109'),
                            'last_name': get_element_text(n1_referring_seg, 'NM103'),
                            'first_name': get_element_text(n1_referring_seg, 'NM104')
                        }
                    claim['referring_provider'] = referring_provider

                    resubmission_code = getFieldDataStr(clm_loop,"CLM05-03")
                    original_ref_no = getFieldDataStr(clm_loop,"REF02[REF01=F8]") if resubmission_code in ['7', '8'] else None

                    # 3. Store the extracted data
                    # You can add this to your main claim dictionary
                    claim['claim_info']['resubmission_code'] = resubmission_code
                    claim['claim_info']['original_ref_no'] = original_ref_no

                    # Service Lines (Loop 2400)
                    claim['service_lines'] = []
                    service_line_loops = clm_loop.findall("./loop[@id='2400']")
                    for line_loop in service_line_loops:
                        ps1_segment = line_loop.find("./seg[@id='PS1']")
                        purchased_service = {}

                        if ps1_segment is not None:
                            purchased_service = {
                                'npi': get_element_text(n1_referring_seg, 'PS101'),
                                'charge': get_element_text(n1_referring_seg, 'PS102'),
                                'state': get_element_text(n1_referring_seg, 'PS103')
                            }
                        claim['purchased_service'] = purchased_service

                        sv1_segment = line_loop.find("./seg[@id='SV1']")
                        dtp_segment = line_loop.find("./seg[@id='DTP']")
                        
                        modifiers = []
                        diagnosis_pointers = []

                        if sv1_segment is not None:
                            modifiers = [
                                mod for mod in [
                                    sv1_segment.find(".//subele[@id='SV101-03']").text if sv1_segment.find(".//subele[@id='SV101-03']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV101-04']").text if sv1_segment.find(".//subele[@id='SV101-04']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV101-05']").text if sv1_segment.find(".//subele[@id='SV101-05']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV101-06']").text if sv1_segment.find(".//subele[@id='SV101-06']") is not None else ""
                                ] if mod
                            ]

                            diagnosis_pointers = [
                                ptr for ptr in [
                                    sv1_segment.find(".//subele[@id='SV107-01']").text if sv1_segment.find(".//subele[@id='SV107-01']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV107-02']").text if sv1_segment.find(".//subele[@id='SV107-02']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV107-03']").text if sv1_segment.find(".//subele[@id='SV107-03']") is not None else "",
                                    sv1_segment.find(".//subele[@id='SV107-04']").text if sv1_segment.find(".//subele[@id='SV107-04']") is not None else ""
                                ] if ptr
                            ]

                        service_line = {
                            'line_number': get_element_text(line_loop.find("./seg[@id='LX']"), 'LX01'),
                            'procedure_code': sv1_segment.find(".//subele[@id='SV101-02']").text if sv1_segment is not None else "",
                            'modifiers': modifiers,
                            'line_item_charge_amount': get_element_text(sv1_segment, 'SV102'),
                            'quantity': get_element_text(sv1_segment, 'SV104'),
                            'diagnosis_pointers': diagnosis_pointers,
                            'date_of_service': format_date(get_element_text(dtp_segment, 'DTP03')),
                            'rendering_provider': rendering_provider
                        }
                        claim['service_lines'].append(service_line)

                    parsed_data['claims'].append(claim)

    return parsed_data

