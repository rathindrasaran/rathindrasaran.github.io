import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
from nicegui import ui
from edi_gen_ai.config import PROJECT_DIR
from edi_gen_ai.tools.utils import run_and_stream, sanitize_filename, log

def extract_number(text):
    """Extracts the first sequence of digits from a string."""
    if not text:
        return None
    match = re.search(r'\d+', text)
    return match.group() if match else None

def process_claims_for_resubmission( CLAIM_DIR ):
    """
    Loads a pyx12-generated XML file from a specific claim directory,
    modifies each claim for resubmission based on data in the NTE segment,
    and saves the result to a new XML file.
    """
    # Build a robust path to the claims directory.
    # This assumes the script is in a subdirectory of the project root,
    # and the 'claims_upload' directory is also in the project root.
    # claim_path = Path(f'{PROJECT_DIR}/claims_upload/{CLAIM_DIR}')
    claim_path = Path(CLAIM_DIR)

    # Find the single XML file within the target directory.
    try:
        xml_file = next(claim_path.glob("*.xml"))
        print(f"Found XML file to process: {xml_file}")
    except StopIteration:
        print(f"Error: No XML file found in directory '{claim_path}'. Make sure the CLAIM_DIR is correct.")
        return

    # Define the output directory and ensure it exists.
    output_dir = claim_path / 'gen'
    output_dir.mkdir(parents=True, exist_ok=True)

    # Define the path for the new output file with the '-resubmit' suffix.
    output_filename = xml_file.with_name(f"{xml_file.stem}-resubmit.xml")
    output_file = output_dir / output_filename.name

    try:
        # Parse the XML document.
        tree = ET.parse(xml_file)
        root = tree.getroot()
    except ET.ParseError as e:
        print(f"Error: Failed to parse XML file '{xml_file}'. Details: {e}")
        return

    claims_modified_count = 0
    # Iterate through all claim loops (identified by the '2300' loop ID).
    for loop_2300 in root.findall(".//loop[@id='2300']"):
        # Find the NTE segment containing the original claim reference.
        nte_seg = loop_2300.find("./seg[@id='NTE']")
        if nte_seg is None:
            continue

        nte01 = nte_seg.find("./ele[@id='NTE01']")
        nte02_ele = nte_seg.find("./ele[@id='NTE02']")

        # Proceed only if the NTE segment is for an 'ADD'itional note
        # and contains text to process.
        if nte01 is not None and nte01.text == 'ADD' and nte02_ele is not None:
            original_claim_ref = extract_number(nte02_ele.text)

            if original_claim_ref:
                # Create a new REF segment for the original reference number.
                new_ref_segment = ET.Element('seg', {'id': 'REF'})
                ref01 = ET.SubElement(new_ref_segment, 'ele', {'id': 'REF01'})
                ref01.text = 'F8'  # 'F8' is the qualifier for Original Reference Number
                ref02 = ET.SubElement(new_ref_segment, 'ele', {'id': 'REF02'})
                ref02.text = original_claim_ref

                # Insert the new REF segment into the 2300 loop. A standard position
                # is after the existing REF segments or DTP segments.
                existing_refs = loop_2300.findall("./seg[@id='REF']")
                if existing_refs:
                    # Insert after the last existing REF segment
                    last_ref_index = list(loop_2300).index(existing_refs[-1])
                    loop_2300.insert(last_ref_index + 1, new_ref_segment)
                else:
                    # Fallback: insert after the CLM segment if no REFs exist
                    clm_seg = loop_2300.find("./seg[@id='CLM']")
                    if clm_seg is not None:
                        clm_index = list(loop_2300).index(clm_seg)
                        loop_2300.insert(clm_index + 1, new_ref_segment)
                    else:
                        loop_2300.append(new_ref_segment)


                # Modify the CLM05-03 sub-element value to '7' (Replacement).
                clm05_03 = loop_2300.find("./seg[@id='CLM']/comp[@id='CLM']/subele[@id='CLM05-03']")
                if clm05_03 is not None:
                    clm05_03.text = '7'
                    claims_modified_count += 1
                else:
                    print(f"Warning: Could not find CLM05-03 in a claim to modify.")

    if claims_modified_count > 0:
        # To improve readability of the output XML file.
        ET.indent(tree, space="  ")
        # Write the entire modified tree to the new file.
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        print(f"\nSuccessfully modified {claims_modified_count} claims.")
        print(f"Resubmission file saved as: {output_file}")

        edi_file_path = output_dir / output_file.name.replace('.xml','.edi')
        # Run the conversion command
        cmd = ['xmlx12', output_file, '--outputfile', edi_file_path]
        process = subprocess.run(cmd, capture_output=True, text=True, check=False)

        # Trigger the download
        ui.download(edi_file_path, f"{output_filename.name.replace('.xml','.edi')}")


    else:
        print("\nNo claims were modified. Please check the input XML for valid NTE segments with claim numbers.")

